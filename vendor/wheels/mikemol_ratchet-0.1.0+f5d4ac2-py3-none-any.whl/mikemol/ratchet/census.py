# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol
"""Turn a checker's findings into ratchet keys, and run the gate over them.

⚑⚑⚑ THE KEY IS `file:rule`, NOT `file:line:rule`. A line number changes when anything above
it moves, so a line-keyed baseline reports the whole file as new debt after an unrelated
edit — every key refused, none of it real. The origin of that mistake is easy to make and
its symptom is a gate that cries wolf until someone disables it.

⚑⚑ AND IT IS NOT `rule` ALONE, EITHER. Collapsing to the rule loses WHERE the debt is, so
paying one file down while another regresses reads as unchanged — the same substitution
blindness the set exists to defeat, one axis over.

⚑ THE COUNT PER (file, rule) IS DELIBERATELY NOT IN THE KEY. Two instances of one rule in
one file is the same debt as three; encoding the count would make an unrelated refactor
that merges two lines look like paydown. The set answers "does this file still owe this
rule", which is the question paydown-only can actually enforce.
"""

import os
import re
import subprocess
from collections.abc import Iterable
from pathlib import Path

# ⚑⚑ ruff's concise line is `path:line:col: <rule> message`, and `<rule>` is a RULE NAME
# (`docstring-missing-returns`) rather than a code (`DOC201`) under this configuration. A first
# cut of this pattern matched `[A-Z]+[0-9]+` and produced ZERO keys against a tree with 192
# findings — an empty census that reads exactly like a clean one, which is the fail-open shape
# this module's own docstring warns about. It was caught by running the parser rather than by
# reading it. The path may contain colons (`./src/x.py`), so the split is on the LAST three
# colon-separated fields rather than the first, and the rule is followed by a COLON.
_CONCISE = re.compile(r"^(?P<path>.+?):\d+:\d+:\s+(?P<code>[A-Za-z][A-Za-z0-9-]*):")


# ⚑⚑⚑ FILES A BUILD SYSTEM SYNTHESIZES ARE NOT PART OF THE DISTRIBUTION'S CENSUS. rules_python
# creates `__init__.py` at every level of a runfiles tree so it is importable; none of them exist
# in the source tree, and `src/mikemol/__init__.py` is the file PEP 420 forbids here outright,
# because it would make the first-installed distribution the exclusive owner of the `mikemol`
# prefix. MEASURED: the first honest run of the bazel ratchet gate refused 8 keys, all from these.
#
# ⚑⚑ THE CENSUS WAS CORRECT ABOUT WHAT IT SAW; WHAT IT SAW WAS NOT THE DISTRIBUTION. An action
# whose domain is a SUPERSET of the real one fails loudly rather than serving a stale green, which
# is the better of the two ways to be mis-typed — but it is still mis-typed, and the repair is to
# state the domain rather than to widen the baseline to swallow the noise.
# ⚑ A FIRST CUT EXCLUDED EVERY `__init__.py` AND OVER-EXCLUDED. `mdstruct/src/mikemol/mdstruct/
# __init__.py` EXISTS in source and legitimately carried a key; dropping it paid down real debt by
# accident, which is the mirror of the defect being fixed — a domain too NARROW rather than too
# wide, and that one serves a stale green. The synthesized files are exactly the empty ones, so
# the discriminator is emptiness rather than the name.
_SYNTHESIZED = "__init__.py"

# ⚑⚑⚑ THE SECOND SYNTHESIZED SHAPE, AND IT IS NOT EMPTY. `rules_python` 2.3.3 generates a
# `_<target>_stage2_bootstrap.py` beside every `py_binary` in the output tree — real Python with
# real content, so the emptiness test above cannot see it. MEASURED by the 1.0.0 -> 2.3.3 bump:
# `//ratchet:ratchet_gate` refused **49 new keys**, all in that one generated file.
# ⚑ MATCHED BY THE SUFFIX THE GENERATOR CHOOSES, not by a leading underscore: `_private.py` is a
# naming convention this repository uses for its own modules, and excluding on it would pay down
# real debt by accident — the over-exclusion the `__init__.py` predicate was already corrected
# for once. The suffix is the build system's, and nothing hand-written wears it.
_BOOTSTRAP_SUFFIX = "_stage2_bootstrap.py"


def _is_synthesized(path: str, root: Path) -> bool:
    """Report whether `path` names a build-system-synthesized file.

    ⚑ rules_python writes an EMPTY `__init__.py` at every level of a runfiles tree so it is
    importable. A hand-written one has content. Checking the bytes rather than the name keeps a
    real file's debt in the census while dropping an artifact the baseline never saw.

    ⚑⚑ AND THE NAME CHECK RAN FIRST, WHICH MADE THE DOMAIN TOO NARROW. This function's own note
    says *the discriminator is emptiness rather than the name* — while returning False outright
    unless the path ended in `__init__.py`, so emptiness was consulted for exactly one filename.
    A second generated shape, `_<target>_stage2_bootstrap.py`, is NOT empty and slipped straight
    through. Both are now named, because the two shapes have genuinely different discriminators:
    one is recognised by being empty, the other by a suffix only the generator writes.

    Returns:
        whether `path` names a build-system-synthesized file.

    """
    if path.endswith(_BOOTSTRAP_SUFFIX):
        return True
    if not path.endswith(_SYNTHESIZED):
        return False
    candidate = root.joinpath(path)
    return candidate.is_file() and not candidate.read_text(encoding="utf-8").strip()


def parse_concise(lines: Iterable[str], root: Path | None = None) -> frozenset[str]:
    """Return `{file:rule}` keys from a checker's concise output.

    ⚑ A LINE THAT DOES NOT MATCH IS DROPPED SILENTLY, and that is safe ONLY because the
    caller checks the process's exit code separately: a checker that crashed emits no
    matching lines, which would otherwise read as a clean census and pay the whole baseline
    down in one run. `run_ruff` refuses on an unexpected exit rather than trusting the parse.

    Returns:
        `{file:rule}` keys from a checker's concise output.

    """
    out: set[str] = set()
    for line in lines:
        found = _CONCISE.match(line.strip())
        if not found:
            continue
        # ⚑ THE `str()` IS THE NARROWING, NOT A FORMALITY — a regex group is typed `str | Any`, and
        # an `Any` reaching the returned mapping is an unchecked shape crossing this boundary.
        path = str(found["path"])
        if root is None or not _is_synthesized(path, root):
            out.add(f"{path}:{found['code']}")
    return frozenset(out)


class CensusUnavailableError(RuntimeError):
    """The checker could not produce a census; the gate must refuse, not crash or pass.

    ⚑ A `RuntimeError` subclass, so a caller that already refused on `RuntimeError` still does.
    """


def run_ruff(dist: Path, preview: bool) -> frozenset[str]:
    """Run ruff over one distribution and return its census.

    ⚑⚑ EXIT 0 AND EXIT 1 ARE BOTH SUCCESS HERE — 0 is a clean tree, 1 is findings. Anything
    ELSE (2 is a usage or internal error) means the checker did not run, and a census read
    from a checker that did not run is an empty set that looks exactly like a clean tree.
    That is the fail-open shape this ecosystem keeps paying for, so it raises instead.

    Returns:
        every `file:rule` key ruff reported, as a frozenset — empty when the tree is clean.

    Raises:
        CensusUnavailableError: when ruff cannot be started (missing, not executable), or exits
            with any status but 0 or 1, because a census read from a checker that did not run is
            indistinguishable from a clean tree and would pay the whole baseline down in one run.

    """
    # ⚑⚑ THE DECLARED BINARY WINS OVER A VENV PATH. This read `.venv/bin/ruff` unconditionally,
    # which is a developer venv no clone contains — the same escape the hooks suite already
    # closed. Under bazel `RUFF_BIN` names a hash-pinned staged input; unset, the venv answers as
    # before. An action reaching for an undeclared binary is invisible to its own key.
    venv_ruff = dist / ".venv" / "bin" / "ruff"
    # ⚑⚑ A RELATIVE `RUFF_BIN` IS ANCHORED WHERE IT WAS NAMED, NOT WHERE RUFF RUNS. ruff runs with
    # `cwd=dist`, so a relative path resolved against the distribution instead of the caller.
    # Measured: bazel's `$(location @ruff//:bin)` is `../+_repo_rules+ruff/ruff`, and exporting it
    # to the ratchet's own tests made every census "could not be run". Callers had dodged it one
    # by one (`Path(...).resolve()` at two hooks call sites); anchoring it here covers them all.
    # `cwd() / declared` is the caller's directory joined WITHOUT following links, and an
    # absolute `declared` wins the join unchanged.
    declared = os.environ.get("RUFF_BIN")
    binary = str(dist.cwd() / declared) if declared else str(venv_ruff)
    argv = [binary, "check", "--no-cache", "--output-format", "concise", "."]
    if preview:
        argv.insert(3, "--preview")
    # ⚑⚑⚑ A CHECKER THAT CANNOT START IS A REFUSAL, NOT A CRASH. Measured: with no
    # `<dist>/.venv/bin/ruff` and `RUFF_BIN` unset, this call raised a raw `FileNotFoundError`,
    # and the interpreter's default handler exits 1 — the status of "new keys refused". A
    # non-executable binary does the same as `PermissionError`. Both are `OSError`, and the
    # message names the path tried and the two ways to supply one.
    try:
        proc = subprocess.run(argv, capture_output=True, text=True, check=False, cwd=dist)
    except OSError as exc:
        msg = (
            f"cannot census {dist}: ruff at {binary} could not be run ({exc.strerror}) — "
            f"supply one as {venv_ruff} or name one in RUFF_BIN"
        )
        raise CensusUnavailableError(msg) from exc
    # ⚑ A SET LITERAL, ON THE CHECKER'S ADVICE, AND THE CONTROL FOR IT WAS MISSING. The arm that
    # covered this line proved an unexpected status REFUSES and nothing proved 0 and 1 are
    # ACCEPTED — a predicate refusing everything would have passed it, which is the broken-shut
    # gate this repository names. The positive arm was written first, so this rewrite has a
    # witness that it did not change which statuses the census admits.
    if proc.returncode not in {0, 1}:
        msg = (
            f"ruff exited {proc.returncode} in {dist} — the census is not trustworthy; "
            f"refusing rather than reporting an empty one\n{proc.stderr}"
        )
        raise CensusUnavailableError(msg)
    return parse_concise(proc.stdout.splitlines(), dist)
