# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol
"""Every ratchet and baseline every repository under a root carries, with its value (W1907).

    mikemol-ratchet census ROOT

The operator's ruling (host transcript 695f3e0a, line 92679): a nonzero ratchet is a priority
marker, so each is listed with the number it records and its floor. The kinds and the reading of a
value are `kinds`; this is the walk.

⚑ A REPOSITORY IS A DIRECTORY UNDER THE ROOT THAT IS NOT A CLONE OR A WORKTREE. A name that starts
with `.` (a gate worktree) or ends in `-bak`, `-bak2` and the like (a clone kept for reference) is
skipped, because counting a clone's baseline beside the original's would double the debt.

⚑ STAGING AND ARCHIVE DIRECTORIES ARE NOT REPOSITORIES AND HOLD NO RATCHETS (W1956): a name-only
classifier cannot tell a gate's baseline from a MEASUREMENT called baseline, and `scratch` and
`tmp` hold benchmark fixtures and copies of other repositories' files, while a directory with
`_session_export_` in its name is an archive of one session's working files (28 atlas
measurements read as baselines in cotype's). They are skipped, at the root and inside a
repository, so the 32 files they gave no longer read as debt.

⚑ THE WALK READS NO LINK AND ENTERS NO BUILD OR VENDOR TREE: `bazel-*` convenience links, `.git`,
`.venv`, `node_modules`, `_build`, caches and agent `worktrees` (copies of the repository's own
files) are pruned, and a link met on the way is not followed.
Only `.json`, `.txt` and `.tsv` files count, so a prose document about a baseline is not one.

⚑ AN UNREAD FILE IS LISTED AS UNREAD, NOT LEFT OUT: a census that dropped what it could not parse
would show fewer ratchets after a baseline broke.
"""

import os
import re
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path

from mikemol.ratchet import declaration, exemptions, expression, kinds

MAX_DEPTH = 4
_SUFFIXES = frozenset({".json", ".txt", ".tsv"})
_CLONE = re.compile(r"-bak\d*$")
_ARCHIVE = re.compile(r"_session_export_")
_STAGING = frozenset({"scratch", "tmp"})
_PRUNED = frozenset(
    {".git", ".venv", "node_modules", "__pycache__", "_build", ".kube", "worktrees"}
)


@dataclass(frozen=True)
class Row:
    """One ratchet file: its repository, path within it, kind, recorded value and floor."""

    repo: str
    ratchet: str
    kind: str
    value: int | None
    floor: int
    total: int | None = None
    guessed: bool | None = None

    def line(self) -> str:
        """Spell the row as one census line.

        Returns:
            the line, with `UNREAD` where the file could not be read, ` sum=N` after the floor
            for a file-rule-count baseline (W1922), and ` guessed=1` when the name classifier
            found the file or ` guessed=0` when the repository declared it (W1958).

        """
        said = "UNREAD" if self.value is None else str(self.value)
        line = f"{self.repo} {self.ratchet} {self.kind} value={said} floor={self.floor}"
        if self.total is not None:
            line = f"{line} sum={self.total}"
        return line if self.guessed is None else f"{line} guessed={int(self.guessed)}"


def repos_under(root: Path) -> list[Path]:
    """List the repository directories under a root, in name order.

    Returns:
        every real directory whose name is neither hidden nor a clone's (`-bak`, `-bak2`).

    """
    return [
        entry
        for entry in sorted(root.iterdir())
        if entry.is_dir()
        and not entry.is_symlink()
        and not entry.name.startswith(".")
        and not _CLONE.search(entry.name)
        and entry.name not in _STAGING
        and not _ARCHIVE.search(entry.name)
    ]


def _walk(repo: Path) -> Iterator[Path]:
    base = len(repo.parts)
    for here, dirs, names in os.walk(repo):
        dirs[:] = sorted(
            d
            for d in dirs
            if d not in _PRUNED
            and not d.startswith("bazel-")
            and d not in _STAGING
            and not _ARCHIVE.search(d)
            and len(Path(here).parts) - base < MAX_DEPTH
        )
        for name in sorted(names):
            yield Path(here) / name


def _files(repo: Path) -> Iterator[Path]:
    return (path for path in _walk(repo) if path.suffix in _SUFFIXES)


def suppression_rows(repo: Path) -> list[Row]:
    """List the repository's one `suppression` row: its sources' suppression comments (W2140).

    ⚑ THE PYCHECK GATE REFUSES TO ADD A SUPPRESSION, so a count above zero is a leftover that this
    row keeps visible. The walk is the census's own (pruned, depth-bounded), so a vendored tree or
    a venv is not counted. A source that does not tokenize makes the row `UNREAD`, never short.

    Returns:
        one row `*.py` summing every source; empty when the repository has no Python source.

    """
    total = 0
    seen = False
    for path in _walk(repo):
        if path.suffix == ".py":
            seen = True
            counted = exemptions.suppressions(path.read_text(encoding="utf-8", errors="replace"))
            if counted is None:
                return [Row(repo.name, "*.py", "suppression", None, kinds.FLOOR)]
            total += counted
    return [Row(repo.name, "*.py", "suppression", total, kinds.FLOOR)] if seen else []


def exemption_rows(repo: Path) -> list[Row]:
    """List one `exemption` row per pyproject the repository carries (W2139).

    ⚑ AN EXEMPTION IS DEBT MOVED, NOT DEBT PAID (operator 2026-10-25): a counted allowlist entry
    removed and the same debt put in a `per-file-ignores` row makes one count fall and this one
    rise, so their sum reads unchanged and never as paydown. The row's value is
    `exemptions.count` of the file; an unreadable pyproject is `UNREAD`, not zero.

    Returns:
        the rows in path order; empty when the repository has no pyproject.

    """
    rows: list[Row] = []
    for path in _walk(repo):
        if path.name == "pyproject.toml":
            value = exemptions.count(path.read_text(encoding="utf-8", errors="replace"))
            relative = path.relative_to(repo).as_posix()
            rows.append(Row(repo.name, relative, "exemption", value, kinds.FLOOR))
    return [*rows, *suppression_rows(repo)]


def _declared_row(repo: Path, item: declaration.Declared) -> Row:
    path = repo / item.path
    value = expression.evaluate(path, item.expression, item.columns)
    return Row(
        repo.name, item.path, item.kind, value, kinds.FLOOR, kinds.sum_of(path), guessed=False
    )


def census_repo(repo: Path) -> list[Row]:
    """List every ratchet file in ONE repository (W1923).

    ⚑ A GATE CENSUSES ITS OWN REPOSITORY AND NO OTHER. The operator's ruling (host transcript
    695f3e0a, line 84035): repos must not be aware that sibling checkouts exist. A repository's own
    gate reports its own ratchets at its own landings, which is also how the pace is keyed; the
    fleet-wide `census` below is an operator tool and is never called from a gate.

    ⚑ A DECLARATION WINS (W1957): a repository with a `ratchets.json` is read from it and from
    nothing else, so no file is counted for its name alone; one without falls back to the name
    classifier.

    Returns:
        one row per declared ratchet, or else per file whose name is a ratchet kind, the
        repository named by its directory; a declaration that exists and cannot be trusted
        raises `declaration.DeclarationError` rather than reading as empty.

    """
    declared = declaration.read(repo)
    if declared is not None:
        return [*(_declared_row(repo, item) for item in declared), *exemption_rows(repo)]
    rows: list[Row] = []
    for path in _files(repo):
        kind = kinds.kind_of(path.name)
        if kind is not None:
            relative = path.relative_to(repo).as_posix()
            value, total = kinds.value_of(path), kinds.sum_of(path)
            rows.append(Row(repo.name, relative, kind, value, kinds.FLOOR, total, guessed=True))
    return [*rows, *exemption_rows(repo)]


def tombstone_line(repo: str, item: declaration.Retired) -> str:
    """Spell one retired ratchet as a census line (W1963).

    ⚑ THE LINE HAS NO `value=`, SO A READER OF RATCHET ROWS SKIPS IT: a tombstone is a different
    fact from a ratchet's value, and an older `ratchet_emit` must not mistake one for the other.

    Returns:
        `<repo> <path> retired reason=<reason> sha=<sha>`, with ` to=<path>` after a rename.

    """
    line = f"{repo} {item.path} retired reason={item.reason} sha={item.sha}"
    return f"{line} to={item.to}" if item.to else line


def tombstones(repo: Path) -> list[str]:
    """List the tombstone lines of ONE repository, in declaration order.

    Returns:
        one line per retired entry; empty when the repository declares none; a declaration that
        cannot be trusted raises `declaration.DeclarationError`, as `census_repo` does.

    """
    return [tombstone_line(repo.name, item) for item in declaration.read_retired(repo)]


def tombstones_under(root: Path) -> list[str]:
    """List the tombstone lines of every repository under a root.

    Returns:
        the lines, repository by repository in name order.

    """
    return [line for repo in repos_under(root) for line in tombstones(repo)]


def census(root: Path) -> list[Row]:
    """List every ratchet file in every repository under a root.

    Returns:
        one row per file whose name is a ratchet kind, repository by repository.

    """
    return [row for repo in repos_under(root) for row in census_repo(repo)]
