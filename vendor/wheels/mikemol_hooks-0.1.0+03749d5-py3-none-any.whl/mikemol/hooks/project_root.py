# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol

# ⚑⚑⚑ CONSUMED BY: no caller in this repository, and EIGHT across the fleet.
#   substrate/scripts/hook_fire_probe.py      substrate/scripts/pycheck_analyze.py
#   substrate/substrate/project_root_selftest.py
#   paperkit/scripts/pycheck_analyze.py       summit/scripts/pycheck_analyze.py
#   (plus substrate/build/lib/ copies of the first three)
#
# ⚑⚑ MEASURED 2026-09-07. Two independent readers agreed nothing here imports this module, and a
# third — swept fleet-wide — found eight importers. ⚑ THE FIRST FLEET READER FAILED ITS OWN
# CONTROL and reported zero: it required the module name inside a dotted path, while the real
# shape is `from mikemol.hooks import project_root`, with the name after `import` past a space the
# pattern could not cross. That negative was a statement about the reader, and it is the reason
# the control is run before the count is read.
#
# ⚑⚑⚑ THE PEERS IMPORT THEIR OWN COPIES. By hash, `substrate/scripts/` and `summit/scripts/` hold
# byte-identical siblings differing from this file; this copy drops the shebang that this repo's
# own `EXE001` reasoning removed for an imported module. Strictly ahead, and unread.
#
# ⚑ NOT REPAIRED HERE — those trees belong to their owners. The record is the deliverable.
"""Which project governs a file — the nearest `pyproject.toml` at or above it.

⚑⚑⚑ A CHECKER POINTED AT THE WRONG CONFIG IS A CHECKER THAT AGREES WITH YOU, AND THE HOOK WAS
POINTING AT ITS OWN. `pycheck_analyze` derives the project from the HOOK's location, so every
file it checks gets THIS repo's bar regardless of which repo the file lives in. Inside substrate
that is correct and invisible; the moment a second repo is edited in the same session it is
wrong in both directions at once — the foreign file is measured against rules it never adopted,
and the rules it DID adopt are never applied.

⚑⚑ MEASURED, NOT SUPPOSED (2026-08-31). Creating a PEP 420 namespace package in a sibling repo
was refused with `INP001: part of an implicit namespace package. Add an __init__.py` — a rule
that is correct under substrate's config and EXACTLY BACKWARDS for a namespace distribution,
where the absent `__init__.py` is the property the whole package rests on. The hook was
demanding the destruction of the thing being built.

⚑⚑ AND THE STAGING DIRECTORY MOVES WITH THE CONFIG, WHICH IS WHY THIS RETURNS A ROOT RATHER
THAN A FILE. ruff and mypy discover configuration by walking UP from the file they are handed,
so a tempfile staged in the wrong project inherits the wrong `pyproject.toml` even when one is
named explicitly — and the editable install that resolves a half-migrated module's sibling
imports is the one in THAT project's venv. Config, staging and interpreter are one decision.

⚑ THE WALK STOPS AT THE FILESYSTEM ROOT AND REPORTS NOTHING RATHER THAN GUESSING. A file under
no project at all is a real case (a scratch file in `/tmp`, a path the caller invented), and
answering it with some default project would apply a bar nobody chose — the same defect one
level out.

⚑⚑ AND `absolute()`, NEVER `resolve()`, MATCHING THE HOOK THIS SERVES. The hooks are themselves
SYMLINKED into other checkouts; a resolved path would walk up from substrate's tree and hand an
adopting repo substrate's config, which is the very defect this module exists to remove. That is
the opposite of the ruling for a tool locating its OWN home, where following the symlink is
required — two rules that look contradictory and are not, because they answer different
questions: *where do I live* versus *whose file is this*.
"""

from __future__ import annotations

from pathlib import Path

# The file whose presence declares a directory a project root.
MARKER = "pyproject.toml"

# ⚑⚑ W482: AN ATOM'S OWN mypy CONFIG. A directory below a project root may carry a `mypy.ini`
# (rules_py does: an atom is not a distribution, so it has no pyproject of its own), and the gate's
# mypy target runs FROM that directory UNDER that file. The hook must apply the same bar.
MYPY_INI = "mypy.ini"


def project_for(path: str | Path) -> Path | None:
    """Return the nearest directory at or above `path` holding a `pyproject.toml`.

    ⚑ `absolute()` RATHER THAN `resolve()` — see the module note. The caller's path is taken as
    given: a file reached through a symlink belongs to the project it was reached THROUGH, which
    is what an adopting repo means by adopting.

    Returns:
        nearest directory at or above `path` holding a `pyproject.toml`.

    """
    start = Path(path).absolute()
    here = start if start.is_dir() else start.parent
    for candidate in (here, *here.parents):
        if (candidate / MARKER).is_file():
            return candidate
    return None


def config_for(path: str | Path) -> Path | None:
    """Return the `pyproject.toml` governing `path`, or None when it is under no project.

    Returns:
        `pyproject.toml` governing `path`, or None when it is under no project.

    """
    root = project_for(path)
    return (root / MARKER) if root is not None else None


def venv_python_for(path: str | Path) -> Path | None:
    """Return the interpreter of the project governing `path`, when it has one.

    ⚑ THE INTERPRETER IS PART OF THE SAME DECISION. A checker run from another project's venv
    resolves that project's installed packages, so a half-migrated module's sibling imports
    would resolve against the wrong editable install — silently, and in the direction that finds
    less. A project without a venv returns None so the caller can say so rather than falling
    back to whichever interpreter happens to be running.

    Returns:
        interpreter of the project governing `path`, when it has one.

    """
    root = project_for(path)
    if root is None:
        return None
    candidate = root / ".venv" / "bin" / "python3"
    return candidate if candidate.exists() else None


def mypy_config_for(path: str | Path) -> Path | None:
    """Return the nearest `mypy.ini` at or above `path`, stopping at its governing project root.

    ⚑ BOUNDED BY THE PROJECT: a `mypy.ini` above the root belongs to some other tree, and the
    pyproject that governs the file is the answer there.

    Returns:
        the `mypy.ini` governing `path`, or None when the project's pyproject governs it.

    """
    root = project_for(path)
    if root is None:
        return None
    start = Path(path).absolute()
    here = start if start.is_dir() else start.parent
    for candidate in (here, *here.parents):
        if (candidate / MYPY_INI).is_file():
            return candidate / MYPY_INI
        if candidate == root:
            break
    return None
