# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol
"""Read the harness's untyped payload, and report whether the hook is armed.

⚑ A HOOK THAT MIS-READS ITS OWN INPUT RENDERS A VERDICT ABOUT SOMETHING OTHER THAN WHAT RAN,
which is why this is its own responsibility: it changes when the HARNESS's contract changes, not
when a checker, a message or a verdict does.

⚑ NO SHEBANG — THIS IS AN IMPORTED MODULE, NOT A SCRIPT. The origin tree kept these as files in a
`scripts/` directory, so every one carried a shebang and an exe bit; as package modules they are
imported, and the linter says so.
"""

from __future__ import annotations

import os

# ⚑ THE HOOK'S OWN SWITCH, CHECKED FIRST. A shared switch alone cannot arm one hook without
# arming its siblings, and a repo adopting this may want exactly one of them refusing.
OWN_SWITCH = "PYCHECK_HOOK_BLOCK"

# The switch every hook in this package honours when its own is unset.
SHARED_SWITCH = "STRUCT_HOOK_BLOCK"


def as_record(value: object) -> dict[str, object]:
    """Return `value` as a string-keyed record, or an empty one if not a mapping.

    ⚑⚑ `object` IS THE HONEST TYPE OF AN UNTRUSTED VALUE; `Any` IS THE DISHONEST ONE. The payload
    arrives as untyped JSON; rebuilding the mapping with a declared return type forces its values
    to `object`, and every read is then narrowed with a real runtime `isinstance` at the use
    site — a CHECK, not an assertion. `isinstance(x, dict)` alone narrows to `dict[Any, Any]`, so
    every read through it inherits the `Any` a strict bar exists to refuse.

    Returns:
        `value` as a string-keyed record, or an empty one if not a mapping.

    """
    if not isinstance(value, dict):
        return {}
    return {str(k): v for k, v in value.items()}


def text_of(value: object) -> str:
    """Return `value` when it is a string, else an empty string.

    Returns:
        `value` when it is a string, else an empty string.

    """
    return value if isinstance(value, str) else ""


def armed(own: str = OWN_SWITCH) -> bool:
    """Report whether this hook is set to DENY — own switch first, then the shared one.

    ⚑⚑ `own` NAMES THE CALLING HOOK'S SWITCH, AND THE DEFAULT IS ONE HOOK'S, NOT ALL OF THEM.
    `OWN_SWITCH` is `PYCHECK_HOOK_BLOCK` — the origin tree's python-check hook. A second hook
    calling a bare `armed()` would be switched by THAT variable, so standing down one hook would
    silently stand down, or arm, another. Found by substrate's shellcheck letter (2026-09-22): a
    plain port would have re-keyed `SHELLCHECK_HOOK_BLOCK` onto `PYCHECK_HOOK_BLOCK` with no error.
    Every hook other than the default's owner passes its own name.

    ⚑⚑ ARMED ON THE COMMAND LINE, NOT BY AN ENVIRONMENT BLOCK ALONE. A session already running
    when its settings change never re-reads them, so a hook armed only in a settings env block
    keeps exiting 0 — detecting every violation and reporting none, **reading as armed in review
    and off in fact**. Set the switch inline in the command string. Two independent adopters
    volunteered this trap.

    Returns:
        whether this hook is set to DENY — own switch first, then the shared one.

    """
    mine = os.environ.get(own)
    if mine is not None:
        return mine == "1"
    return os.environ.get(SHARED_SWITCH) == "1"
