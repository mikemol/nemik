# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol
"""`mikemol-vlog`: ship JSON lines to VictoriaLogs as structured fields (W1179).

    tool | mikemol-vlog --stream tool=commit --stream repo=mtools
    mikemol-vlog --stream tool=gate -- some-tool --its --args       (exit status is the tool's)
    mikemol-vlog --stream tool=app --from-file app.log --state app.state    (once, from an offset)
    mikemol-vlog --stream tool=app --from-file app.log --follow    (then wait for more: W1817)
    mikemol-vlog --drain                                    (send what is spooled, in front)

⚑ THE CALLER'S WORK IS A LOCAL FILE APPEND. Lines become records (`vlogrecord`), are appended to a
spool (`vlogship.ship`), and then a DETACHED drainer is started and not waited for (`vlogdetach`).
A stalled or refusing endpoint can only grow the spool, never the caller's wait. No wall-clock
timeout exists anywhere in this path; the bounds are lines and bytes.

⚑ THE EXIT STATUS IS THE PRODUCER'S. A pipe cannot see it, so the wrapper form runs the command and
returns its status; the stdin and file forms return 0 once the lines are spooled (2: usage).

⚑ THE FILE FORM SAVES EXACTLY THE PREFIX IT SPOOLED. Re-reading the file to find the offset would
commit past a line appended in between, and under `on_full = hold` a spool at its ceiling takes only
part of a chunk: the offset saved is the end of the last consumed line, so the held tail is read
again by the next run. `hold` needs the file form (stdin and a command cannot be re-read), so it is
refused as a usage error with anything else.

CONSUMED BY: the `mikemol-vlog` console script.
"""

import argparse
import datetime as dt
import json
import sys
import time
from collections.abc import Callable, Iterable, Sequence
from pathlib import Path
from typing import TextIO

from mikemol.hooks import (
    vlogbatch,
    vlogconfig,
    vlogdetach,
    vlogfollow,
    vlogforms,
    vlogrecord,
    vlogship,
)

EXIT_USAGE = 2
EXIT_NO_DESTINATION = 3
EXIT_REFUSED = 4
EXIT_BUSY = 5
EXIT_HELD = 6
FOLLOW_PERIOD_S = 1.0
FOLLOW_NEEDS_A_FILE = "--follow needs --from-file: only a file can be followed from an offset"
UNITS = ("s", "ms", "us", "ns")
HOLD_NEEDS_A_FILE = (
    "on_full = hold needs --from-file: stdin and a wrapped command cannot be re-read"
)
Spawn = Callable[[Sequence[str]], None]


class Args(argparse.Namespace):
    """The parsed command line, typed so nothing downstream is `Any`."""

    stream: list[str] | None
    service: str | None
    source: str | None
    resolver_arg: list[str] | None
    spool_dir: Path | None
    max_lines: int | None
    max_bytes: int | None
    message_key: str
    time_key: str | None
    stamp: str | None
    unit: str
    from_file: Path | None
    state: Path | None
    follow: bool
    follow_period: float
    drain: bool
    no_drain: bool
    exit_classes: bool
    config: Path
    command: list[str]


def _now() -> str:
    return vlogrecord.stamp(dt.datetime.now(dt.UTC))


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mikemol-vlog")
    parser.add_argument("--stream", action="append", metavar="KEY=VALUE")
    parser.add_argument("--service", help="the service NAME the host's resolver is asked for")
    parser.add_argument("--source", help="a [source.NAME] table: this source's ceiling and policy")
    parser.add_argument("--resolver-arg", action="append", metavar="ARG")
    parser.add_argument("--spool-dir", type=Path)
    parser.add_argument("--max-lines", type=int)
    parser.add_argument("--max-bytes", type=int)
    parser.add_argument(
        "--message-key",
        default=vlogrecord.DEFAULT_MESSAGE_KEY,
        help=(
            "the JSON key that holds the log message (default 'message'); a line whose message "
            "is under another key is shipped whole as _msg, so a caller whose records are already "
            "VictoriaLogs-shaped passes --message-key _msg"
        ),
    )
    parser.add_argument("--time-key")
    parser.add_argument("--stamp", help="a [stamps.NAME] kind that reads the time out of a line")
    parser.add_argument("--unit", default="s", choices=UNITS)
    parser.add_argument("--from-file", type=Path)
    parser.add_argument("--state", type=Path)
    parser.add_argument(
        "--follow",
        action="store_true",
        help="with --from-file: after shipping, wait for the file to change and ship again",
    )
    parser.add_argument(
        "--follow-period",
        type=float,
        default=FOLLOW_PERIOD_S,
        help="with --follow: seconds between looks at a quiet file (a sampling period)",
    )
    parser.add_argument("--drain", action="store_true", help="send the spool now, in front")
    parser.add_argument("--no-drain", action="store_true", help="spool only; start no drainer")
    parser.add_argument(
        "--exit-classes",
        action="store_true",
        help="exit 6 when the hold policy left lines in the file (a transient condition)",
    )
    parser.add_argument("--config", type=Path, default=vlogconfig.CONFIG_PATH)
    parser.add_argument("command", nargs="*", help="after --: a command to run and ship")
    return parser


def _state_of(args: Args) -> Path | None:
    """Name the offset state file of the file form.

    Returns:
        `--state`, else `<file>.vlogstate` beside the file; None when no file form was asked for.

    """
    if args.from_file is None:
        return None
    return args.state or args.from_file.with_name(args.from_file.name + ".vlogstate")


def _stdin_lines(stdin: TextIO | None) -> Iterable[str]:
    return sys.stdin if stdin is None else stdin


def _produce(
    args: Args, stdin: TextIO | None, take: Callable[[str], None]
) -> tuple[int, vlogforms.Chunk | None]:
    """Feed lines to `take` from the chosen form.

    Returns:
        the producer's status in the wrapper form (else 0), and the chunk read in the file form.

    """
    state = _state_of(args)
    if args.command:
        return vlogforms.run_wrapped(args.command, take), None
    if args.from_file is not None and state is not None:
        chunk = vlogforms.read_from_offset(args.from_file, state)
        for line in chunk.lines:
            take(line)
        return 0, chunk
    for line in _stdin_lines(stdin):
        take(line)
    return 0, None


def drain_class(reason: str) -> int:
    """Name the class of a drain that left lines behind, as an exit status (W1214).

    ⚑ THE CLASS TELLS A UNIT WHAT TO DO ABOUT IT: no destination (the service or its resolver is
    not configured or not answering: 3), refused (the endpoint answered and said no: 4), busy
    (another drainer holds the spool, which is transient and not a fault: 5). Lines left with no
    reason at all stay 1.

    Returns:
        the exit status for the class.

    """
    if reason.startswith("no destination"):
        return EXIT_NO_DESTINATION
    if reason.startswith("busy"):
        return EXIT_BUSY
    return EXIT_REFUSED if reason else 1


def _drain_now(config: vlogship.Config) -> int:
    """Send the spool in front and print what happened.

    ⚑ THE REASON GOES TO STANDARD ERROR TOO: a unit that keeps only the exit status and the error
    stream (luthen's journal said only "exit 1" until it let the output through) now has the drain's
    own words beside a status that names the class.

    Returns:
        0 when nothing is left, else the class of why (`drain_class`).

    """
    done = vlogship.drain_all(config)
    report: dict[str, object] = {"sent": done.sent, "left": done.left, "reason": done.reason}
    sys.stdout.write(json.dumps(report) + "\n")
    if done.left == 0:
        return 0
    sys.stderr.write(f"mikemol-vlog: {done.left} lines left: {done.reason or 'no reason given'}\n")
    return drain_class(done.reason)


def _config_of(args: Args) -> vlogship.Config | str:
    """Merge the flags over the config file, with the chosen source's table laid over the top.

    Returns:
        the shipper config, or the reason the source or its policy cannot be used.

    """
    table = vlogconfig.merged_table(vlogconfig.read_toml(args.config), args.source)
    if isinstance(table, str):
        return table
    flags = vlogconfig.Flags(
        args.service,
        args.resolver_arg,
        args.spool_dir,
        args.max_lines,
        args.max_bytes,
        args.source,
    )
    return vlogconfig.build(table, flags)


def _prepare(
    args: Args,
) -> tuple[dict[str, str], vlogrecord.FieldMap, vlogship.Config] | str:
    """Read the stream pairs, the line stamp and the config, or say what is wrong with them.

    Returns:
        the streams, the field map and the shipper config; or the usage message.

    """
    streams = vlogconfig.streams_of(args.stream or [])
    if streams is None:
        return "--stream wants KEY=VALUE"
    line_stamp = None
    if args.stamp:
        found = vlogconfig.stamp_named(vlogconfig.read_toml(args.config), args.stamp)
        if isinstance(found, str):
            return found
        line_stamp = found
    config = _config_of(args)
    if isinstance(config, str):
        return config
    if config.on_full == vlogship.HOLD and args.from_file is None and not args.drain:
        return HOLD_NEEDS_A_FILE
    if args.follow and (args.from_file is None or args.command):
        return FOLLOW_NEEDS_A_FILE
    how = vlogrecord.FieldMap(args.message_key, args.time_key, args.unit, line_stamp=line_stamp)
    return streams, how, config


def _pass(
    args: Args,
    stdin: TextIO | None,
    ready: tuple[dict[str, str], vlogrecord.FieldMap, vlogship.Config],
    spawn: Spawn,
) -> tuple[int, bool]:
    """Run one pass: read the chosen form, spool it, commit the consumed prefix, start the drainer.

    Returns:
        the producer's status (0 outside the wrapper form) and whether the spool was at its
        ceiling, so lines were left in the file.

    """
    streams, how, config = ready
    batcher = vlogbatch.Batcher(streams, how, config, _now)
    code, chunk = _produce(args, stdin, batcher.take)
    batcher.flush()
    state = _state_of(args)
    if chunk is not None and state is not None:
        vlogforms.commit(state, vlogforms.prefix_of(chunk, batcher.consumed))
    if not args.no_drain:
        spawn(vlogdetach.drain_argv(config))
    return code, batcher.blocked


def _follow(
    args: Args,
    ready: tuple[dict[str, str], vlogrecord.FieldMap, vlogship.Config],
    spawn: Spawn,
) -> int:
    """Pass over the file whenever it changes, for as long as the unit runs (W1817).

    Returns:
        0 once stopped (only a test stops it; a unit is ended by its signal).

    """
    path = args.from_file
    if path is None:
        return EXIT_USAGE

    def step() -> bool:
        return _pass(args, None, ready, spawn)[1]

    def pause() -> None:
        time.sleep(args.follow_period)

    vlogfollow.follow(step, path, pause)
    return 0


def main(
    argv: Sequence[str] | None = None,
    stdin: TextIO | None = None,
    spawn: Spawn = vlogdetach.spawn_detached,
) -> int:
    """Run `mikemol-vlog`.

    Returns:
        the producer's status in the wrapper form; 0 once lines are spooled; 1 when `--drain` left
        lines behind; 2 for a usage error.

    """
    args = _parser().parse_args(list(sys.argv[1:] if argv is None else argv), namespace=Args())
    ready = _prepare(args)
    if isinstance(ready, str):
        sys.stderr.write(f"mikemol-vlog: {ready}\n")
        return EXIT_USAGE
    if args.drain:
        return _drain_now(ready[2])
    if args.follow:
        return _follow(args, ready, spawn)
    code, blocked = _pass(args, stdin, ready, spawn)
    if args.exit_classes and blocked and code == 0:
        sys.stderr.write("mikemol-vlog: the spool is at its ceiling; the rest stays in the file\n")
        return EXIT_HELD
    return code
