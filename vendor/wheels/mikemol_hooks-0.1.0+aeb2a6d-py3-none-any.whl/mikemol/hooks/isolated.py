# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol
"""Commit in a private index, gated on a snapshot of the tree that lands (mtools:W902, W891).

`git commit -- <paths>` is an `--only` commit: git takes `.git/index.lock` for the WHOLE run, hooks
included, so a peer's `git add` fails for the minutes a gate takes, and the gate's
worktree-equals-index precondition refuses on ANOTHER session's unstaged files. Both are one defect:
the gate ran on the shared working tree and the shared index. This gates the tree that lands.

    1. a PRIVATE index (`<git dir>/mtools/commit.index`): `read-tree HEAD`, then `add -A -- paths`
       from the real working tree, then `write-tree`. The real index is never written to build it.
    2. the tree is materialized at the repo's FIXED snapshot path (`snapshot.Snapshot`), under its
       flock, so bazel's output base stays warm (operator 2026-10-06).
    3. `git commit` runs with GIT_DIR the real repository, GIT_WORK_TREE the snapshot and
       GIT_INDEX_FILE the private index, from inside the snapshot. The repo's own hooks run
       unchanged and see a worktree equal to the index; HEAD of the real repository moves.
    4. the real index is told afterwards (`reset -q -- paths`, a momentary lock) so the committed
       paths read as committed, not as a staged reversal.

W901 measured each claim on real git (`hooks/tests/test_isolated_commit.py`).

CONSUMED BY: `commit_kata.isolated_commit`, the `mikemol-commit` mode `MIKEMOL_COMMIT_ISOLATED=1`.
"""

import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from mikemol.hooks.snapshot import Snapshot
from mikemol.hooks.strayworktree import repair as _repair_worktree


class Done(Protocol):
    """What a finished git command shows: `runproc.Result` fits."""

    returncode: int
    stdout: str
    stderr: str


EnvRunner = Callable[[Sequence[str], Mapping[str, str], Path], Done]
"""Run one git command: its arguments, the environment to add, and the directory to run in."""


REFRESH_ATTEMPTS = 4
"""How many times the real index's reset is tried before the verdict says it was not refreshed."""

REFRESH_PAUSE_S = 2.0
"""The wait between attempts: long enough for a peer's momentary index lock to clear."""


def _failed(done: Done) -> bool:
    return done.returncode != 0


def exact_files(root: Path, paths: Sequence[str]) -> list[str]:
    """Pick the paths the caller named exactly: a regular file, never a link or a directory.

    ⚑ BY INTENT, NOT BY TRACKING (W1039). A re-vendor writes new sha-named wheels under a directory
    that ignores everything; they are untracked AND ignored, and a plain `add` refuses them. A file
    the caller names is theirs to add; what a directory expands to is not, so an ignored scratch
    file cannot ride in. A link is refused as data (no-symlinks ruling), so it is never forced.

    Returns:
        the named paths that exist as regular files, in the order given.

    """
    return [p for p in paths if (root / p).is_file() and not (root / p).is_symlink()]


def add_argv_list(root: Path, paths: Sequence[str]) -> list[list[str]]:
    """Plan the `git add` calls for `paths`: the exact files forced, then the rest as before.

    Returns:
        the argument lists (after `git`), the forced add first when there is anything to force.

    """
    forced = exact_files(root, paths)
    rest = [p for p in paths if p not in forced]
    plan = [["add", "-f", "--", *forced]] if forced else []
    if rest:
        plan.append(["add", "-A", "--", *rest])
    return plan


def refresh_index(root: Path, paths: Sequence[str], run: EnvRunner) -> str:
    """Bring the real index to HEAD for the committed `paths`, and say whether it worked (W1108).

    ⚑ A FAILED REFRESH WAS SILENT. The `reset` takes the index lock for a moment, and a peer's raw
    commit or `git add` holding it made the reset fail with nothing said: the real index stayed at
    the old HEAD, the committed paths read as staged reversals, and a plain `git commit` after it
    would have committed them (nemik:W428 measured a stale index; a host flush staged deletions of
    tracked files). So it retries, then CHECKS that no committed path differs from HEAD in the
    index, and the verdict says which. Only the committed paths are touched; other staged work is
    left as it was.

    Returns:
        one line: what was refreshed, or that it was not and the command to run.

    """
    done = run(["reset", "-q", "--", *paths], {}, root)
    for _attempt in range(REFRESH_ATTEMPTS - 1):
        if not _failed(done):
            break
        time.sleep(REFRESH_PAUSE_S)
        done = run(["reset", "-q", "--", *paths], {}, root)
    left = run(["diff", "--cached", "--name-only", "--", *paths], {}, root)
    stale = left.stdout.split()
    if _failed(done) or _failed(left) or stale:
        why = done.stderr.strip() or left.stderr.strip() or "paths still differ from HEAD"
        return (
            f"real index NOT refreshed for {', '.join(stale) or 'the committed paths'} ({why}); "
            f"run: git reset -q -- {' '.join(paths)}"
        )
    return f"real index refreshed to HEAD for {len(paths)} committed path(s)"


def _restore(root: Path, paths: Sequence[str], run: EnvRunner) -> Done:
    """Restore `paths` to HEAD in the working tree, trying again while git refuses.

    ⚑ `git restore --worktree` TAKES THE INDEX LOCK TO REFRESH THE INDEX, so a peer's git, a second
    landing or a host apply pass holding it makes the restore FAIL; refresh_tree filed that failure
    with the files someone had edited and printed nothing of git's reason (luthen-observability
    W1880: six stale copies, the last one named only 'differs from HEAD and was left'). So it
    retries as `refresh_index` does, and the caller names what still failed.

    Returns:
        git's last answer: success, or the failure that outlasted the attempts.

    """
    argv = ["restore", "--source=HEAD", "--worktree", "--", *paths]
    done = run(argv, {}, root)
    for _attempt in range(REFRESH_ATTEMPTS - 1):
        if not _failed(done):
            break
        time.sleep(REFRESH_PAUSE_S)
        done = run(argv, {}, root)
    return done


def _leftover(root: Path, path: str, start: str, run: EnvRunner) -> str | None:
    """Judge a working file the landing deleted from HEAD (luthen-observability:W2334).

    ⚑ `git diff HEAD -- path` IS BLIND TO IT: the file is absent at HEAD, so the leftover working
    copy is untracked and the diff exits 0, which `refresh_tree` read as "already equal" and
    moved on from, leaving a tree a gate would read as holding a file HEAD no longer has.

    ⚑ THE BYTES ARE HASHED RAW AND A LINK IS NEVER READ THROUGH (github-14's cold BLOCK of
    42b23583). `hash-object` applies the repository's eol and clean filters unless told not to, so
    under `text eol=crlf` a leftover with a carriage return hashed equal to the deleted file and
    was unlinked; and `is_file()` follows a link, so a link to a file with those bytes was
    deleted. Neither is byte-identical to what the landing removed, so neither is ours to delete.

    Returns:
        None when the path is at HEAD or is no file in the working tree (the ordinary judgement
        applies); "same" when HEAD lacks it and the working file is a regular file holding the
        raw bytes of `start` (nobody edited it: remove it); "differs" for anything else, a link
        included.

    """
    if run(["cat-file", "-e", f"HEAD:{path}"], {}, root).returncode == 0:
        return None
    if (root / path).is_symlink():
        return "differs"
    if not (root / path).is_file():
        return None
    mine = run(["hash-object", "--no-filters", "--", path], {}, root)
    then = run(["rev-parse", "--verify", "--quiet", f"{start}:{path}"], {}, root)
    same = mine.returncode == 0 and then.returncode == 0 and mine.stdout == then.stdout
    return "same" if same else "differs"


def refresh_tree(root: Path, paths: Sequence[str], start: str, run: EnvRunner) -> str | None:
    """Bring the main tree's working copies of landed paths to HEAD, losing no one's edit.

    ⚑ A STACK FROZEN FROM ANOTHER DIRECTORY (`--freeze-from`, W2103) LEAVES THE MAIN TREE'S COPIES
    AT THE OLD BYTES (luthen-observability:W1857, measured: a 2-file stack committed as 17654019,
    the index refreshed, the main working files still the pre-fix bytes and ` M` against the new
    HEAD, the diff exactly the fix reversed). A path is judged by what the working file equals:
    HEAD already (the stack was built here: nothing to do), the old HEAD `start` (nobody edited it:
    restored to HEAD), or something else (someone's edit: left alone and named).

    Returns:
        None when every path already equals HEAD; else one line saying which were restored and
        which differ and were left.

    """
    restored: list[str] = []
    differ: list[str] = []
    failed: list[str] = []
    for path in paths:
        leftover = _leftover(root, path, start, run)
        if leftover == "same":
            (root / path).unlink()
            restored.append(path)
            continue
        if leftover == "differs":
            differ.append(path)
            continue
        if run(["diff", "--quiet", "HEAD", "--", path], {}, root).returncode == 0:
            continue
        if run(["diff", "--quiet", start, "--", path], {}, root).returncode == 0:
            done = _restore(root, [path], run)
            if _failed(done):
                reason = (done.stderr.strip().splitlines() or ["no message"])[0]
                failed.append(f"{path} (git said: {reason})")
            else:
                restored.append(path)
        else:
            differ.append(path)
    if not restored and not differ and not failed:
        return None
    said = [f"working copy restored to HEAD for {', '.join(restored)}"] if restored else []
    if failed:
        said.append(f"⚑ working copy could not be restored for {', '.join(failed)}")
    if differ:
        said.append(f"working copy differs from HEAD and was left for {', '.join(differ)}")
    return "; ".join(said)


def stale_tree(root: Path, paths: Sequence[str], start: str, run: EnvRunner) -> str | None:
    """Find landed paths whose working copy went back to the pre-landing bytes, and restore them.

    ⚑ `refresh_tree` JUDGES ONCE, RIGHT AFTER THE REF MOVES, AND THE LANDING THEN KEEPS GOING: the
    post-commit hook pushes, and a second landing or a host apply pass can write the old bytes back
    in that window (luthen-observability:W1880, five landings, each stale file exactly the stack's
    start commit's bytes). So this runs AFTER the hook, on the same rule: a copy that differs from
    HEAD and equals `start` is bytes nobody edited, and is restored again and named, with the
    source of the bytes, so the landing's own output says it happened.

    Returns:
        None when no landed path holds the start commit's bytes; else one line naming them and
        whether they were restored.

    """
    back = [
        path
        for path in paths
        if run(["diff", "--quiet", "HEAD", "--", path], {}, root).returncode != 0
        and run(["diff", "--quiet", start, "--", path], {}, root).returncode == 0
    ]
    if not back:
        return None
    fixed = _restore(root, back, run)
    action = "NOT restored" if _failed(fixed) else "restored again"
    return (
        f"working copy of {', '.join(back)} held the start commit's bytes AFTER the landing "
        f"(something wrote them back) and was {action}"
    )


@dataclass(frozen=True)
class Plan:
    """What an isolated commit takes: files read from the tree, and blobs frozen at submit.

    ⚑ `placed` ARE THE `update-index` CALLS THAT PUT FROZEN BLOBS INTO THE PRIVATE INDEX (W2120): a
    plain commit that was frozen at submit places those bytes, so an edit of its paths in the main
    tree between submit and the gate cannot ride in under its name. `paths` are then only what is
    still read from the tree (the queue files); with none placed it is the whole request.
    """

    paths: Sequence[str]
    placed: Sequence[Sequence[str]] = ()


def commit_isolated(
    root: Path,
    paths: Sequence[str],
    message: str,
    run: EnvRunner,
    namespace: Path,
) -> Done:
    """Commit `paths` of `root` through a private index and a snapshot of the resulting tree.

    Returns:
        the `git commit` process; or the first step's process that failed before it.

    """
    return commit_planned(root, Plan(paths), message, run, namespace)


def commit_planned(
    root: Path,
    plan: Plan,
    message: str,
    run: EnvRunner,
    namespace: Path,
) -> Done:
    """Commit a plan through a private index and a snapshot of the resulting tree.

    Returns:
        the `git commit` process; or the first step's process that failed before it.

    """
    gitdir = run(["rev-parse", "--absolute-git-dir"], {}, root)
    if _failed(gitdir):
        return gitdir
    git_dir = Path(gitdir.stdout.strip())
    index = git_dir / "mtools" / "commit.index"
    index.parent.mkdir(parents=True, exist_ok=True)
    index.unlink(missing_ok=True)
    scope = {"GIT_DIR": str(git_dir), "GIT_INDEX_FILE": str(index)}
    read = run(["read-tree", "HEAD"], scope, root)
    tracked_tree = {**scope, "GIT_WORK_TREE": str(root)}
    frozen = [run(list(argv), scope, root) for argv in plan.placed]
    tree_adds = add_argv_list(root, plan.paths)
    adds = [*frozen, *(run(argv, tracked_tree, root) for argv in tree_adds)]
    tree = run(["write-tree"], scope, root)
    for step in (read, *adds, tree):
        if _failed(step):
            return step
    with Snapshot(root.name, namespace) as snap:
        snap.materialize(root, tree.stdout.strip())
        # ⚑ THE GATE'S TOOLS ARE HOST STATE (W939): `<dist>/.venv` is a uv venv in the real
        # checkout, not a build output the snapshot can regrow (the bazel `.venv` holds python3
        # only), so the hook is told where the real checkout is and reads its tools there; the
        # TREE it gates is still the index's.
        work = {**scope, "GIT_WORK_TREE": str(snap.path), "MIKEMOL_REAL_ROOT": str(root)}
        refreshed = run(["update-index", "-q", "--refresh"], work, snap.path)
        if _failed(refreshed):
            return refreshed
        # ⚑ THE TREE THE GATE JUDGED IS NAMED IN THE COMMIT (W1666, nemik:W703): the index's tree is
        # the one the snapshot materialized and the hook ran on, so the trailer joins the message's
        # own trailer block and a reader can ask whether a commit's gate ran on what it holds.
        stamped = f"{message.rstrip()}\nGated-Tree: {tree.stdout.strip()}\n"
        done = run(["commit", "-m", stamped], work, snap.path)
    # ⚑ A STEP THAT RAN UNDER THE EXPORTED GIT_DIR AND GIT_WORK_TREE MAY HAVE WRITTEN
    # `core.worktree` INTO THE REAL CONFIG (W2269): `_repair_worktree` removes it and returns the
    # line saying so (newline-terminated), or nothing.
    done.stdout = f"{done.stdout}gated-tree: {tree.stdout.strip()}\n{_repair_worktree(root, run)}"
    if not _failed(done):
        note = refresh_index(root, plan.paths, run)
        done.stdout = f"{done.stdout}{note}\n"
    return done
