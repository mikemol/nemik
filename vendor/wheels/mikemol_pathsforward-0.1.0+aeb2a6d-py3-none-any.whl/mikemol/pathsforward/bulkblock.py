# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol
"""Block every open card that carries one `touches` tag on a single card (mtools:W947).

⚑ A QUEUE WRITER THAT BLOCKS ONE CARD AT A TIME CANNOT MOVE A POPULATION. About 190 per-file
"typing: FILE (N findings)" cards across four repos all said "whole-file Write by hand"; each repo
has one mechanization card they wait on, and the writer had no way to say so once.

⚑ ONLY A READY CARD IS MOVED. A card already blocked keeps the blocker it has (a second one would
hide the first), a working card is somebody's current job, and a done or dropped card is not open;
the first two are LISTED with the reason, so a dry run shows what the write will leave alone.
The target itself is never blocked on itself.
"""

from dataclasses import dataclass

from mikemol.pathsforward.model import RefusedError, State, strlist, text

_AGENT = "agent"
_CLOSED = frozenset({"", "done", "dropped"})


@dataclass(frozen=True)
class Plan:
    """What a bulk block moves and what it leaves alone."""

    moved: tuple[str, ...]
    kept: tuple[tuple[str, str], ...]


def plan(state: State, tag: str, target: str) -> Plan:
    """Decide which cards carrying `tag` would be blocked on `target`, without changing anything.

    A target with a colon (`repo:W<n>`) is another queue's card and is taken as given; a bare one
    must be an open card of this queue.

    Returns:
        the ready cards that move and the open ones that stay, each with its reason.

    Raises:
        RefusedError: when the tag matches nothing, or a local target is not an open card.

    """
    by_symbol = {text(w, "symbol"): w for w in state.waypoints}
    if ":" not in target and text(by_symbol.get(target, {}), "status") in _CLOSED:
        msg = f"{target} is not an open card of this queue"
        raise RefusedError(msg)
    moved: list[str] = []
    kept: list[tuple[str, str]] = []
    for w in state.waypoints:
        sym = text(w, "symbol")
        status = text(w, "status")
        if tag not in strlist(w, "touches") or sym == target or status in _CLOSED:
            continue
        if status == "ready":
            moved.append(sym)
        else:
            blockers = ",".join(strlist(w, "blocked_on"))
            kept.append((sym, f"{status} on {blockers}" if blockers else status))
    if not moved and not kept:
        msg = f"no open card carries the touches tag {tag!r}"
        raise RefusedError(msg)
    return Plan(tuple(moved), tuple(kept))


def freeze_plan(state: State, ask: str) -> Plan:
    """Decide which cards a freeze would block on `ask`, without changing anything (W1397).

    ⚑ A FROZEN WORKSTREAM WAITS ON ONE ASK, SO THE WORK ORDER FOLLOWS THE OPERATOR'S ANSWER. Every
    ready AND working card moves (a frozen repo has no session holding a working card); a card
    already blocked keeps the blocker it has, so the ask is never stacked on top of a real wait. The
    ask itself is never moved, and unfreezing is the ask going done plus `--prune-landed`.

    Returns:
        the ready and working cards that move and the blocked ones that stay, each with its reason.

    Raises:
        RefusedError: when the ask is not an open card of this queue, or nothing is left to move.

    """
    by_symbol = {text(w, "symbol"): w for w in state.waypoints}
    if text(by_symbol.get(ask, {}), "status") in _CLOSED:
        msg = f"{ask} is not an open card of this queue"
        raise RefusedError(msg)
    moved: list[str] = []
    kept: list[tuple[str, str]] = []
    for w in state.waypoints:
        sym = text(w, "symbol")
        status = text(w, "status")
        if sym == ask or status in _CLOSED:
            continue
        if status in {"ready", "working"}:
            moved.append(sym)
        else:
            kept.append((sym, f"{status} on {','.join(strlist(w, 'blocked_on'))}"))
    if not moved and not kept:
        msg = f"no open card besides {ask} to freeze"
        raise RefusedError(msg)
    return Plan(tuple(moved), tuple(kept))


UNSCORED = "unscored"
UNMANIFESTED = "unmanifested"
OPEN = "open"


def select_symbols(
    state: State, names: list[str], excluded: dict[str, str] | None = None
) -> list[str]:
    """Expand the operands of a bulk update into waypoint symbols, in the order given.

    ⚑ AN OPERAND IS A SYMBOL OR A SELECTOR (mtools:W974, el-openglo:W484). `unscored` selects every
    live waypoint with no vector, which is the mechanical scoring pass el-openglo needed 24 calls
    for. `open` selects every card not done (W1154), so a goal's edges are one command. A symbol
    that is not a card of this queue is refused by name before anything is changed.

    ⚑ AN EXCLUSION IS A SYMBOL OF THIS QUEUE, REFUSED OTHERWISE: a typo would silently exclude
    nothing. The caller prints each exclusion with its reason.

    Returns:
        the symbols, de-duplicated, selector expansions in queue order, without the excluded.

    Raises:
        RefusedError: when an operand is neither a selector nor a symbol of this queue, or an
            excluded symbol is not a card of this queue.

    """
    known = {text(w, "symbol") for w in state.waypoints}
    skipped = excluded or {}
    for sym in skipped:
        if sym not in known:
            msg = f"--except {sym} is not a waypoint of this queue"
            raise RefusedError(msg)
    chosen: list[str] = []
    for name in names:
        if name == UNSCORED:
            found = [
                text(w, "symbol")
                for w in state.waypoints
                if text(w, "status") != "done" and not text(w, "vector")
            ]
        elif name == UNMANIFESTED:
            found = [
                text(w, "symbol")
                for w in state.waypoints
                if text(w, "status") == "ready" and not strlist(w, "manifest")
            ]
        elif name == OPEN:
            found = [text(w, "symbol") for w in state.waypoints if text(w, "status") != "done"]
        elif name in known:
            found = [name]
        else:
            selectors = f"{UNSCORED}, {OPEN}, {UNMANIFESTED}"
            msg = f"{name} is neither a waypoint of this queue nor a selector ({selectors})"
            raise RefusedError(msg)
        chosen.extend(s for s in found if s not in chosen and s not in skipped)
    return chosen


def apply(state: State, found: Plan, target: str) -> None:
    """Block each moved card on `target`, as `--update` would: agent kind, count restarted."""
    moving = set(found.moved)
    for w in state.waypoints:
        if text(w, "symbol") in moving:
            w["status"], w["blocked_on"] = "blocked", [target]
            w["blocked_kind"], w["ticks_blocked"] = _AGENT, 0
