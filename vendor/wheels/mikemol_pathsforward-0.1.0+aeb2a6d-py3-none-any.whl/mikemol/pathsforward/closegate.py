# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol
"""Refuse to close a tick while a ready, unblocked card exists, unless the close names the block.

W1203. ⚑ A TICK IS A LOOP CYCLE, NOT A CARD (operator, 2026-10-14). A session that closed after one
card, with dozens ready, was not blocked; it chose to stop. A reminder in a memory is the weakest
layer, so the closing verb reads the queue itself: while any card is READY and not waiting behind
an open enabler, `--tick-close` REFUSES (the lock stays held, so the stop hook keeps asking) unless
the close says what the real block is:

    --blocked-by W<n>   a card that exists, is not done and is not the card the tick worked
    --reason TEXT       free text that names such a card, or a peer's `repo:W<n>`

Either is ledgered with the close. A bare close with ready cards is refused; a close with none is
unchanged. Every close prints the ready count and the top three, so the figure is always in front
of the session that is about to stop.

⚑ A SELF-CITATION IS NOT A BLOCK (github-8f, 2026-10-15, W1247): a gate or suite running for the
card just worked does not stop the other ready cards; it is when to start the next one.

⚑ THE TOP CARD BY RANK IS NOT SKIPPED IN SILENCE (W1368, nemik:W580): given `--rank-from FILE`
(nemik-rank --json for this repo, read as data), a close that would pass is also refused when the
top ranked card is ready and unblocked here but is neither the card worked nor named by
`--blocked-by` or `--reason`. Without the file there is no such refusal; the rule only ever adds to
the check above.

⚑ READY MEANS WORKABLE: a witnessed card (its evaluator, not a mind, marks it done) and a card
behind an open enabler are not counted, the same sets `--block-behind-open` and the ranker use.

CONSUMED BY: `cli._tick_close` (and the katas `tick end`, W1202).
"""

import re
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from itertools import pairwise
from pathlib import Path
from typing import cast

from mikemol.pathsforward import inflight, lock
from mikemol.pathsforward.behindopen import plan
from mikemol.pathsforward.landed import landed_since, landing_times
from mikemol.pathsforward.ledger import Parsed, read
from mikemol.pathsforward.model import State, strlist, text, workable

SYMBOL = re.compile(r"\bW\d+\b")
FOREIGN = re.compile(r"[\w-]+:W\d+")
FRESH = re.compile(
    r"fresh (?:claude (?:code )?)?(?:session|context)|more context|new session",
    re.IGNORECASE,
)
TOP = 3
TICK_SYMBOL = 2
IDLE_WINDOW = 50
SESSION = re.compile(r"\bsession=(\S+)")


def landing_bound(times: Sequence[float]) -> float | None:
    """Learn how long this repository goes between landings, from its own landing times (W2047).

    ⚑ NO TYPED THRESHOLD: the bound is the LARGEST gap between consecutive landings among the times
    given, so a card idle longer than the repository has ever gone without landing anything is
    idle by its own record, not by a number someone chose.

    Returns:
        the largest gap in seconds, or None when fewer than two landings are known.

    """
    gaps = [later - earlier for earlier, later in pairwise(sorted(times))]
    return max(gaps) if gaps else None


def idle_cards(state: State, now: datetime, bound: float | None) -> list[str]:
    """Name each working card whose last work is older than the learned bound (W2047).

    Returns:
        the symbols of working cards stamped before `now` minus `bound` seconds, in queue order;
        empty with no bound, and a working card with no readable stamp is not named.

    """
    if bound is None:
        return []
    named: list[str] = []
    for card in state.waypoints:
        stamp = text(card, "last_worked")
        if text(card, "status") != "working" or not stamp:
            continue
        try:
            worked = datetime.fromisoformat(stamp).astimezone(UTC)
        except ValueError:
            continue
        if (now - worked).total_seconds() > bound:
            named.append(text(card, "symbol"))
    return named


@dataclass(frozen=True)
class Verdict:
    """What the close may do: refused or not, what to print, and what to ledger."""

    refused: bool
    lines: tuple[str, ...]
    note: str


def ready_cards(state: State) -> list[str]:
    """List the symbols of the ready, workable cards that wait behind no open enabler.

    Returns:
        the symbols, in queue order.

    """
    found = plan(state)
    behind = {sym for sym, _ in found.moved} | {sym for sym, _ in found.mutual}
    return [
        text(w, "symbol")
        for w in state.waypoints
        if text(w, "status") == "ready" and workable(w) and text(w, "symbol") not in behind
    ]


def open_line(state: State) -> str:
    """Spell the line `--tick-open` prints beside the claim and nudge lines (W2038).

    ⚑ A QUIET OPEN READ AS "NOTHING TO DO" (github-8f 2026-10-26: nemik ended a tick on "found
    nothing to claim, no nudges due" with a band of ready cards). The ready count and the top
    cards, a velocity card marked `*`, are said where the session reads the claim lines.

    Returns:
        `ready N; take them: W1, W2* (* velocity)` in queue order, or `ready 0` with none.

    """
    ready = ready_cards(state)
    if not ready:
        return "ready 0"
    marked = {text(w, "symbol"): "velocity" in strlist(w, "touches") for w in state.waypoints}
    top = ", ".join(f"{sym}{'*' if marked.get(sym) else ''}" for sym in ready[:TOP])
    return f"ready {len(ready)}; take them: {top} (* velocity)"


def tick_start(state: State, ledger: Path | None) -> str:
    """Name when this tick began: the previous tick's close, else the lock's own time.

    ⚑ THE LOCK'S TIME IS NOT THE TICK'S START (github-8f, 2026-10-15): a host `tick end` takes the
    lock only at the close, so everything done before it predates `taken_at` and counted as
    nothing. The ledger's last `tick` line is when the previous tick closed, and a card worked
    after it belongs to this one.

    Returns:
        a UTC stamp, or "" when neither a tick line nor a lock time exists.

    """
    stamps = [
        found.stamp
        for found in (read(ledger) if ledger is not None and ledger.is_file() else [])
        if isinstance(found, Parsed)
        and found.entry.kind == "tick"
        and found.entry.outcome != "minted"
    ]
    if stamps:
        return stamps[-1]
    held = lock.current(state)
    return held[1] if held else ""


def touched(state: State, since: str) -> set[str]:
    """Name the cards a queue edit stamped since `since`: worked, finished or dropped.

    ⚑ A ONE-CARD TICK SHOWS IN ITS OWN OUTPUT: `last_worked` is stamped on every work update
    (a done transition included), and a dropped card leaves the queue for the residue with a
    `dropped_at`, so both are counted. The stamps are the writer's UTC strings and compare as
    strings.

    Returns:
        the distinct symbols, empty when `since` is empty.

    """
    if not since:
        return set()
    worked = {text(w, "symbol") for w in state.waypoints if text(w, "last_worked") >= since}
    dropped = {text(r, "symbol") for r in state.residue if text(r, "dropped_at") >= since}
    return worked | dropped


def advanced(state: State, since: str, landed: set[str] | None = None) -> int:
    """Count the cards advanced since `since`: those a landed commit carries (W1377).

    ⚑ AN EDIT IS NOT AN ADVANCE: with the symbols of the commits since the tick began, only a
    touched card some commit carries counts, so one bulk call that unblocked 130 cards no longer
    reads as 130 advanced. With `landed` None (no git to ask) every touched card counts, as before.

    Returns:
        the number of distinct cards, 0 when `since` is empty.

    """
    stamped = touched(state, since)
    return len(stamped if landed is None else stamped & landed)


def _named(state: State, blocked_by: str | None, reason: str | None, worked: str | None) -> str:
    """Say what block the close names, or why it names none.

    ⚑ EIGHT TICKS CLOSED "the suite is running and the <card> commit follows it", citing the card
    they had just worked. The accepted blocks are an open card that is NOT the one worked, or a
    foreign `repo:W<n>` (a peer's card, a named external wait). A done card is no block either.

    Returns:
        the note to ledger, or "" when the close names no real block.

    """
    live = {
        text(w, "symbol")
        for w in state.waypoints
        if text(w, "status") != "done" and text(w, "symbol") != worked
    }
    if blocked_by is not None and blocked_by in live:
        return f"blocked by {blocked_by}"
    said = reason or ""
    foreign = cast("list[str]", FOREIGN.findall(said))
    # ⚑ A READY CARD IS WORK, NOT A BLOCK (W2688, amr-skills W402): a reason that cites only a card
    # the tick could have worked, such as the top card the close was refused for, blocks nothing.
    workable = set(ready_cards(state))
    cited = [
        s
        for s in cast("list[str]", SYMBOL.findall(FOREIGN.sub("", said)))
        if s in live and s not in workable
    ]
    named = [*foreign, *cited]
    return f"reason: {reason} (cites {', '.join(named)})" if named else ""


def top_ranked(raw: object) -> str | None:
    """Read the top card's symbol off a `nemik-rank --json` document.

    ⚑ THE DOCUMENT IS DATA: a list of records, best first, each with a string `symbol`. The first
    record's symbol is the top; nothing else in it is read, so a new field cannot change it.

    Returns:
        the symbol, or None for an empty list.

    Raises:
        TypeError: when the document is not a list.
        ValueError: when its first record carries no string symbol.

    """
    if not isinstance(raw, list):
        msg = "a rank file is a JSON list of records, best first"
        raise TypeError(msg)
    records = cast("list[object]", raw)
    if not records:
        return None
    first = records[0]
    symbol = cast("dict[str, object]", first).get("symbol") if isinstance(first, dict) else None
    if not isinstance(symbol, str) or not symbol:
        msg = "the first record of a rank file has no string symbol"
        raise ValueError(msg)
    return symbol


def rank_check(
    verdict: Verdict,
    state: State,
    top: str | None,
    named: tuple[str | None, str | None, str | None],
) -> Verdict:
    """Add the rank rule to a close that would otherwise pass (W1368).

    ⚑ ONLY A CARD THAT COULD HAVE BEEN WORKED COUNTS: a top card that is blocked, done or behind an
    open enabler is not ready here, so it is not skipped. The worked card, a `--blocked-by` card
    and any card the `--reason` cites are the three ways a close accounts for the top card.

    Returns:
        the verdict unchanged when it already refused or the top card is accounted for, else a
        refusal naming the top card and the `--reason` to give.

    """
    blocked_by, reason, worked = named
    if verdict.refused or top is None or top not in ready_cards(state):
        return verdict
    cited = cast("list[str]", SYMBOL.findall(reason or ""))
    if top in {worked, blocked_by} or top in cited:
        return verdict
    why = (
        f"REFUSED: the top card by nemik rank is {top}, ready and unblocked, and this close "
        f'neither worked nor names it: work it, or give --reason "{top}: <why it waits>"'
    )
    return Verdict(refused=True, lines=(*verdict.lines, why), note="")


def roll_note(state: State, ledger: Path | None) -> str:
    """Say how many cards this tick advanced, for the ledger line of a roll (W1589).

    ⚑ A ROLL IS ALWAYS ALLOWED AND NEVER HIDES A STALL (github-8f, 2026-10-18): it is a cycle
    boundary, not a stop, so it takes no named block and no threshold; the count of cards the tick
    advanced goes into its line, so a roll that advanced nothing reads `advanced 0`.

    Returns:
        `rolled; advanced N`, N being the cards a landed commit carried (every touched card when
        git cannot be asked, as the close counts).

    """
    since = tick_start(state, ledger)
    landed = None if ledger is None else landed_since(ledger.parent.parent, since)
    return f"rolled; advanced {advanced(state, since, landed)}"


def handoff_line(ledger_text: str, repo: str) -> str:
    """Name the tick the ledger just closed, as the line a reviewer hand-off pastes (W2154).

    ⚑ THE CLOSE TIME IS THE LEDGER LINE'S OWN TIMESTAMP, NOT ONE TYPED BY HAND (github:W59, the
    host typed close times wrong twice in three ticks): the last `tick` line of the ledger is the
    one the close or roll just wrote, and its first field is the time it was written.

    Returns:
        `G1-HANDOFF <repo> <symbol> closed=<timestamp> session=<id>`, or an empty string when the
        ledger holds no tick line.

    """
    for line in reversed(ledger_text.splitlines()):
        fields = line.split()
        if len(fields) > TICK_SYMBOL and fields[1] == "tick":
            found = SESSION.search(line)
            session = found.group(1) if found else "-"
            return f"G1-HANDOFF {repo} {fields[2]} closed={fields[0]} session={session}"
    return ""


def _live(ledger: Path | None) -> frozenset[str]:
    """Name the cards a queued or in-flight stack names, for the project the ledger is in.

    ⚑ A CARD MID-LANDING IS NOT AN UNLANDED EDIT (W2096, paperkit:R2): its evidence-only
    change has a gate running, so the close does not count it among 'more touched, named by
    no landed commit'.

    Returns:
        the symbols, or none when there is no ledger or the count file cannot be read.

    """
    return frozenset() if ledger is None else inflight.read(ledger.parent.parent)


def idle_note(state: State, ledger: Path | None) -> str:
    """Name the working cards idle past the repository's own landing gap (W2047).

    ⚑ A CARD A LIVE STACK NAMES IS NOT IDLE: its gate is running. The bound is the largest gap
    between the last IDLE_WINDOW landings, so nothing typed decides it.

    Returns:
        `; idle working past the landing gap: W1, W2`, or the empty string when there is no
        ledger, no readable history or no such card.

    """
    if ledger is None:
        return ""
    times = landing_times(ledger.parent.parent, IDLE_WINDOW)
    idle = idle_cards(state, datetime.now(UTC), landing_bound(times or []))
    named = [symbol for symbol in idle if symbol not in _live(ledger)]
    return f"; idle working past the landing gap: {', '.join(named)}" if named else ""


def judge(
    state: State,
    blocked_by: str | None = None,
    reason: str | None = None,
    worked: str | None = None,
    ledger: Path | None = None,
) -> Verdict:
    """Decide whether a tick may close.

    Returns:
        the verdict: the ready count and top three always, and a refusal when ready cards exist
        and the close names no block that this queue holds.

    """
    ready = ready_cards(state)
    top = ", ".join(ready[:TOP]) or "none"
    since = tick_start(state, ledger)
    landed = None if ledger is None else landed_since(ledger.parent.parent, since)
    moved = advanced(state, since, landed)
    open_edits = 0 if landed is None else len(touched(state, since) - landed - _live(ledger))
    # ⚑ THE FIGURE IS THE TOUCHED CARDS NO LANDED COMMIT NAMES, NOT "NOTHING LANDED" (W1588,
    # github-8f and nemik, 2026-10-18): nemik's close read `advanced 85; 39 touched, none landed`,
    # and the second half was taken to mean that no commit landed, when 85 cards had.
    edits = f"; {open_edits} more touched, named by no landed commit" if open_edits else ""
    idle = idle_note(state, ledger)
    count = f"ready and unblocked: {len(ready)}; top: {top}; this tick advanced {moved}{edits}"
    count += idle
    if not ready:
        return Verdict(refused=False, lines=(count,), note="")
    if FRESH.search(reason or ""):
        card = worked or "the card"
        why = f"REFUSED: a fresh session or more context is an atomize signal: atomize {card}"
        return Verdict(refused=True, lines=(count, why), note="")
    note = _named(state, blocked_by, reason, worked)
    if note:
        named = f"closing on a named block ({note})"
        return Verdict(refused=False, lines=(count, named), note=note)
    if SYMBOL.search(FOREIGN.sub("", reason or "")):
        why = (
            "REFUSED: a reason that cites the card it is about is not a block: name the card "
            "that blocks it, or work it (a card cited here that is the one worked, or is ready, "
            "blocks nothing)"
        )
        return Verdict(refused=True, lines=(count, why), note="")
    why = (
        "REFUSED: a tick is a loop cycle, not a card. "
        f"{len(ready)} ready card(s) can be worked; name the real block with "
        "--blocked-by W<n> (an open card other than the one just worked) or --reason TEXT "
        "citing one, or a peer's repo:W<n>; a gate running for the card worked is not a block"
    )
    return Verdict(refused=True, lines=(count, why), note="")


def judge_reviewing(
    state: State, reviewing: str, running: Sequence[str], ledger: Path | None = None
) -> Verdict:
    """Decide whether a tick may close while a named reviewer runs (W2038, github:W84).

    ⚑ A REVIEW IS A NAMED WAIT, NOT A CARD: `reviewing` is accepted only when `running` (the ids a
    reader of the harness's subagent transcripts finds live) holds it, so a typed name that is not
    running is no block and the close is judged as a bare one.

    Returns:
        the bare verdict when no card is ready or the reviewer is not running; otherwise an
        accepted verdict whose note is `reviewing <id>`.

    """
    bare = judge(state, ledger=ledger)
    if not bare.refused or reviewing not in running:
        return bare
    note = f"reviewing {reviewing}"
    named = f"closing on a named wait ({note})"
    return Verdict(refused=False, lines=(bare.lines[0], named), note=note)
