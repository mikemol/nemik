#!/usr/bin/env python3
"""Ζ·foot — project the per-claim dependency manifest (footprints.json) FROM the live Φ·footprints.

For each project's each checked claim, strace the check (scope = repo root) to see which files it
READS, and reduce them to the set of DEP TOKENS — the top-level units a Bazel target depends on:
`paperkit` (the engine), a sibling project dir, or `.` (a root file: .githooks, a root bib/rubric).
The check's OWN project + the engine are always needed (gate.py loads the bib; the witness lives in
one of them), so the manifest records only what is read BEYOND them — i.e. the cross-package deps
that `extra_data` used to declare by hand.  tools/bibtex.bzl reads this at fetch and emits each
check target's `data` from it; no strace at fetch (fast, deterministic).

    python3 paperkit/footdeps.py [PROJECT...]      # write footprints.json (default: the wired set)
    python3 paperkit/footdeps.py --check [PROJECT...]   # verify it is fresh, exit 1 if stale

A degraded footprint (strace absent/can't attach → None) records the sentinel ["*"] = "all
projects" (the repo rule over-declares), never a silent under-declaration.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
import tomllib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

# Ζ·pkg·shape — the engine's own directory, FIRST on sys.path, and it must stay a per-module
# line rather than moving to paperkit/__init__.py: a package __init__ runs only when the
# package is IMPORTED, and these modules are also loaded as siblings by a caller that has
# already put its own directory ahead of ours.  render/checks/ ships its OWN bib.py, so a
# witness inserting that directory shadows the engine's parser and `from bib import
# dep_order` resolves to the wrong module.  MEASURED: removing these six lines reddened
# seven talk claims with "cannot import name 'dep_order' from bib (render/checks/bib.py)".
# The insert is a PRIORITY CLAIM, not a reachability fix — __init__.py handles reachability.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bib
import resolver


def _wired(repo_root: Path) -> list:
    """The projects the footprint audit gates — DERIVED, never hardcoded (guard-must-not-copy: a hand-
    maintained list drifts, and it had: `render` was missing).  The audit applies to SANDBOX-tier
    warrants (bibtex.bzl: only sandbox is swept and footprint-audited), so WIRED = the bib.project set
    (MODULE.bazel — the ONE registry that maps project→its bib file; on-demand projects like report/image
    are not bib.projects, correctly excluded) that has at least one sandbox-tier check.  Single source:
    the tier declarations in each project's own bib.
    """
    module = (repo_root / "MODULE.bazel").read_text()
    out = []
    for m in re.finditer(r"bib\.project\([^)]*\)", module, re.S):
        proj = re.search(r'project = "([^"]+)"', m.group(0))
        bib_lbl = re.search(r'bib = "([^"]+)"', m.group(0))
        if not (proj and bib_lbl):
            continue
        bib_path = repo_root / bib_lbl.group(1).lstrip("/").replace(":", "/")
        if not bib_path.is_file():
            continue
        # consumer_fields — a declared field must be quiet HERE too, else _wired (which runs on every
        # commit via the pre-commit) loud-drops a consumer's carried field.  Route through the owner
        # (load_bib binds the project's declared fields) when the project has a paper.toml.  A row WITHOUT
        # one is still a real project that must be AUDITED — it just has no declared consumer fields, so
        # parse with the empty default (() = no declaration, the honest value): its bib's non-builtin
        # fields are then genuinely undeclared and warned, correctly.  NOT a silent skip: dropping the row
        # would narrow the audit set with no signal — the exact silent-failure this codebase refuses.
        # (load_config exits on a missing paper.toml; _wired runs against arbitrary consumer repo roots,
        # repo_root = git toplevel, so guard existence before the owner call.  A row's `project` gives a
        # NAME; `repo_root / "."` correctly resolves the root row to repo_root.)
        pdir = repo_root / proj.group(1)
        f = bib.load_bib(bib_path, pdir) if (pdir / "paper.toml").is_file() else bib.parse(bib_path)
        # a sandbox-tier check = has a check and its effective tier is sandbox (no tier field / "sandbox")
        if any(w.get("check") and (w.get("tier") or "sandbox") == "sandbox" for w in f.values()):
            out.append(proj.group(1))
    return sorted(out)


_FILEGROUP_RE = re.compile(r'filegroup\(\s*name\s*=\s*"files"\s*,\s*srcs\s*=\s*\[(.*?)\]', re.S)


def _root_files(repo_root: Path) -> set:
    """Ξ·dag·reads — the repo-relative paths the root //:files filegroup STAGES (the `.` reads
    token).  DERIVED from BUILD.bazel (the owner, never a hardcoded copy) because //:files curates
    a CROSS-DIRECTORY set — it lists //report:gen.py, //tools:*.py, //paperkit:components.bzl, … —
    so which reads token stages a file is decided by its OWNING FILEGROUP, not its directory.  The
    project :files filegroups are own-directory-only, so //:files is the only cross-dir case.
    """
    m = _FILEGROUP_RE.search((repo_root / "BUILD.bazel").read_text())
    if not m:
        return set()
    return {(lit[2:].replace(":", "/", 1) if lit.startswith("//") else lit)
            for lit in re.findall(r'"([^"]+)"', m.group(1))}


def _covering(f: str, projects: set, root_files: set) -> set:
    """Ξ·dag·reads — the reads tokens that STAGE file f; ANY ONE suffices.  A file can be staged by
    SEVERAL sources, so this is a SET, not a single token: report/gen.py is in BOTH //report:files
    (`report`) and //:files (`.`), so a check declaring EITHER covers it.
    """
    top = f.split("/", maxsplit=1)[0]
    if top == "paperkit":
        # engine-adjacent — the .py modules AND the .bzl the build reads (components.bzl, dag.bzl),
        # incidentally opened by every engine-importing check; excluded like the engine (a genuine
        # need is caught by //:hook's own file-not-found on the unstaged file).
        return {"paperkit"}
    s = set()
    if top in projects:
        s.add(top)                       # under a project dir → coverable by @@//<proj>:files
    if f in root_files:
        s.add(".")                       # cross-listed in //:files → coverable by the `.` token
    return s or {"."}                    # a bare root file (.githooks/, a root bib/rubric/asset)


def _imported(project_dir: Path, repo_root: Path) -> set:
    """Repo-relative paths of the warrant bibs COMPOSED into a project from OTHER packages (root
    imports //paper:adequacy_pitch.bib).  Staged by the bib COMPOSITION, not a reads token, so a
    footprint read of one is already covered — derived from the same load_config the build uses.
    """
    out = set()
    for b in bib.load_config(project_dir)["bibs"]:
        try:
            out.add(str(Path(b).resolve().relative_to(repo_root)))
        except ValueError:               # a bib outside the repo — ignore
            continue
    return out


def _label_path(label: str) -> str | None:
    """Ζ·foot·builds — the repo-relative FILE a `builds` label stages: `@@//report:gen.py` →
    `report/gen.py`, `@@//:MODULE.bazel` → `MODULE.bazel`.  None for anything that is not a
    main-repo file label (a target such as `@@//paperkit:wheel` stages outputs, not a source path,
    so it cannot cover a footprint read and must not be guessed at)."""
    m = re.fullmatch(r"@{0,2}//([^:]*):(.+)", label.strip())
    if not m:
        return None
    pkg, name = m.groups()
    return f"{pkg}/{name}" if pkg else name


def _missing(fp: list, declared: set, projects: set, root_files: set, name: str, imported: set,
             built: set = frozenset()) -> list:
    """The reads tokens a check is MISSING: for each footprint file NOT already staged — by its own
    project, the engine, an imported warrant bib, a `builds` FILE label, or a DECLARED token's
    filegroup — the tokens that WOULD stage it (any one suffices).  [] iff every read is staged
    (the audit's soundness core).
    """
    return sorted(set().union(*_uncovered(fp, declared, projects, root_files, name, imported,
                                          built).values()))


def _uncovered(fp: list, declared: set, projects: set, root_files: set, name: str, imported: set,
               built: set = frozenset()) -> dict:
    """{footprint file: the reads tokens that WOULD stage it} for every read NOT already staged —
    `_missing` is its union.  Ζ·foot·files: the FILES are what a fix needs (a `builds` label names
    a file); a token like `report` says only which package, so the report printed tokens and left
    the reader to re-trace the check to learn what was actually read."""
    have = set(declared) | {name, "paperkit"}
    out = {}
    for f in fp:
        # Ζ·foot·pyc — a read of `pkg/__pycache__/m.cpython-NN.pyc` IS a read of `pkg/m.py`: the
        # interpreter opens the bytecode cache for the source it imports.  `_engine` already maps
        # this for paperkit/; without it here every declared non-engine module (report/gen.py …)
        # showed up as an unstaged .pyc the moment strace could see it.
        p = Path(f)
        if p.suffix == ".pyc" and p.parent.name == "__pycache__":
            f = str(p.parent.parent / (p.name.split(".")[0] + ".py"))
        if f in imported:
            continue                     # staged via warrant-imports composition, not reads=
        if Path(f).name == ".gitignore":
            # ⚑ Ζ·sandbox·declared — the Δ sandbox scope (layout._Scope) READS the repository's
            # ignore rules to drop non-content (caches, stale build copies, nested checkouts).  In a
            # Bazel cell only declared files are staged, so the rules have nothing to exclude and are
            # themselves not staged — _Scope then finds none and behaves exactly as before.  So the
            # read is the scope MECHANISM on host runs, not an input to any staged verdict, and
            # declaring it would only re-key cells on every .gitignore edit.  Limit, stated: a claim
            # whose SUBJECT is a .gitignore gets no help from this audit for that one file.
            continue
        if f in built:
            # ⚑ Ζ·foot·builds — staged by a `builds` FILE label, the operator's preferred form ("I
            # don't like directories as read targets"; "express dependencies on the specific files
            # needed").  This audit read only `reads=` tokens, so a claim declaring EXACTLY the
            # files it opens was flagged as under-declared — invisible until strace reached luthen
            # (2026-09-25), when 8 of the first 19 findings were this false positive.
            continue
        cov = _covering(f, projects, root_files)
        if not (cov & have):
            out[f] = cov                 # any of these declared would cover f
    return out


def _engine(reads: list) -> list:
    """Ζ·mutant — the ENGINE MODULES a check reads (the def-mutable surface for footprints.json):
    paperkit/*.py.  sensitivity ⊆ footprint (Φ), so a claim's def-sweep need mutate only the
    def-sites in THESE modules — the scope tools/bibtex.bzl reads at fetch to bound the pk_mutate /
    pk_eval fanout.  CRITICAL for soundness: a check's subprocess imports modules from the BYTECODE
    cache, so strace sees `paperkit/__pycache__/bib.cpython-NN.pyc`, not `paperkit/bib.py` — map each
    such .pyc back to its source .py, else the scope silently OMITS a sensitive module (bib/config for
    `deterministic`) and sens ⊄ footprint.
    """
    mods = set()
    for r in reads:
        if not r.startswith("paperkit/"):
            continue
        p = Path(r)
        if p.suffix == ".py":
            mods.add(r)
        elif p.suffix == ".pyc" and p.parent.name == "__pycache__":
            # paperkit/[sub/]__pycache__/x.cpython-NN.pyc → paperkit/[sub/]x.py
            mods.add(str(p.parent.parent / (p.name.split(".")[0] + ".py")))
    return sorted(mods)


def build(repo_root: Path, names: list) -> dict:
    manifest = {}
    for name in names:
        pdir = repo_root if name == "." else repo_root / name
        raw = tomllib.loads((pdir / "paper.toml").read_text())
        custom = raw.get("checks", {})
        cfg = bib.load_config(pdir)
        F = {}
        for b in cfg["bibs"]:
            F.update(bib.parse(b, cfg["consumer_fields"]))
        # Only SANDBOX-tier checks are footprint-audited (bibtex.bzl: only sandbox is swept + audited).
        # A toolchain/local check runs the host toolchain (veraPDF/lualatex/pandoc, 37s+ each) — stracing
        # it would RERUN that validator (minutes) AND its reads= is not staged-and-gated the sandbox way,
        # so it is correctly out of scope.  A BOUNDARY-CROSSING check (resolver.CROSSING — result:/concept:)
        # is an EDGE, not a leaf: its footprint is never used, and stracing it reruns a sibling gate.  Skip
        # both by the DATA (the tier field) and the VERB (crosses=True), never by re-listing verbs/tiers.
        # strace is I/O-bound, so trace the rest CONCURRENTLY.
        items = [(k, f["check"]) for k, f in sorted(F.items())
                 if f.get("check") and not f["check"].startswith(resolver.CROSSING)
                 and (f.get("tier") or "sandbox") == "sandbox"]

        def deps(chk):
            fp = resolver.footprint(chk, pdir, custom, scope=repo_root)
            return ["*"] if fp is None else fp

        with ThreadPoolExecutor(max_workers=min(16, (os.cpu_count() or 4))) as ex:
            graded = list(ex.map(lambda kc: deps(kc[1]), items))
        manifest[name] = {k: d for (k, _), d in zip(items, graded)}
    return manifest


def _declared(pdir: Path) -> dict:
    """{claim: set(declared read tokens)} from each claim's `reads` field (the declare+audit
    source).  Routed through the canonical parser (paperkit.bib, via bib.parse) — `reads` is now
    a first-class field there, so no separate line scanner / no disagreement with the build.
    """
    F = bib.parse_project(pdir)
    return {k: set(f.get("reads", [])) for k, f in F.items()}


def _built(pdir: Path) -> dict:
    """{claim: set(repo-relative files)} staged by each claim's `builds` FILE labels — the other
    half of what a claim declares (Ζ·foot·builds).  Same canonical parser as `_declared`."""
    F = bib.parse_project(pdir)
    return {k: {p for p in map(_label_path, f.get("builds") or []) if p} for k, f in F.items()}


def audit(repo_root: Path, names: list) -> list:
    """The AUDIT: each claim's live Φ·footprint (repo-scoped) must be COVERED by its declared
    `reads` (plus its own project + the engine).  Returns the under-declared [(proj, claim,
    missing, declared, files)] — an empty list means every declaration is sound.
    """
    live = build(repo_root, names)
    projects = {p.name for p in repo_root.iterdir() if (p / "paper.toml").is_file()}
    root_files = _root_files(repo_root)
    bad = []
    for name in names:
        pdir = repo_root if name == "." else repo_root / name
        declared = _declared(pdir)
        built = _built(pdir)
        imported = _imported(pdir, repo_root)
        for k, fp in live.get(name, {}).items():
            if "*" in fp:                            # degraded footprint (e.g. strace blocked) — skip
                continue
            unc = _uncovered(fp, declared.get(k, set()), projects, root_files, name, imported,
                             built.get(k, set()))
            if unc:
                bad.append((name, k, sorted(set().union(*unc.values())),
                            sorted(declared.get(k, set())), sorted(unc)))
    return bad


def audit_one(proj: str, claim: str) -> dict:
    """Ζ·foot·act — the PER-CLAIM footprint-audit ORACLE: strace this one claim's check and report
    whether its live Φ·footprint is covered by its declared `reads` (+ own project + engine).  Bazel
    nests one of these per claim and pk_footaudit aggregates them — so the audit SWEEP is the build
    graph, not footdeps' ThreadPool loop (which stays for direct/on-demand use).
    """
    project_dir = Path(proj).resolve()
    name = "." if proj == "." else project_dir.name
    repo_root = project_dir if proj == "." else project_dir.parent
    projects = {p.name for p in repo_root.iterdir() if (p / "paper.toml").is_file()}
    raw = tomllib.loads((project_dir / "paper.toml").read_text())
    custom = raw.get("checks", {})
    declared = _declared(project_dir).get(claim, set())
    F = bib.parse_project(project_dir)
    f = F.get(claim)
    if not f or not f.get("check") or f["check"].startswith(resolver.CROSSING):
        return {"claim": claim, "ok": True, "skip": True}     # a crossing verb is an edge — no footprint
    fp = resolver.footprint(f["check"], project_dir, custom, scope=repo_root)
    if fp is None:
        return {"claim": claim, "ok": True, "degraded": True}  # strace blocked — over-declare, never fail
    missing = _missing(fp, declared, projects, _root_files(repo_root), name,
                       _imported(project_dir, repo_root), _built(project_dir).get(claim, set()))
    # `engine` = the def-mutable surface (the modules whose def-sites the Ζ·mutant fanout sweeps);
    # pk_foot_learn aggregates it across claims → footprints.json (the def-scope manifest).
    return {"claim": claim, "ok": not missing, "missing": missing, "engine": _engine(fp)}


def _strace_works() -> bool:
    """Ζ·degrade·roots — a POSITIVE CONTROL for the audit's own instrument.  strace can DEGRADE
    silently (absent, or ptrace blocked on a hardened host/container): resolver.footprint then
    returns None, every claim over-declares to ["*"], the audit finds nothing to flag, and main()
    prints a GREEN 'every declared reads ⊇ footprint' — a plausible-but-WRONG pass.  So trace a check
    with a KNOWN small footprint first; if it comes back empty, strace is degraded and the audit is
    not trustworthy (mirrors bnd-footprint, which guards the SANDBOX strace in //:hook).
    """
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        (p / "probe.txt").write_text("PK_PROBE\n")
        return resolver.footprint("cmd:grep -q PK_PROBE probe.txt", p, {}, scope=p) == ["probe.txt"]


def main(argv: list) -> int:
    if "--only" in argv:
        i = argv.index("--only")
        claim = argv[i + 1]
        rest = [a for a in argv[1:] if a != "--only" and a != claim and not a.startswith("-")]
        print(json.dumps(audit_one(rest[0] if rest else ".", claim)))
        return 0
    repo_root = Path(subprocess.run(["git", "rev-parse", "--show-toplevel"],
                                    capture_output=True, text=True).stdout.strip())
    if not _strace_works():
        print("paperkit-footdeps: DEGRADED — strace is unavailable on this host (a probe with a KNOWN "
              "footprint traced empty); the footprint audit CANNOT verify declared reads and is SKIPPED, "
              "not passed (Ζ·degrade·roots positive control — never a silent false green).  reads= are "
              "unenforced here; run on a strace-capable host to gate them.", file=sys.stderr)
        return 0
    names = [a for a in argv[1:] if not a.startswith("-")] or _wired(repo_root)
    bad = audit(repo_root, names)
    if bad:
        for proj, k, miss, decl, files in bad:
            print(f"paperkit-footdeps: {proj}:{k} footprint reads {miss} not in declared reads {decl} "
                  f"— declare the files in `builds` (or the tokens in `reads`); unstaged: "
                  f"{', '.join(files)}", file=sys.stderr)
        return 1
    print(f"paperkit-footdeps: every declared `reads` ⊇ its Φ·footprint ({len(names)} projects audited)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
