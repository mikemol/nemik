#!/usr/bin/env python3
"""paperkit project — emit a paper's prose by PROJECTING it from the warrant set.

A paper is the projection of a claim-DAG.  Each entry in a `.bib` is a claim:
a statement (`claim`/`title`), a rubric `section`, its dependencies (`from`),
and a verifier (`check`).  This command reads those records and emits the prose —
every section's claims ordered by their `from` edges and joined with connective
`glue` across genuine entailment edges, and each claim's NON-ADJACENT grounding
(`rests-on`) edges projected as trailing cross-references (the long edges the
connective cannot carry by adjacency).  The output passes the gate (every
citation resolves, every required claim present, in order) BY CONSTRUCTION.

    paperkit-project [DIR]            # write the projection to the configured `out`
    paperkit-project --check [DIR]    # exit 1 if the committed file != the projection
    paperkit-project -o - [DIR]       # write to stdout

DIR defaults to the current directory and must contain `paper.toml`.
"""
from __future__ import annotations

import csv
import json
import re
import sys
import tomllib
from pathlib import Path

# Ζ·pkg·shape — the engine's own directory, FIRST on sys.path, and it must stay a per-module
# line rather than moving to paperkit/__init__.py: a package __init__ runs only when the
# package is IMPORTED, and these modules are also loaded as siblings by a caller that has
# already put its own directory ahead of ours.  render/checks/ ships its OWN bib.py, so a
# witness inserting that directory shadows the engine's parser and `from bib import
# dep_order` resolves to the wrong module.  MEASURED: removing these six lines reddened
# seven talk claims with "cannot import name 'dep_order' from bib (render/checks/bib.py)".
# The insert is a PRIORITY CLAIM, not a reachability fix — __init__.py handles reachability.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bib
import durable

# the projector parses then renders, so it uses the bib data model internally (short names).
from bib import dep_order, emit_path, is_placed, load_config, rubric
from bib import parse as entries

# top-level now: after Μ·cycle rhetoric imports bib (a leaf), NOT project, so project→rhetoric is
# one-way — the project↔rhetoric cycle is gone and this need no longer be a function-local import.
from rhetoric import MOVES

import config

# Minimal, domain-agnostic LaTeX -> Unicode for claim text (em/en dashes, a few
# escapes, inline math).  A paper that needs more declares its own; this is the
# common floor.
_LATEX = [
    (r"\\textsuperscript\{(\d)\}", lambda m: "⁰¹²³⁴⁵⁶⁷⁸⁹"[int(m.group(1))]),
    (r"\\texttt\{([^{}]*)\}", r"\1"), (r"\\textbackslash", ""),
    (r"\\&", "&"), (r"\\\$", "$"), (r"\\_", "_"),
    (r"\\'e", "é"), (r'\\"o', "ö"), (r"\\'E", "É"),
    (r"---", "—"), (r"(?<=\S)--(?=\S)", "–"), (r"\\equiv", "≡"),
    (r"\$([^$]*)\$", r"\1"),
]


def clean(s: str) -> str:
    # Inline math $…$ is renderable CONTENT for the downstream engine (pandoc/MathJax), not
    # LaTeX-prose to flatten — shield each span verbatim (its delimiters, macros, AND grouping
    # braces) so neither the floor-flattening below nor the grouping-brace strip touches it. This
    # is the same shield discipline as \{ \}, one level up: the whole math span is literal.
    math: list = []
    s = re.sub(r"(?<!\\)\$[^$]*\$",
               lambda m: math.append(m.group(0)) or f"\x02{len(math) - 1}\x03", s)
    # A code span is LITERAL for the same reason inline math is: `--flavour` is a
    # command-line flag, not prose, and the en-dash rule below would silently
    # rewrite it to `–flavour` -- a flag the reader cannot type. Shield it the
    # same way, and restore it verbatim.
    s = re.sub(r"`[^`\n]*`",
               lambda m: math.append(m.group(0)) or f"\x02{len(math) - 1}\x03", s)
    for pat, rep in _LATEX:
        s = re.sub(pat, rep, s)
    # Escaped braces \{ \} are LITERAL (e.g. set notation {1,2,3}); shield them
    # from the grouping-brace strip below, then restore as real braces.
    s = s.replace(r"\{", "\x00").replace(r"\}", "\x01")
    s = re.sub(r"[{}]", "", s)
    s = s.replace("\x00", "{").replace("\x01", "}")
    s = re.sub(r"\x02(\d+)\x03", lambda m: math[int(m.group(1))], s)
    return s.strip().rstrip(".")


def short_author(a: str) -> str:
    a = clean(a)
    names = re.split(r"\s+and\s+", a)
    if len(names) > 2:
        return names[0].split()[-1] + " et al."
    return " & ".join(n.split()[-1] if " " in n else n for n in names)


def _anchor(key: str, body: str, target: str) -> str:
    """A claim's own citation point: a pandoc [@key] tag (for citeproc), a web ANCHOR that other
    claims link to, or NOTHING for the footnote target (where the marker + its verification note
    are attached by the weaver instead).  The grounding edges are the same `rests-on` DATA either
    way — only how a citation MATERIALIZES differs by target (the projector's one job).
    """
    if target == "web":
        return f'<a id="{key}"></a>{body}'
    if target in ("footnote", "plain"):
        return body
    return f"{body} [@{key}]"


def _verify_note(check: str) -> str:
    """The footnote target's provenance line: HOW this clause's claim is machine-verified, read
    off its `check`.  A cmd: names the verifier to re-run; a claim:/file: names what is imported/
    present.  This is the whole point of the footnote target — every clause cites its own proof.
    """
    kind, _, tgt = check.partition(":")
    if not check:
        return "Asserted without a machine check"
    if kind == "cmd":
        return f"Machine-verified — `{tgt}`"
    if kind == "agda":
        return f"Agda-proved — `{tgt}`"
    if kind == "premise":
        return f"Classical premise (not machine-checked) — `{tgt}`"
    if kind == "claim":
        return f"Verified claim `{tgt}`"
    if kind == "file":
        return f"Artifact present — `{tgt}`"
    return f"Machine-verified — `{tgt}`" if tgt else "Machine-verified"


def sentence(key: str, f: dict, primary: str, target: str = "pandoc") -> str:
    """A claim sentence carrying its own citation/anchor for `target`.  Prefer an explicit
    `claim`; else a warrant's `title` (the title IS the claim); else a terse cite.
    """
    if f.get("claim"):
        return _anchor(key, clean(f["claim"]), target)
    title = clean(f.get("title", key))
    if f["_src"] == primary:
        return _anchor(key, title, target)
    yr = f.get("year", "")
    who = short_author(f.get("author", "")) if "author" in f else ""
    paren = ", ".join(x for x in (who, yr) if x)
    return _anchor(key, title + (f" ({paren})" if paren else ""), target)


GLUE = ["and from that, ", "so "]

# A placed (not woven) warrant emits an asset instead of a sentence.  WHICH
# renderer runs is DECLARED by `as`; the suffix map below is the legacy fallback
# for warrants that predate the field.
FENCE = {".sh": "sh", ".bash": "sh", ".py": "python", ".toml": "toml",
         ".bib": "bibtex", ".json": "json", ".yaml": "yaml", ".yml": "yaml",
         ".txt": "text", ".tsv": "text", ".md": ""}   # .md = raw include (legacy)


IMAGE_EXTS = {".svg", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".emf"}

RENDERERS = ("table", "image", "code", "raw")

# A `raw` placement is document syntax the engine did not construct, so it can
# forge the very markers the gate reads — [@key] citations and `## ` headings.
# Fencing already shields code from cited_keys (gate.cited_keys strips ``` runs);
# these sentinels give the raw arm the same shield.  Keep in sync with gate.py.
RAW_OPEN, RAW_CLOSE = "<!-- paperkit:raw -->", "<!-- /paperkit:raw -->"


def _cell(s: str) -> str:
    """One table cell.  The FILE owns data; the ENGINE owns document syntax — so
    nothing a cell contains may become markup, a citation, or a heading.
    """
    s = " ".join(str(s).split())            # newlines would break the row
    return (s.replace("\\", "\\\\").replace("|", "\\|")
             .replace("[", "\\[").replace("]", "\\]"))   # kills [@key] citations


def _rows(p: Path) -> list:
    """(header, rows) from tabular DATA — never from pre-rendered markup."""
    suf = p.suffix.lower()
    if suf == ".json":
        data = json.loads(p.read_text())
        if isinstance(data, dict) and "columns" in data:
            return [list(data["columns"])] + [list(r) for r in data.get("rows", [])]
        if isinstance(data, list) and data and isinstance(data[0], dict):
            cols = list(data[0].keys())
            return [cols] + [[r.get(c, "") for c in cols] for r in data]
        if isinstance(data, list):
            return [list(r) for r in data]
        raise ValueError(f"{p.name}: unrecognised table JSON shape")
    delim = "," if suf == ".csv" else "\t"
    with p.open(newline="") as fh:
        return [r for r in csv.reader(fh, delimiter=delim) if r]


def render_table(p: Path) -> list:
    """A markdown table the ENGINE builds from data, with every cell escaped."""
    rows = _rows(p)
    if not rows:
        return [f"<!-- emit: empty table {p.name} -->"]
    width = max(len(r) for r in rows)
    out = [[_cell(c) for c in r] + [""] * (width - len(r)) for r in rows]
    head, body = out[0], out[1:]
    return (["| " + " | ".join(head) + " |",
             "|" + "|".join([" --- "] * width) + "|"]
            + ["| " + " | ".join(r) + " |" for r in body])


def _infer(p: Path) -> str:
    """Legacy renderer inference from the filename.  Deprecated: declare `as`."""
    if p.suffix.lower() in IMAGE_EXTS:
        return "image"
    return "code" if FENCE.get(p.suffix) else "raw"


def emit_block(cfg: dict, f: dict) -> list:
    """The lines for an `emit:` warrant, rendered by its DECLARED `as` kind:

        table  data (.tsv/.csv/.json) → a markdown table the engine constructs,
               every cell escaped, so an asset cannot inject document syntax
        image  → a markdown image, the claim as its caption/alt
        code   → a fenced block, language from the extension
        raw    → included verbatim, shielded from cited_keys by sentinels

    With `as` absent the kind is inferred from the extension, preserving the
    behaviour of warrants written before the field existed.  The asset is resolved
    by bib.emit_path (project_dir, then out.parent), so BOTH legitimate layouts work
    and the projector and the gate resolve to the SAME path.
    """
    emit = f["emit"]
    p = emit_path(cfg, emit)                       # project_dir first, then out.parent; None = absent
    kind = (f.get("as") or "").strip().lower() or _infer(Path(emit))
    if kind not in RENDERERS:
        raise ValueError(f"{emit}: unknown renderer as={kind!r}; "
                         f"expected one of {', '.join(RENDERERS)}")
    if kind == "image":
        return [f"![{clean(f.get('claim', 'figure'))}]({emit})"]
    if p is None:
        return [f"<!-- emit: missing {emit} -->"]
    if kind == "table":
        return render_table(p)
    content = p.read_text().rstrip("\n")
    if kind == "code":
        return [f"```{FENCE.get(p.suffix, '')}", content, "```"]
    return [RAW_OPEN, content, RAW_CLOSE]


def transitive_reduction(rests: dict) -> dict:
    """Drop a grounding edge X→Y when Y is already reachable from X by a LONGER `rests-on`
    path (the reader reaches Y through the intermediate, so re-citing Y is redundant
    clutter, not new grounding).  The `drop` rung — the zero of the reference's
    materialization ladder (drop < cite < expound < figure), need-proportioned.
    """
    def reaches(a, b):
        seen, stk = set(), [x for x in rests.get(a, ()) if x != b]
        while stk:
            n = stk.pop()
            if n == b:
                return True
            if n not in seen:
                seen.add(n)
                stk += list(rests.get(n, ()))
        return False
    return {k: [y for y in ys if not reaches(k, y)] for k, ys in rests.items()}


def references(k: str, targets: list, pos: dict, target: str = "pandoc") -> str:
    """Project a claim's NON-ADJACENT grounding edges (after transitive reduction) as
    cross-references — the long edges the prose connective cannot carry by adjacency.  A
    connective IS a reference at distance 0; this is the same edge-projection at distance
    > 0, the direction read off the sign of the prose-distance (a back-reference to ground
    already laid, a forward-reference to ground laid below).  Citation is the floor
    materialization; richer forms (expound, figure) are opt-in.  Returns the parenthetical.
    For `target` web a cross-reference is an intra-page hyperlink to the grounded claim's
    anchor; for pandoc it is a [@key] citation — the SAME edge, materialized per target.
    """
    if not pos or k not in pos:
        return ""

    def tok(y: str) -> str:
        human = y.replace("-", " ").replace("_", " ")
        if target == "web":
            return f"[{human}](#{y})"
        if target == "footnote":
            return human            # a footnote body cannot host a [@key]/anchor — name the claim in prose
        return f"[@{y}]"
    back, fwd = [], []
    for y in targets:
        yp = pos.get(y)
        if yp is None or yp == pos[k] - 1:        # cross-scope, or carried by the connective
            continue
        (back if yp < pos[k] else fwd).append(tok(y))
    parts = []
    if back:
        parts.append("grounded above in " + ", ".join(back))
    if fwd:
        parts.append("developed below at " + ", ".join(fwd))
    return f" ({'; '.join(parts)})" if parts else ""


def weave(text: list, F: dict, primary: str, pos: dict | None = None,
          reduced: dict | None = None, footnotes: dict | None = None,
          target: str = "pandoc") -> str:
    """Weave a run of prose-claim keys into one sentence-diagrammed paragraph.  A
    claim carrying a `link` is materialized at the EXPOUND rung of the reference
    ladder (drop < cite < expound < figure): a footnote marker on the sentence, the
    link explanation + its grounding citations collected into `footnotes` for the
    document end.  Without a link (or no footnotes sink) the grounding is the CITE
    floor — the inline parenthetical.  `target` selects how citations materialize.
    """
    def clause(k: str) -> str:
        s = sentence(k, F[k], primary, target)
        link = F[k].get("link")
        if target == "plain":                        # SUBMISSION view: no PROVENANCE surfaced, but an
            if link and footnotes is not None:       # authored `link` footnote survives — the technical NAME,
                footnotes[k] = clean(link)           # defocused out of the inline reading so the computations
                return s + f"[^{k}]"                  # lead. (The proof backend stays the author-side gate.)
            return s
        ref = references(k, (reduced or {}).get(k, F[k].get("rests-on", [])), pos or {}, target)
        link = F[k].get("link")
        if link and footnotes is not None:           # expound: link + citations → footnote
            footnotes[k] = clean(link) + ref
            return s + f"[^{k}]"
        if target == "footnote" and footnotes is not None:   # CITE floor as a provenance footnote
            footnotes[k] = _verify_note(F[k].get("check", "")) + ref
            return s + f"[^{k}]"
        return s + ref                               # cite floor: inline parenthetical
    clauses = [clause(k) for k in text]
    clauses[0] = clauses[0][:1].upper() + clauses[0][1:]
    clauses[1:] = [re.sub(r"^(The|A|An) ", lambda m: m.group(1).lower() + " ", c)
                   for c in clauses[1:]]
    parts, woven = [clauses[0]], 0
    for i in range(1, len(text)):
        f = F[text[i]]
        clause = clauses[i]
        # `join` is the FULL connector to the previous clause — the grammatical
        # attachment of a sentence-diagram constituent: "— " apposition, ", and "
        # conjunction, ", which " relative, ": " list-intro, ". " new sentence.
        # Default is the legacy "; " + `glue` weave.
        if f.get("join") is not None:
            j = f["join"] if f["join"].endswith(" ") else f["join"] + " "
            if j.strip().endswith((".", "!", "?")):   # sentence boundary → capitalize
                clause = clause[:1].upper() + clause[1:]
            parts.append(j + clause)
            continue
        mv = f.get("move")
        if mv:                                    # a typed `move` with no explicit `join`:
            if mv in MOVES:                       # realize its default connector (MOVES imported up top)
                conn = MOVES[mv][1]
                if conn.strip().endswith((".", "!", "?")):
                    parts.append(conn + clause[:1].upper() + clause[1:])
                else:
                    parts.append("; " + conn + clause)
                continue
        edge = text[i - 1] in f.get("from", [])
        if edge and f.get("glue"):
            g = f["glue"]
            conn = g if g.endswith(" ") else g + " "
        elif edge and f["_src"] == primary and F[text[i - 1]]["_src"] == primary:
            conn = GLUE[woven % len(GLUE)]
            woven += 1
        else:
            conn = ""
        parts.append("; " + conn + clause)
    return "".join(parts) + "."


def project(cfg: dict, target: str = "pandoc") -> str:
    F, primary = {}, cfg["bibs"][0].name
    for b in cfg["bibs"]:
        F.update(entries(b, cfg["consumer_fields"]))     # thread the project's declared consumer_fields

    by_sec = {}
    for k, f in F.items():
        if f.get("section"):
            by_sec.setdefault(f["section"], []).append(k)
    # global prose linearization (rubric order × dep_order) — positions used to project
    # a claim's long (non-adjacent) grounding edges as cross-references.
    pos, _i = {}, 0
    for sk, _t in rubric(cfg["rubric"]):
        for k in dep_order(by_sec.get(sk, []), F):
            pos[k] = _i
            _i += 1
    # transitive reduction of the grounding DAG — project only references the reader
    # cannot already reach through a shorter rests-on path (drop redundant clutter).
    reduced = transitive_reduction({k: f.get("rests-on", []) for k, f in F.items()})
    footnotes: dict = {}                              # expound-rung materializations, in document order

    lines = [f"# {cfg['title']}", ""]
    if cfg["subtitle"]:
        lines += [f"*{cfg['subtitle']}*", ""]
    for n, (sk, title) in enumerate(rubric(cfg["rubric"]), 1):
        lines += [f"## {n}. {title}" if cfg["numbered"] else f"## {title}", ""]
        keys = dep_order(by_sec.get(sk, []), F)
        if not keys:
            lines += ["<!-- structural section: connective prose, no required claim atom -->", ""]
            continue
        # Walk the section in dependency order, interleaving woven-prose runs with placed asset blocks and
        # NESTED PROOF STEPS: a run of (depthless) claims weaves into one paragraph; an emit: warrant flushes
        # it then drops its block; a claim carrying `depth = N` is a proof step, rendered as a Markdown list
        # item indented by N (so a decomposed proof reads as an outline, not interleaved flat prose).
        run: list = []
        in_list = [False]

        def _blank():
            if lines and lines[-1] != "":
                lines.append("")

        def _flush():
            if run:
                lines.append(weave(run, F, primary, pos, reduced, footnotes, target))
                run.clear()

        def _close_list():
            if in_list[0]:
                _blank()
                in_list[0] = False

        for k in keys:
            f = F[k]
            if f.get("depth"):                       # a nested proof step → indented list item (tight)
                if not in_list[0]:
                    _flush()
                    _blank()
                    in_list[0] = True
                item = weave([k], F, primary, pos, reduced, footnotes, target)
                lines.append("  " * (int(f["depth"]) - 1) + "- " + item)
            elif f.get("emit"):
                _close_list()
                if f.get("claim") or f.get("title"):
                    run.append(k)
                _flush()
                _blank()
                lines += emit_block(cfg, f)
                _blank()
            elif f.get("check", "").startswith("figure:"):
                continue
            else:
                _close_list()
                run.append(k)
                # ISO 24495-1 asks for one topic per paragraph.  A claim IS one
                # assertion, and dep_order has already topologically sorted the
                # section, so flushing per claim satisfies that BY CONSTRUCTION
                # rather than by editorial judgement.  The default stays `woven`:
                # short, tightly-linked claims read better joined, and a claim
                # written to follow a connective does not stand alone.
                if cfg.get("paragraph") == "claim":
                    _flush()
                    _blank()
        _close_list()
        _flush()
        _blank()
    # the expound rung: a claim's `link` materialized as a document-end footnote
    # (the marker rode the sentence; the explanation + its citations land here).
    if footnotes:
        lines += [f"[^{k}]: {v[:1].upper() + v[1:]}" for k, v in footnotes.items()] + [""]
    if cfg["references"]:
        lines += ["## References", ""]
    return "\n".join(lines).rstrip("\n") + "\n"          # exactly one trailing newline (MD012-clean)


def observe(cfg: dict, genre_name: str = "talk", project_dir=None, gamma=None) -> list:
    """Ρ·deck·observe — the projector's SECOND observation shape: S → List(Unit), indexed by
    (target, genre), beside project()'s S → String indexed by target alone.

    ⚑ ONE LEVEL, not a tree.  slides.bib designed this as S → RoseTree(S) — deck > chapters >
    slides > claims, one grouping applied recursively — and that is NOT what shipped: this
    returns a flat list of units, each carrying its own `items`.  The recursive form is
    UNBUILT, and the RoseTree language was copied into three render check docstrings before
    anyone compared it to the return.  A type a function advertises and does not meet is the
    same defect class as a claim whose witness cannot fail; it is named here rather than left
    for the next reader to trip over.

    project() LINEARIZES: one flat stream seeded by rubric-order × dep_order, which every existing
    target (pandoc/web/footnote/plain) is a citation-materialization of.  A deck is not a
    linearization but a SEGMENTATION into bounded observation-windows, so it cannot be a fifth
    target — it is a different observation of the same carrier, which is why this is a sibling
    function and not a branch inside project().

    Two axes, kept apart (slides.bib's grouping-is-not-pagination):
      GROUPING   what coheres — the claims' own structure.  Read from `section`, the authored
                 partition.  How far that sits from the rests-on-derived one is measured by
                 coherence.grouping_residual — in the DELTA component, which depends on this one,
                 so the measurement reads the projection and never the reverse.
      PAGINATION where a unit breaks — a rhetoric choice, supplied by the genre registry.

    Returns a list of UNITS, each {"keys": [...], "claims": [...], "section": …}.  Deliberately NOT
    a rendered string: what a unit becomes on a slide is the render layer's business, and returning
    prose here would re-linearize the thing this function exists to avoid.

    HONEST BOUND (measured, Ρ·deck·rests-on·adoption): the grouping is only as rich as the
    `rests-on` a project actually declares.  Where authors declare grounding this cut reads real
    structure; where they declare only prose order it reduces to the section cut — which is a fact
    about the corpus, not the mechanism, and `residual` in the returned metadata says which case a
    given project is in.  (That residual is reported by the ∂² grade, not computed here: project
    must not import the grader — the component lattice has delta depending on project.)
    """
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import genre as genre_mod  # the pagination registry (project component; no upward edge)

    F = {}
    for b in cfg["bibs"]:
        F.update(entries(b, cfg["consumer_fields"]))
    recs = [{"key": k, **f} for k, f in F.items()]

    # the GROUPING, in document order (rubric × dep_order), so a unit's claims read in the order
    # the document already establishes — pagination changes the bracketing, never the order.
    by_sec = {}
    for k, f in F.items():
        if f.get("section"):
            by_sec.setdefault(f["section"], []).append(k)
    groups, sections = [], []
    for sk, _t in rubric(cfg["rubric"]):
        keys = dep_order(by_sec.get(sk, []), F)
        if keys:
            groups.append(keys)
            sections.append(sk)


    # the PAGINATION — resolved from the registry, which REFUSES an unregistered name rather than
    # falling back (so a deck is never cut by a genre nobody asked for).
    spec = genre_mod.resolve(genre_name, project_dir)
    objective = spec.get("objective")
    # Ρ·deck·residual·wire — REGROUP on the grounding-derived partition at the resolution this
    # genre asks for (γ, which every registry entry carries and nothing read until now).  σ stays
    # the prior: where the rests-on graph is too sparse to say anything, modularity's null term
    # leaves the −γ·d term deciding and the partition falls back to section BY CONSTRUCTION — so a
    # project with no grounding (measured: 7 of 11 in this repo) gets exactly the section cut it
    # would have had, and one WITH grounding gets a cut that answers to it.
    # an explicit γ overrides the genre's own; absent, the genre's declared value stands.
    derived = genre_mod.partition(recs, float(gamma if gamma is not None
                                              else spec.get("gamma", 1.0)))
    if not derived["degenerate"]:
        order = {k: i for i, g in enumerate(groups) for k in g}   # document order, preserved
        by_group: dict = {}
        for k in sorted(order, key=order.get):
            by_group.setdefault(derived["part"][k], []).append(k)
        # groups in the document order of their FIRST claim, so the deck still reads forward
        groups = sorted(by_group.values(), key=lambda g: order[g[0]])

    # a BUILT-IN runs in-process; a project-DECLARED one runs its `cmd` through the registry's
    # seam (Ρ·deck·genre·cmd), which validates the result against the same totality invariant.
    # Ζ·spawn·owner — the spawn is INJECTED: `genre` may not import `resolver` (project →
    # resolver is an upward edge the partition forbids), so the caller that legitimately may
    # supplies the engine's owner of running a document-declared command.
    if objective is not None:
        units = objective(groups, recs)
    else:
        from resolver import spawn_declared
        units = genre_mod.run_declared(spec, groups, recs, cwd=project_dir,
                                       spawn=spawn_declared)

    # which section a unit came from — a unit never spans sections (the objective splits within a
    # group, never merges across), so the first key's section names the whole unit.
    sec_of = {k: f.get("section") for k, f in F.items()}
    out = []
    for u in units:
        # Ρ·deck·materialize — a unit carries everything the PROSE route materializes for these
        # claims, not just their sentences.  A deck that dropped a claim's emitted table, its
        # proof-step nesting, or its expound-rung footnote would be a lossy view of the same
        # carrier, and the render layer could not recover what the projector discarded.
        items = []
        for k in u:
            f = F.get(k, {})
            item = {"key": k, "claim": f.get("claim", "")}
            if f.get("depth"):
                item["depth"] = f["depth"]          # proof-step nesting, as an indent level
            if f.get("link"):
                item["link"] = f["link"]            # the expound-rung note
            if f.get("emit"):
                # the placed asset, rendered by its declared `as` — the SAME lines the prose route
                # emits, produced by the same function, so the two views cannot diverge.
                item["emit"] = {"path": f["emit"], "as": f.get("as"),
                                "lines": emit_block(cfg, f)}
            if f.get("check"):
                item["check"] = f["check"]          # provenance: the render layer marks it
            if f.get("note"):
                # Ρ·deck·notes — the SPEAKER NOTE.  `note` was already in the bib grammar and
                # engine-inert ("parsed but consumed nowhere, reserved"), so a deck reads the
                # reserved field rather than inventing one: a note is what an author says ABOUT a
                # claim, which is exactly the register a presenter needs and no other target wants.
                item["note"] = f["note"]
            items.append(item)
        out.append({"keys": list(u),
                    "claims": [F[k].get("claim", "") for k in u],
                    "items": items,
                    "section": sec_of.get(u[0]) if u else None})
    return out


# Ω·config — the knobs this module RESOLVES, declared here (place-by-ownership; the kernel
# hosts the mechanism only).  TARGET is also resolved by gate/discriminate — they reference
# project.TARGET (the lowest common component in the DEPS lattice owns it).
TARGET = config.Param("target", "PAPERKIT_TARGET", config="target", default="pandoc", choices=("pandoc", "web", "footnote", "plain"),
                      help="citation render target: pandoc ([@key] for citeproc/PDF), web (intra-page hyperlinks + anchors, for a blog), "
                           "footnote (each clause's provenance as a document-end footnote — self-contained, no bibliography), "
                           "or plain (no citation surfaced at all — a clean SUBMISSION view; the claim-DAG stays the author-side gate)")
# Ρ·deck·genre·knob — the pagination genre.  choices is DELIBERATELY None: the genre set is an
# OPEN registry (built-ins + a project's [genres.*]), so a static tuple here would either freeze
# the set — contradicting the registry — or duplicate it and drift.  Validation therefore happens
# where the set actually lives: genre.resolve() REFUSES an unregistered name, which is the same
# reason resolver.VERBS validates a check type rather than config.Param enumerating them.
GENRE = config.Param("genre", "PAPERKIT_GENRE", config="genre", default="talk",
                     help="pagination genre for --observe: a registered objective over the grouping "
                          "(built-ins staged/talk/atomic/collection; a project adds its own with a "
                          "[genres.<name>] table in paper.toml).  Validated by the registry, not by "
                          "a fixed list — the set is open")
# Ρ·deck·gamma·declare — the RESOLUTION dial, the deck-analog of --min-strength.  Each genre
# carries a default γ (its own idea of how much to trust the grounding over the authored sections);
# this makes that reachable, so a deck can be re-cut coarser or finer without inventing a genre.
# Default None = "whatever the genre asks for", which keeps a genre's declared γ meaningful instead
# of overriding it with an engine-wide constant.
GAMMA = config.Param("gamma", "PAPERKIT_GAMMA", config="gamma", default=None,
                     help="observe: the grouping resolution γ, overriding the genre's own — "
                          "γ→∞ recovers the authored sections, γ→0 the modularity optimum; "
                          "omit to use the genre's declared value")
OBSERVE = config.Param("observe", "PAPERKIT_OBSERVE", flag=True,
                       help="project: emit the DAG's segmentation into units (one per line, "
                            "tab-separated keys) instead of the linearized document")
CHECK = config.Param("check", "PAPERKIT_CHECK", flag=True,
                     help="project: verify the projection round-trips against the bib, then exit")
# The projector CLI's composed registry: exactly the Params its import cone hosts
# (bnd-config asserts this completeness — a cone-resolved Param missing here would be
# a silently ignored flag).
#
# ⚑ Ζ·config·cone — `path` AND `engine-path` JOINED THE CONE WHEN THE SPAWN DID, AND THEY ARE
# COMPOSED BY QUALIFIED REFERENCE, NEVER IMPORTED.
#
# Ζ·spawn·owner moved "run a command a document declared" to `resolver.spawn_declared`, which the
# `--observe` path injects; `spawn_declared` calls `clean_env()`, which resolves BOTH of
# resolver's knobs (`config.resolve(PATH)` / `config.resolve(ENGINE_PATH)`, resolver.py:509,511).
# So this CLI's cone now HOSTS them, and bnd-config said so exactly:
# `project.REGISTRY == the Params its import cone hosts (7) — missing=['engine-path', 'path']`.
# Without them, `paperkit-project --path=...` parses as an unknown flag and the pin is silently
# ignored — the precise defect that guard exists to catch.
#
# ⚑⚑ THE FIRST FIX WAS `from resolver import PATH as _PATH`, AND IT BROKE THREE OTHER ARMS.
# `_hosted()` reads a module's own attributes, so an imported Param is a SECOND HOST: the suite
# went 1 drifted → 3, newly failing "every Param has exactly ONE host module", "knob names are
# globally unique" and "env vars are globally unique".  COMPOSING a knob and HOSTING one are two
# different relations, and satisfying the first with the second's mechanism violates ownership.
# `discriminate.py:158` already had the right form — `resolver.PATH, resolver.ENGINE_PATH`, a
# qualified reference that composes without binding.  Same here.
import resolver as _resolver   # noqa: E402  — qualified, so the knobs stay HOSTED by resolver

REGISTRY = [TARGET, GENRE, GAMMA, OBSERVE, CHECK, _resolver.PATH, _resolver.ENGINE_PATH]


def main(argv: list) -> int:
    config.apply_args(argv, REGISTRY)
    pos = config.positionals(argv, REGISTRY)
    project_dir = Path(pos[0]).resolve() if pos else Path.cwd()
    cfg = load_config(project_dir)
    pol = tomllib.loads((project_dir / "paper.toml").read_text()).get("paper", {})

    if config.resolve(OBSERVE):
        import genre as _genre
        # Ρ·deck·observe via the CLI: the SECOND observation shape, printed as units.  Not written
        # to cfg["out"] — that path holds the linearization the gate's PROJECT invariant compares
        # against, and a segmentation is not a candidate for it.
        try:
            _g = config.resolve(GAMMA, pol)
            units = observe(cfg, config.resolve(GENRE, pol), project_dir, _g)
        except _genre.Unregistered as e:
            # a CLI refusal reads as a message, not a traceback — the registry's LOUD invariant is
            # about telling the caller what happened, and a stack trace tells them where.
            print(f"paperkit-project: {e}", file=sys.stderr)
            return 1
        for u in units:
            print(f"{u['section']}\t" + "\t".join(u["keys"]))
        return 0

    out = project(cfg, config.resolve(TARGET, pol))   # Ω·config: pandoc (default) | web

    if config.resolve(CHECK):
        tgt = cfg["out"]
        if not tgt.exists() or tgt.read_text() != out:
            print(f"paperkit-project: {tgt.name} ≠ projection — regenerate "
                  f"(paperkit-project)", file=sys.stderr)
            return 1
        print(f"paperkit-project: {tgt.name} ≡ projection ({len(out.split())} words)")
        return 0
    if "-o" in argv and argv[argv.index("-o") + 1] == "-":
        sys.stdout.write(out)
        return 0
    durable.write_atomic(cfg["out"], out)
    print(f"paperkit-project: wrote {cfg['out'].name} ({len(out.split())} words)", file=sys.stderr)
    return 0


def _cli():
    """Console-script entry point (pyproject [project.scripts]).

    A wheel cannot point an entry point at `__main__`, so the same one-liner is named here
    and reused below — one call site, not two implementations that can drift.
    """
    raise SystemExit(main(sys.argv[1:]))


if __name__ == "__main__":
    _cli()
