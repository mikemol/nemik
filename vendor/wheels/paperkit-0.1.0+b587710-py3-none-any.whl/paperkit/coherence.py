#!/usr/bin/env python3
"""paperkit coherence (∂²) — measure how far a project's DECLARED structure reflects
its MEASURED sensitivity: the boundary-of-a-boundary residual.

Δ grades whether each check CAN fail; ∂² asks whether the structure the claims declare
actually shows up in what makes them fail.  Three faces, all read from the existing
pipeline (`discriminate --resolution def --json`), so nothing new is measured — re-read:

  STRUCTURE   prose is a LINEARIZATION of the claim-DAG.  A grounding (`rests-on`) edge
              between prose-ADJACENT claims is carried by the connective for free; a
              NON-ADJACENT one is a LONG EDGE the linear text owes a projected cross-
              reference (citation / figure / expounding — what a connective IS at distance
              > 0).  The residual is the long edges not yet projected.

  SENSITIVITY each claim's measured sensitivity set is its Δ `tests` (the inputs whose
              corruption flips it).  --without-K makes the witnesses NAME-distinct, but
              they may still COLLAPSE to one sensitivity signature — name-distinct yet
              measuring the same thing.  At definition resolution every witness carries a
              distinct engine-capability fingerprint, so the collapse closes.

  GROUNDING   each DECLARED grounding edge (rests-on) should be REFLECTED in measured
              sensitivity: a claim that rests-on Y should exercise some of the engine Y
              tests (their fingerprints overlap).  A disjoint edge is discharged when its
              non-reflection is explained — MEASURABLY (X tests no engine capability, so it
              is vacuously disjoint: rhetorical grounding) or by a `link` (the sibling of
              the structure discharge).  Only a GENUINE, un-acknowledged miss is residual.

  EMERGENCE   the STRICTER sibling of grounding (Ζ·emerge): grounding asks per-edge OVERLAP, this
              asks per-claim COVERAGE — does a claim's fingerprint REDUCE to its premises',
              fp(X) ⊆ ∪fp(rests-on)?  A claim that collapses adds no engine discrimination beyond
              its grounding (its witness emerges by consumption — the proof composes); an increment
              tests engine capability no premise does (under-grounded, or an irreducible leaf); a
              leaf is an axiom.  Where grounding's overlap passes, coverage can still catch a delta.

  UNMEASURED  the SYMDIFF of the two graphs the faces above read (Ζ·symdiff).  STRUCTURE is
              computed from the bib, so it counts every edge whose SOURCE is a record;
              GROUNDING and EMERGENCE need a fingerprint at BOTH ends and silently skip an
              edge whose target was never graded.  On a partial grade that gap is invisible
              and large.  Reported so a partial reading declares its own incompleteness:
              `pending` (target awaiting measurement) shrinks to zero as the grade completes,
              `dangling` (target no bib entry declares) is a broken edge and does not.

A high residual is not a failure to hide — it is the gap between what a document SAYS
grounds it and what DEMONSTRABLY does, surfaced so it can be closed (move-unification
for structure; definition-resolution fingerprints for sensitivity, grounding, and emergence).

    coherence.py [DIR]            # the residual report
    coherence.py --json [DIR]     # structured
    coherence.py --from-cache [DIR]   # read .delta-cache.json — no re-sweep, partial-grade OK
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

# Ζ·pkg·shape — the engine's own directory, FIRST on sys.path, and it must stay a per-module
# line rather than moving to paperkit/__init__.py: a package __init__ runs only when the
# package is IMPORTED, and these modules are also loaded as siblings by a caller that has
# already put its own directory ahead of ours.  render/checks/ ships its OWN bib.py, so a
# witness inserting that directory shadows the engine's parser and `from bib import
# dep_order` resolves to the wrong module.  MEASURED: removing these six lines reddened
# seven talk claims with "cannot import name 'dep_order' from bib (render/checks/bib.py)".
# The insert is a PRIORITY CLAIM, not a reachability fix — __init__.py handles reachability.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bib

_ENGINE = Path(__file__).resolve().parent
# Ζ·ladder·sentinel — the same REFUSE rung discriminate types (a caller bug the tool will not
# answer), kept numerically identical so a caller reads one alphabet across the engine.
_REFUSE = 3


def _linearize(records: list) -> dict:
    """The prose linearization: each section's claims in dep_order (topological by
    `from`), concatenated in section-first-appearance order.  Returns {key: position}.
    """
    frm = {r["key"]: r.get("from", []) for r in records}
    secs, order = [], {}
    for r in records:                       # sections in first-appearance order
        s = r.get("section")
        order.setdefault(s, []).append(r["key"])
        if s not in secs:
            secs.append(s)
    pos, idx = {}, 0
    for s in secs:
        seen, out = set(), []

        def visit(k):
            if k in seen or k not in order[s]:
                return
            seen.add(k)
            for a in frm.get(k, []):
                visit(a)
            out.append(k)

        for k in order[s]:
            visit(k)
        for k in out:
            pos[k] = idx
            idx += 1
    return pos


def structure_residual(records: list, discharged=frozenset()) -> dict:
    """Face one, by the EDGE-PROJECTION model.  Prose is a LINEARIZATION of the claim-DAG;
    a grounding (`rests-on`) edge to a prose-ADJACENT claim is carried by the connective
    for free, but a NON-ADJACENT one is a LONG EDGE the linear text owes a projected
    cross-reference — a citation / figure / expounding (the same thing a connective is, at
    distance > 0; the direction is the sign of the prose-distance).  The residual is the
    long edges not yet projected; ADVISORY, dischargeable by a `link` footnote (or, the
    constructive close, by actually projecting the reference).
    """
    pos = _linearize(records)
    carried, long_edges = 0, []
    for r in records:
        k = r["key"]
        for y in r.get("rests-on", []):
            if y not in pos or k not in pos:
                long_edges.append((k, y, None))      # cross-scope target — always owed
            elif pos[y] == pos[k] - 1:
                carried += 1                          # the immediate predecessor: connective carries it
            else:
                long_edges.append((k, y, pos[k] - pos[y]))
    undischarged = sum(1 for k, _, _ in long_edges if k not in discharged)
    return {"carried": carried, "owed": len(long_edges), "undischarged": undischarged,
            "long_edges": long_edges}


def grouping_residual(records: list, gamma: float = 1.0, discharged=frozenset()) -> dict:
    """Face five (Ρ·deck·residual) — the AUTHORED section grouping vs the DERIVED one.

    The other faces read the sweep; this one reads only the bib, so it measures wherever a
    project parses.  The question: is `section` a projection of the GROUNDING structure, or
    does it disagree with it?

    σ is the authored partition (claims grouped by `section`).  P* is the partition that
    maximises rests-on MODULARITY, σ-regularized:  P* = argmax_P [ Q_E(P) − γ·d(P, σ) ].
    The residual is d(σ, P*): zero means the authored grouping IS the grounding structure;
    nonzero NAMES the claims whose grounding lives outside their section.

    Two properties that make this honest rather than a beauty contest (both measured, not
    assumed — prototypes/slides.bib's `measured-grounding-is-sparse-and-section-aligned`):

      * modularity's null term means a SINGLE edge contributes ≈0 (chance-expectation cancels
        it), so sparse regions are argmax-INDIFFERENT and the −γ·d term dominates there: the
        ungrounded tail falls back to σ BY CONSTRUCTION, not by a special case.  ~40% of claims
        having no rests-on edge is therefore not a defect of the measure.
      * γ is the deck-analog of --min-strength: γ→∞ recovers pure section, γ→0 pure modularity.

    We do NOT gate "is the modularity optimal" (unfalsifiable, a value judgment).  We report
    the residual and the claims it names — a claim P* pulls out of its section is either
    MISFILED or a deliberate cross-reference the prose owes a callback.

    DISCHARGE (Ρ·deck·residual·gate).  The second case is common and legitimate: a thesis claim
    that forward-references machinery defined later grounds outside its section BY DESIGN.  So a
    named claim carrying a `link` footnote is DISCHARGED, exactly as the structure and grounding
    faces discharge theirs — the author has acknowledged the divergence and said why.  `residual`
    stays the raw count (the measurement); `undischarged` is the gateable number.  Without this
    split a --max-residual gate would red on correct forward references, i.e. measure the wrong
    thing while looking rigorous.
    """
    keys = [r["key"] for r in records]
    sec = {r["key"]: r.get("section") for r in records}
    sigma = {}
    for r in records:
        sigma.setdefault(r.get("section"), []).append(r["key"])

    # Ρ·deck·residual·wire — the PARTITION is computed by genre.partition (the project component,
    # which delta depends on), not duplicated here.  One owner, two consumers: the projector cuts
    # a deck on this partition, this face measures how far it sits from the authored sigma.  A
    # second copy would drift, and the residual would then be measuring a grouping no deck uses.
    import genre
    g = genre.partition(records, gamma)
    if g["degenerate"]:
        return {"claims": len(keys), "edges": 0, "residual": 0, "undischarged": 0,
                "gamma": gamma, "sections": len(sigma), "moved": [], "acknowledged": [],
                "degenerate": True, "within_sigma": 0, "within_frac": None}
    part, edges, within = g["part"], g["edges"], g["within"]
    moved = sorted(k for k in keys if part[k] != sec[k])
    ack = [k for k in moved if k in discharged]
    return {"claims": len(keys), "edges": edges, "residual": len(moved),
            "undischarged": len([k for k in moved if k not in discharged]),
            "gamma": gamma, "sections": len(sigma), "moved": moved, "acknowledged": ack,
            "degenerate": False, "within_sigma": within,
            "within_frac": round(within / edges, 3) if edges else None}


def sensitivity_residual(records: list) -> dict:
    """Face two: how many DISTINCT sensitivity signatures the behavioral witnesses
    actually have, vs how many name-distinct witnesses there are.  The collapse is the
    count that share their signature with another (name-distinct, sensitivity-same).
    """
    sigs: dict = {}
    for r in records:
        if r.get("grade") != "behavioral":
            continue
        sigs.setdefault(tuple(sorted(r.get("tests", []))), []).append(r["key"])
    classes = sorted(sigs.values(), key=len, reverse=True)
    behavioral = sum(len(c) for c in classes)
    largest = classes[0] if classes else []
    return {
        "behavioral": behavioral,
        "signatures": len(classes),
        "collapse": behavioral - len(classes),          # redundant witnesses, by sensitivity
        "largest_class": len(largest),
        "largest_signature": list(largest and sorted(sigs.keys(), key=lambda k: len(sigs[k]))[-1]),
    }


def scope_residual(records: list) -> dict:
    """Face six (Ξ·entails) — the DECLARED scope vs the MEASURED reach.

    `entails = {fragment}` is an author saying "this witness covers PART of what the sentence
    claims".  Every other axis here reads a measurement; this one reads a declaration, so on its
    own it is just a word — and a word that lowered its own grade would be self-fulfilling.  This
    face is what makes it falsifiable: the disclosure has to CORRESPOND to the evidence.

    ⚑ What can be checked SOUNDLY is narrower than "is the fragment real", and saying so matters.
    `tests` records which def-sites flip the check, not what proportion of a SENTENCE it covers —
    no sweep can know the latter, because the shortfall lives between prose and code.  So this
    face does not attempt a coverage ratio.  It checks the one direction the measurement genuinely
    contradicts:

      · `fragment` on a witness with NO measured reach (vacuous/indeterminate, `tests` empty).
        A fragment claims the witness reaches PART of the sentence; a witness that nothing flips
        reaches none of it.  The disclosure describes a partial proof where there is no proof, and
        reads as modesty while being an overclaim — the worse direction, since a reader takes
        `fragment` as "less than all" rather than "possibly nothing".

    Everything else is REPORTED, not judged: `full` claims are the default and unremarkable, and a
    `fragment` on a behavioral witness is exactly what the axis is for.  The residual is the count
    of contradicted disclosures — a face that reds only where the declaration and its own evidence
    cannot both be true.
    """
    # Read the AUTHORED field, falling back to the clamp-annotated one.  `scope` is written by
    # grade.clamp; reading only that would make this face silently empty on any record that had
    # not been through it — a face that measures nothing while reporting residual 0 is the
    # degenerate-green this whole apparatus exists to refuse.  `entails` is the author's own word
    # and is always present when declared, so it is the primary read.
    declared = [r for r in records
                if (r.get("entails") or r.get("scope") or "full") != "full"]
    contradicted = [r["key"] for r in declared
                    if not r.get("tests") and r.get("grade") in ("vacuous", "indeterminate")]
    return {
        "declared": len(declared),                      # claims disclosing a shortfall
        "behavioral": len([r for r in declared if r.get("grade") == "behavioral"]),
        "residual": len(contradicted),                  # disclosures their evidence contradicts
        "contradicted": sorted(contradicted),
        # Ζ·symdiff, one face over — `residual: 0` over ZERO declarations is not a clean bill, it
        # is a face that measured nothing, and the two render identically once collapsed to a
        # count.  A corpus where no claim declares a scope is the CURRENT state of every project
        # here, so this is the common reading, not an edge case: say which one it is.
        "measured": bool(declared),
    }


def _engine_cap(tests, universal=frozenset()) -> set:
    """The capability fingerprint — the sites that DISCRIMINATE this claim from its siblings.

    Ζ·torsor — the faces below are set algebra over fingerprints (`S[k] - ∪S[premises]`,
    pairwise intersection, equality classes).  That algebra is FRAME-INDEPENDENT: differences
    between fingerprints carry the meaning, the absolute origin does not.  So what must be
    fixed is not WHICH subtree the sites live in, but which sites are UNINFORMATIVE — the ones
    every witness trips, on which overlap is trivially satisfied and tells you nothing.

    This used to hardcode one frame: sites under `paperkit/`, minus `paperkit/tests/`.  That is
    right for a project whose witnesses exercise the ENGINE, and empty for one whose witnesses
    are self-contained — gcalculus's checks run `python3 concepts.py <key>` and never open a
    paperkit module, so every fingerprint came back empty and `_vacuous_exit` refused a document
    that is in fact richly discriminating (14 def-granular sites on its first claim alone).  The
    measurement was not degraded; it was being read in the wrong frame.

    So the shared scaffolding is now COMPUTED rather than named: the sites present in EVERY
    cited claim's fingerprint are the frame's origin, and quotienting them out leaves exactly
    the discrimination.  For the engine case this derives what the old constant asserted (the
    fixture builder is in every witness's footprint); for a self-contained project it derives
    the dispatcher and the assertion guard instead.  Nothing is declared, so nothing can go
    stale against the thing it describes.

    With FEW claims graded, everything looks universal and the fingerprints collapse toward
    empty.  That is not a flaw in the measure — it is the measure reporting that coverage is too
    thin to discriminate, and the answer is to grade more claims.

    Ζ·torsor·own — the computed quotient does NOT subsume one structural exclusion, and dropping
    it was a regression the boundary suite caught: a claim's OWN check script (`checks/<claim>`)
    is per-claim by construction, so it is never in the intersection and no amount of coverage
    will remove it.  It must go by KIND, not by frequency: a witness co-flipping with its own
    script is the check testing itself, which is evidence about the mechanism and never about
    the claim.  `paperkit/tests/` (the shared fixture builder) is the same argument at the
    engine's scale.  So the frame is a COMPOSITION — structural exclusion by kind, then the
    computed quotient by universality — and only the old `paperkit/`-only INCLUSION filter is
    gone, since that is the part that made a self-contained project read as vacuous.
    """
    return {t for t in tests
            if t not in universal
            and not t.startswith("checks/")
            and not t.startswith("paperkit/tests/")}


def _universal_sites(records: list) -> frozenset:
    """The sites EVERY cited claim's sensitivity contains — the frame origin to quotient out.

    Intersection over all fingerprints.  A site every witness trips (a dispatcher, an assertion
    guard, the bib the gate re-reads) cannot separate two claims, so leaving it in makes
    grounding overlap trivially true.  Empty intersection ⇒ nothing is universal ⇒ every site
    already discriminates, and the quotient is the identity.

    Computed over the STRUCTURALLY-admissible sites only (see `_engine_cap`): a claim's own
    check script and the shared fixture builder are excluded by kind first, so they can neither
    pollute the intersection nor be double-counted by it.

    Ν·frame — universality needs SIBLINGS to be meaningful.  With a single fingerprint every
    site it holds is trivially in the intersection, so the quotient would empty it and the
    measurement would read vacuous — conflating "every claim tests the same thing" (genuinely
    undiscriminating) with "there is only one claim" (nothing to discriminate FROM).  Below two
    fingerprints the frame is UNDEFINED, and the identity quotient is the honest answer: report
    what was measured rather than subtract a frame that was never established.
    """
    sets = [{t for t in r.get("tests", [])
             if not t.startswith("checks/") and not t.startswith("paperkit/tests/")}
            for r in records if r.get("tests")]
    sets = [s for s in sets if s]
    if len(sets) < 2:
        return frozenset()
    return frozenset(set.intersection(*sets))


def unmeasured_edges(records: list, all_keys=frozenset()) -> dict:
    """Ζ·symdiff — the edges STRUCTURE counts that the MEASURED faces cannot see.

    The faces read two different graphs and never said so.  STRUCTURE is computed from the bib
    alone, so it counts every `rests-on` edge whose SOURCE is in the record set.  GROUNDING and
    EMERGENCE need a fingerprint at BOTH ends: grounding's `if not sy: continue` and emergence's
    `[y for y in rests-on if y in S]` both drop an edge whose target was never graded.  On a
    partial grade that difference is silent and large — widening one claim's grounding by three
    edges moved `owed` 8→11 while `reflected`, `undischarged` and `increment` did not move at
    all, which reads as "the edges changed nothing" when the truth is "three faces never saw
    them."

    Worse, `if not sy` CONFLATES two states that mean opposite things:

      measured empty    Y was graded and its fingerprint is empty — Y tests no capability, so
                        the edge is vacuously disjoint.  Rhetorical grounding, auto-discharged.
                        A real verdict.
      never graded      Y has no record at all.  NOT a verdict — the measurement has not looked.

    Reporting them the same way is the sentinel error one level down: *not measurable from here*
    is not *nothing to measure*.  This face separates them, so a partial reading states its own
    incompleteness instead of implying coverage it does not have.  `pending` shrinks to zero as
    the grade completes; a `dangling` edge names a target no bib entry declares at all, which is
    a broken edge rather than an ungraded one and does not shrink.
    """
    graded = {r["key"] for r in records}
    pending, dangling = [], []
    for r in records:
        for y in r.get("rests-on", []):
            if y in graded:
                continue
            (dangling if (all_keys and y not in all_keys) else pending).append([r["key"], y])
    return {"pending": pending, "dangling": dangling,
            "unmeasured": len(pending) + len(dangling)}


def grounding_residual(records: list, discharged=frozenset(), universal=frozenset()) -> dict:
    """Face three (the comparison the roadmap reserved): does each DECLARED grounding
    edge (`rests-on`) show up in MEASURED sensitivity?  A claim X that rests-on Y should
    exercise some of the engine Y tests — their engine-capability fingerprints should
    OVERLAP.  A disjoint edge X→Y is discharged when its non-reflection is EXPLAINED:

      rhetorical    X tests no engine capability at all (an empty fingerprint), so the
                    edge is VACUOUSLY disjoint — a thesis/meta claim grounded rhetorically,
                    not behaviourally.  This is MEASURED, not asserted: it auto-discharges.
      acknowledged  X DOES test engine capability, just not Y's, but a `link` footnote
                    acknowledges it (the sibling of the structure face's discharge).

    Only a GENUINE miss — X tests engine capability, disjoint from Y's, and un-acknowledged
    — is the residual: declared grounding the measurement does not see and no one explained.
    """
    S = {r["key"]: _engine_cap(r.get("tests", []), universal) for r in records}
    edges = reflected = rhetorical = undischarged = 0
    misses = []
    for r in records:
        k = r["key"]
        sx = S.get(k, set())
        for y in r.get("rests-on", []):
            sy = S.get(y)
            if not sy:                          # Y measures no engine capability — no claim to test
                continue
            edges += 1
            if sx & sy:
                reflected += 1
            elif not sx:
                rhetorical += 1                 # X's fingerprint is empty — vacuously disjoint (measured)
            elif k in discharged:
                pass                            # author-acknowledged via a `link` footnote
            else:
                undischarged += 1
                misses.append([k, y])
    return {"grounding_edges": edges, "reflected": reflected, "rhetorical": rhetorical,
            "undischarged": undischarged, "misses": misses}


def emergence_residual(records: list, universal=frozenset()) -> dict:
    """Face four (Ζ·emerge): the STRICTER sibling of grounding.  Grounding asks per-edge OVERLAP
    (does X exercise SOME of what Y tests); emergence asks per-claim COVERAGE — does the claim's
    engine fingerprint REDUCE to its premises', fp(X) ⊆ ∪fp(rests-on)?  A claim that COLLAPSES adds
    no engine discrimination beyond its grounding: its witness is redundant and EMERGES by
    consumption (the proof composes — Ζ·compose).  A claim with an INCREMENT tests engine capability
    NO premise does (the delta).  An increment is NOT by itself an under-grounding: a def-fingerprint
    records what the CHECK exercises, which includes the check's MECHANISM (the engine it RUNS to
    verify a thesis — e.g. a claim about the bib whose check runs the resolver to confirm a check
    resolves) and the claim's OWN origin-capability, not only the thesis's grounding.  So an increment
    means KEEP / contributes (collapse-safe), and reads three ways: under-grounded (add the missing
    rests-on), the claim's irreducible contribution, or pure check mechanism.  The sound under-grounding
    signal is the GROUNDING face (overlap), not this one.  A LEAF (no rests-on) is an axiom.  Where
    grounding's OVERLAP can pass (the edge shares one site) while the claim still tests more,
    emergence's SUBSET catches it: the residual is the increments — claims the grounding does not COVER.
    """
    S = {r["key"]: _engine_cap(r.get("tests", []), universal) for r in records}
    collapse = leaf = 0
    increments = []
    for r in records:
        k = r["key"]
        prem = [y for y in r.get("rests-on", []) if y in S]
        if not prem:
            leaf += 1
            continue
        delta = sorted(S.get(k, set()) - set().union(*[S[y] for y in prem]))
        if delta:
            increments.append([k, delta])
        else:
            collapse += 1
    return {"collapse": collapse, "increment": len(increments), "leaf": leaf, "increments": increments}


def report(records: list, discharged=frozenset(), all_keys=frozenset()) -> dict:
    cited = [r for r in records if r.get("cited", True)]
    # Ζ·torsor — derive the frame ONCE from the whole record set, then measure every face in it.
    # The origin (the universal sites) is computed, not declared, so it cannot go stale.
    universal = _universal_sites(cited)
    return {"claims": len(cited),
            # Ν·vac — vacuous iff no cited claim retains ANY discriminating site once the frame's
            # origin is quotiented out.  This is now FRAME-RELATIVE and therefore honest: a
            # document whose witnesses all trip exactly the same sites cannot be told apart by
            # this measurement, whether that is a degraded sweep or a corpus too thinly graded to
            # separate.  Either way no real verdict is possible — callers must refuse green.
            "vacuous": bool(cited) and not any(_engine_cap(r.get("tests", []), universal)
                                               for r in cited),
            "frame": {"universal": sorted(universal), "quotiented": len(universal)},
            "structure": structure_residual(cited, discharged),
            "sensitivity": sensitivity_residual(cited),
            "grounding": grounding_residual(cited, discharged, universal),
            "emergence": emergence_residual(cited, universal),
            # Ρ·deck·residual — the AUTHORED section grouping vs the grounding-derived one.
            # Reads only the bib (no sweep), so it is meaningful even on a degraded grade.
            "grouping": grouping_residual(cited, discharged=discharged),
            # Ξ·entails — the DECLARED scope against the measured reach.  Like grouping this reads
            # a bib declaration, but unlike it the declaration is checked against the SWEEP, so it
            # is meaningful only where a grade was established.
            "scope": scope_residual(cited),
            # Ζ·symdiff — what STRUCTURE counted and the measured faces could not see.  Reported
            # beside them so a partial reading declares its own incompleteness.
            "unmeasured": unmeasured_edges(cited, all_keys)}


def _records(project_dir: Path) -> list:
    # def resolution: the sensitivity face is only meaningful at the per-definition
    # fingerprint — at file resolution every witness collapses to the import-crash
    # signature.  This is the costly grade (the on-demand precision pass), not the hook's.
    r = subprocess.run([sys.executable, str(_ENGINE / "discriminate.py"),
                        "--resolution", "def", "--json", str(project_dir)],
                       capture_output=True, text=True)
    # Ν·loud — the sweep's exit code is a VERDICT, not noise.  A whole-project --json run returns 0;
    # a non-zero is a real failure (a refused key, a crash) whose stdout is empty or partial, and
    # `json.loads(... or "[]")` would silently read it as an EMPTY document — a vacuous report
    # presented as a real one.  Surface it instead of banking the swallow (finding A's consumer face).
    if r.returncode != 0:
        raise SystemExit(f"Ν·loud: `discriminate --resolution def --json {project_dir}` exited "
                         f"{r.returncode} — the ∂² faces have nothing sound to read.  "
                         f"stderr:\n{r.stderr.strip()}")
    return json.loads(r.stdout or "[]")


def _records_from_calcs(project_dir: Path, calc_files: list) -> list:
    """Ζ·emerge·gate — assemble the records coherence reads from CACHED calc records (the measurement,
    sens) + the bib STRUCTURE (rests-on/section/from), instead of re-running the def-resolution sweep.
    This is what makes the ∂² faces a CHEAP READING over the cached calculation.  The structure comes
    from the canonical parser (paperkit.bib, via bib.parse) — entries already carries rests-on.
    """
    F = bib.parse_project(project_dir)
    recs = []
    for f in calc_files:
        c = json.loads(Path(f).read_text())
        k = c["claim"]
        st = F.get(k, {})
        recs.append({"key": k, "tests": c.get("sens", []), "rests-on": st.get("rests-on", []),
                     "section": st.get("section", ""), "from": st.get("from", []),
                     "grade": "behavioral" if c.get("sens") else "vacuous", "cited": True})
    return recs


def _coverage(project_dir: Path, records: list) -> tuple:
    """Ζ·cohere·artifact — how much of the bib's GROUNDING GRAPH this calc set actually covers.

    A partial calc set does not fail; it computes a confident answer over a fraction of the graph
    and reports it as if it were the whole.  Measured, and it cost a day: `:cohere` consumes the
    def-sweep certificates (`__dcalc`), and a reproduction that globbed `*.calc.json` picked up 86
    file-resolution `__calc` records and 1 certificate.  It read 39 of the bib's 80 rests-on edges,
    reported "39/39 reflected, 0 undischarged", and that number was offered as the evidence a gate
    was fixed.  Both real misses were in the 41 edges the reading could not see.

    So the reading NAMES its own coverage.  This is the Ζ·pi·unresolved discipline one level down:
    an incomplete observation must not be indistinguishable from a complete one, and the fix is
    never to guess the remainder — it is to say what was not looked at.
    """
    have = {r["key"] for r in records}
    # ⚑ ELIGIBLE, not ALL.  The denominator is the claims that CAN carry a def-sweep certificate:
    # a `concept:` claim is graded by its OWNING library and imported as a certificate (Π-typed
    # delegation — re-deriving an owner's grade in the importing view is exactly what delegation
    # refuses), and a `cmd:` claim has no def-site grid at all.  Counting them as coverage GAPS
    # conflates "not looked at" with "not lookable at", and the refusal then fires on a reading
    # that is complete.  Measured on paper: 112 bib claims, 85 with a local certificate, and of
    # the 27 without, 26 are `concept:` imports and 1 is `cmd:` — none of them a miss.
    F = F_of(project_dir)
    eligible = {k: f for k, f in F.items()
                if not str(f.get("check") or "").startswith(("concept:", "cmd:"))}
    edges = sum(len(f.get("rests-on") or []) for f in eligible.values())
    seen = sum(len(r.get("rests-on") or []) for r in records)
    return len(have & set(eligible)), len(eligible), seen, edges


def F_of(project_dir: Path) -> dict:
    return bib.parse_project(project_dir)


def _records_from_cache(project_dir: Path) -> list:
    """Ζ·emerge·resume — assemble the records from `.delta-cache.json`, the cache `discriminate`
    ALREADY writes, instead of re-running the sweep or reading Bazel calc artifacts.

    The third records source, and the one a plain checkout can use.  `_records` shells out to a
    full `--resolution def` sweep with no --state and no --budget: unresumable, and measured at
    3.5h on a 118-claim project before a kill discarded all of it.  `_records_from_calcs` is the
    cheap path but reads per-claim calc files that only the Bazel pipeline produces.  Between
    them sat the artifact that makes the ∂² faces readable anywhere: the per-check cache, keyed
    on each check's read footprint over the engine epoch, which `discriminate --state/--budget`
    accumulates ACROSS bounded increments.

    So the residual becomes a reading over WHATEVER HAS BEEN GRADED SO FAR.  A partial cache
    yields a partial report — the faces are per-claim, so a claim absent from the cache is simply
    not among the records, exactly as an uncited one is not.  That is what makes a work-list
    derivable incrementally rather than only after a sweep runs to completion: grade for ten
    minutes, read what is known, grade ten more.

    A `file`-resolution cache is REFUSED rather than read: at file resolution every witness
    collapses to the import-crash signature (the reason `_records` asks for def), so reading one
    would feed the sensitivity, grounding and emergence faces a measurement that cannot
    discriminate — and `_vacuous_exit` would then report a vacuous DOCUMENT rather than a wrong
    tool.  Ν·loud: refuse, naming the resolution found, rather than degrade.
    """
    # Both refusals below are REFUSE (_REFUSE = 3, discriminate's alphabet), not a floor-unmet 1:
    # pointing this at a project with no cache, or with a file-resolution one, is a CALLER BUG the
    # tool will not answer — the same category as an unknown --only key.  `raise SystemExit(str)`
    # exits 1, which read as "a threshold was missed" and put a caller bug in the verdict channel.
    p = project_dir / ".delta-cache.json"
    if not p.is_file():
        print(f"Ν·loud: no .delta-cache.json in {project_dir} — run "
              "`discriminate.py --resolution def --state S --budget N` first", file=sys.stderr)
        raise SystemExit(_REFUSE)
    cached = json.loads(p.read_text())
    if cached.get("resolution") != "def":
        print(f"Ν·loud: .delta-cache.json is {cached.get('resolution')!r} resolution, not 'def' — "
              "at file resolution every witness collapses to the import-crash signature, so the "
              "sensitivity, grounding and emergence faces would read a measurement that cannot "
              "discriminate.  Re-grade with --resolution def.", file=sys.stderr)
        raise SystemExit(_REFUSE)
    F = bib.parse_project(project_dir)
    # a check may serve SEVERAL claims (binding dilution) — the cache keys by check, the faces
    # key by claim, so one cached grade fans out to every claim citing it.
    by_check: dict = {}
    for k, f in F.items():
        if f.get("check"):
            by_check.setdefault(f["check"], []).append(k)
    recs = []
    for chk, entry in sorted(cached.get("checks", {}).items()):
        g = entry.get("grade") or {}
        for k in by_check.get(chk, []):
            st = F.get(k, {})
            recs.append({"key": k, "tests": g.get("tests", []),
                         "rests-on": st.get("rests-on", []), "section": st.get("section", ""),
                         "from": st.get("from", []), "grade": g.get("grade", "indeterminate"),
                         "cited": True})
    return recs


def _all_keys(project_dir: Path) -> frozenset:
    """Every key the bib DECLARES — the set against which an ungraded target is `pending`
    (a claim awaiting measurement) rather than `dangling` (an edge to nothing at all).
    """
    F = bib.parse_project(project_dir)
    return frozenset(F)


def _discharged(project_dir: Path) -> set:
    """Claims carrying a `link` footnote — the author has acknowledged that this claim's
    prose and grounding edges diverge, and why; that discharges the advisory.
    """
    F = bib.parse_project(project_dir)
    return {k for k, f in F.items() if f.get("link")}


def _vacuous_exit(project_dir: Path, rep: dict) -> bool:
    """Ν·vac — print + signal when the measurement carries NO engine capability at all, so a
    caller never reports a verdict (green or red) over a vacuous def-sweep.
    """
    if not rep["vacuous"]:
        return False
    print(f"Ν·vac: coherence over {project_dir.name or project_dir}: NO claim tests any engine "
          f"capability ({rep['claims']} claims, every fingerprint empty) — a vacuous measurement "
          f"(a degraded def-sweep?); refusing to emit a verdict.", file=sys.stderr)
    return True


def _grounding_exit(rep: dict) -> int:
    """Ζ·cohere·mute — the `--from-calcs` gate exit: NAME the undischarged edges, then signal.

    This arm is what `//:cohere` runs, and it used to `return 1` in silence.  The verdict record
    downstream carries only {"verb","verdict"}, so a red gate said exactly `fail` and nothing
    else — while `misses` (the precise list of which grounding edge the measurement does not
    see) sat computed one field away and was discarded.  Diagnosing one red edge then cost a
    hand reconstruction of a set the code had already built.

    The two sibling exits in this module (`_vacuous_exit`, `_residual_exit`) both print the
    reason to stderr before returning nonzero; this one is the outlier, not the pattern.  A gate
    whose failure carries no residual is not cheaper, it just relocates the work to whoever
    reads it — and it reads as a harness fault (the thing `Ν·vac` exists to distinguish) rather
    than the genuine finding it usually is.
    """
    g = rep["grounding"]
    if g["undischarged"] == 0:
        return 0
    print(f"coherence: GROUNDING {g['undischarged']} of {g['grounding_edges']} rests-on edge(s) "
          f"un-acknowledged — the claim tests engine capability, but DISJOINT from its premise's. "
          f"Overlap the fingerprints, or discharge with a `link` stating why they diverge:",
          file=sys.stderr)
    for x, y in g["misses"]:
        print(f"  [@{x}] rests-on [@{y}] — tests engine capability, but not [@{y}]'s",
              file=sys.stderr)
    return 1


def _residual_exit(rep: dict, max_resid) -> int:
    """The Ρ·deck·residual·gate exit: 0 unless an explicit budget is exceeded by the
    UN-ACKNOWLEDGED residual.  No flag → always 0 (instrument, not control).
    """
    if max_resid is None:
        return 0
    gr = rep["grouping"]
    if gr["undischarged"] > max_resid:
        print(f"coherence: GROUPING RESIDUAL {gr['undischarged']} exceeds --max-residual "
              f"{max_resid} — {gr['undischarged']} claim(s) group outside their section with no "
              f"`link` acknowledging why.  Refile them, or discharge each with a `link` stating "
              f"the cross-reference it makes: "
              f"{[k for k in gr['moved'] if k not in gr['acknowledged']]}", file=sys.stderr)
        return 1
    return 0


def _max_residual(argv: list):
    """Ρ·deck·residual·gate — `--max-residual N`: the grouping face's budget, the deck-analog of
    `--min-strength`.  Absent → the face is an INSTRUMENT (reported, never fatal); present → a
    CONTROL that fails when the UN-ACKNOWLEDGED residual exceeds N.  An instrument earns trust
    per-use by re-verifying its output; a control has to be sound in both directions first, which
    is why the discharge mechanism (a `link` on the named claim) had to land before this flag.
    """
    for i, a in enumerate(argv):
        if a == "--max-residual" and i + 1 < len(argv):
            return int(argv[i + 1])
        if a.startswith("--max-residual="):
            return int(a.split("=", 1)[1])
    return None


def main(argv: list) -> int:
    # Ζ·cohere·help — ANSWER BEFORE MEASURING.  `--help` used to fall through every branch below:
    # it is not a positional, so `pos` came back empty, `project_dir` defaulted to the CWD, and the
    # tool began a full def-sweep — 2+ minutes before printing anything, and then printing a
    # REPORT rather than a usage.  A tool whose help is unreachable without paying for a
    # measurement has no help; the flag is answered here, first, touching nothing.
    if "--help" in argv or "-h" in argv:
        print(__doc__.strip().split("\n\n")[0])
        print("\nusage: coherence.py [project] [--json] [--from-calcs <calc.json>...] "
              "[--from-cache] [--max-residual N]\n"
              "  (no project)        the current directory\n"
              "  --json              emit the full report as JSON, not just the exit verdict\n"
              "  --from-calcs …      read CACHED def-sweep certificates (__dcalc) — no re-sweep;\n"
              "                      REFUSES (exit 2) if the calc set covers only part of the graph\n"
              "  --from-cache        read the accumulated per-check cache from --state increments\n"
              "  --max-residual N    fail when the grouping residual exceeds N\n"
              "\nExit: 0 coherent, 1 a face is red, 2 CANNOT-RUN (a partial or vacuous reading).\n"
              "⚑ Bare, this SWEEPS: it grades every check to fingerprint it, which is minutes, not\n"
              "  seconds.  --from-calcs is the gate's path and reads what the build already banked.")
        return 0
    as_json = "--json" in argv
    max_resid = _max_residual(argv)
    # the flag's VALUE is not a positional project dir
    argv = [a for i, a in enumerate(argv)
            if not (a == "--max-residual" or a.startswith("--max-residual=")
                    or (i and argv[i - 1] == "--max-residual"))]
    pos = [a for a in argv if not a.startswith("-")]
    project_dir = Path(pos[0]).resolve() if pos else Path.cwd()
    if "--from-calcs" in argv:
        # Ζ·emerge·gate — cheap coherence: read CACHED calc records (sens) + the bib structure, no
        # re-sweep.  pos = [project, calc.json...].  The gateable reading over the calculation.
        recs = _records_from_calcs(project_dir, pos[1:])
        n_claims, tot_claims, n_edges, tot_edges = _coverage(project_dir, recs)
        if n_edges < tot_edges:
            # Ζ·cohere·artifact — REFUSE a partial reading rather than report it as whole.  Exit 2
            # (cannot-run), never 0 or 1: a measurement over part of the graph is neither a pass
            # nor a refutation, and reading it as either is the error this guard exists for.
            print(f"Ν·partial: coherence over {project_dir.name or project_dir}: the calc set "
                  f"covers {n_claims}/{tot_claims} claims and {n_edges}/{tot_edges} rests-on "
                  f"edges — an INCOMPLETE reading.  `:cohere` consumes the def-sweep certificates "
                  f"(__dcalc); a glob that also matches file-resolution __calc records silently "
                  f"reads a fraction of the graph.  Refusing to emit a verdict.", file=sys.stderr)
            return 2
        rep = report(recs, _discharged(project_dir), _all_keys(project_dir))
        if as_json:
            print(json.dumps({"document": project_dir.name or str(project_dir), **rep}, indent=2))
        if _vacuous_exit(project_dir, rep):
            return 2
        return _grounding_exit(rep)
    # Ζ·emerge·resume — read the accumulated per-check cache instead of re-sweeping.  Same
    # faces, same report; the measurement comes from whatever `--state/--budget` increments
    # have graded so far, so a partial grade yields a partial (never a wrong) reading.
    src = _records_from_cache if "--from-cache" in argv else _records
    rep = report(src(project_dir), _discharged(project_dir), _all_keys(project_dir))
    if as_json:
        print(json.dumps({"document": project_dir.name or str(project_dir), **rep}, indent=2))
        if rep["vacuous"]:
            return 2
        # the --max-residual control applies to EVERY output mode: a gate a caller can disable by
        # asking for JSON is not a gate.
        return _residual_exit(rep, max_resid)
    if _vacuous_exit(project_dir, rep):
        return 2
    s, se, g, e = rep["structure"], rep["sensitivity"], rep["grounding"], rep["emergence"]
    print(f"coherence (∂²): {project_dir.name or project_dir} — {rep['claims']} cited claims")
    print(f"  structure  : {s['carried']} grounding edges carried by the prose connective, "
          f"{s['owed']} are LONG edges owed a projected cross-reference; {s['undischarged']} "
          f"un-acknowledged (advisory — project the reference, or discharge with a `link`)")
    print(f"  sensitivity: {se['behavioral']} behavioral witnesses → {se['signatures']} distinct "
          f"sensitivity signatures ({se['collapse']} collapse); the largest {se['largest_class']} "
          f"share {se['largest_signature']}")
    print(f"  grounding  : {g['reflected']}/{g['grounding_edges']} rests-on edges reflected in "
          f"measured engine sensitivity; {g['rhetorical']} vacuously disjoint (rhetorical — the "
          f"claim tests no engine capability); {g['undischarged']} genuine, un-acknowledged "
          f"(advisory — overlap the fingerprints, or discharge with a `link`)")
    for x, y in g["misses"]:
        print(f"               [@{x}] rests-on [@{y}] — tests engine capability, but not [@{y}]'s")
    print(f"  emergence  : {e['collapse']} claims COLLAPSE (engine sensitivity ⊆ grounding → witness "
          f"emerges by consumption), {e['increment']} INCREMENT (test engine capability beyond their "
          f"grounding), {e['leaf']} LEAF axioms (no grounding → self-contained checks)")
    for x, d in e["increments"]:
        print(f"               [@{x}] +{len(d)} engine site(s) beyond its grounding "
              f"— e.g. {[t.split('::')[-1] for t in d[:3]]}")
    gr = rep["grouping"]
    if gr["degenerate"]:
        print(f"  grouping   : no rests-on edges between cited claims — σ ({gr['sections']} "
              f"sections) is the only partition the grounding graph can express, so the "
              f"residual is trivially 0 (nothing to disagree with)")
    else:
        pct = "—" if gr["within_frac"] is None else f"{gr['within_frac']:.0%}"
        print(f"  grouping   : d(σ,P*) = {gr['residual']} of {gr['claims']} claims move when the "
              f"section grouping is re-derived from rests-on modularity (γ={gr['gamma']}); "
              f"{gr['undischarged']} un-acknowledged; "
              f"{gr['within_sigma']}/{gr['edges']} grounding edges ({pct}) already stay "
              f"within-section")
        for k in gr["moved"]:
            ack = " [discharged by `link`]" if k in gr["acknowledged"] else ""
            print(f"               [@{k}] — its grounding lives outside its section "
                  f"(MISFILED, or a deliberate cross-reference the prose owes a callback){ack}")
    um = rep["unmeasured"]
    if um["unmeasured"]:
        print(f"  unmeasured : {len(um['pending'])} declared edge(s) STRUCTURE counts that "
              f"grounding and emergence CANNOT see — the target is not graded, so those faces "
              f"skip the edge silently; {len(um['dangling'])} point at no bib entry at all")
        for x, y in um["pending"][:6]:
            print(f"               [@{x}] rests-on [@{y}] — target ungraded (grade it to measure)")
        for x, y in um["dangling"]:
            print(f"               [@{x}] rests-on [@{y}] — NO SUCH ENTRY (a broken edge)")
    return _residual_exit(rep, max_resid)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
