#!/usr/bin/env python3
"""Behavioral-boundary examples for environment sanitization — gate.clean_env.

⟨P, F, δ⟩ per the boundary practice.  A check is arbitrary code (cmd: is the universal
escape hatch), so it must run in a CONTROLLED environment, not whatever the gate
inherited — sshd's lesson against env injection.  Bounds: the allow-list keeps what a
check legitimately needs (PATH, locale, paperkit's own knobs) and DROPS the
injection vectors (LD_PRELOAD, IFS, BASH_ENV, PYTHONPATH) and any unknown var; and
within the kept PATH it drops the RELATIVE/empty entries (Τ·path) that would resolve a
tool to the cwd — the project dir being gated.

    python3 paperkit/tests/boundaries_env.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import resolver

DIRTY = {
    "PATH": "/usr/bin" + os.pathsep + "." + os.pathsep + os.pathsep + "rel/x",  # abs kept; .,"",rel dropped
    "HOME": "/h", "LC_ALL": "C", "PAPERKIT_CHECK_MB": "256",         # kept: needed + paperkit's knob
    "LD_PRELOAD": "/evil.so", "IFS": " \t", "BASH_ENV": "/inj.sh",   # dropped: injection
    "PYTHONPATH": "/x", "MEMBUDGET_PARENT": "abcd", "FOO": "bar",    # dropped: injection / retired / unknown
}


def main() -> int:
    fails = []

    ran = []

    def check(desc, cond):
        # Λ·guard-must-not-copy — `ran` COUNTS the arms.  The summary line used to restate a
        # number authored beside the set it describes, and every one of the 26 suites carrying
        # such a line UNDERSTATED it (24 mismatched, none overstated): arms were added and the
        # literal never moved, so it tracked the suite's authoring history rather than its
        # content — and would have read a SHRINKING suite as an unchanged one.
        ran.append(desc)
        fails.append(desc) if not cond else None
        print(f"  {'ok ' if cond else 'XX '}{desc}")

    e = resolver.clean_env(DIRTY)

    print("env-sanitization behaviors\n")
    check("keeps PATH's absolute dirs so a check's tools still resolve", e.get("PATH") == "/usr/bin")
    check("DROPS PATH's relative/empty entries (Τ·path — they resolve to the gated cwd)",
          all(p and os.path.isabs(p) for p in e.get("PATH", "").split(os.pathsep)))
    check("keeps HOME and locale (LC_ALL)", e.get("HOME") == "/h" and e.get("LC_ALL") == "C")
    check("keeps paperkit's own knobs (PAPERKIT_*), DROPS the retired MEMBUDGET_* (Bazel bounds memory)",
          e.get("PAPERKIT_CHECK_MB") == "256" and "MEMBUDGET_PARENT" not in e)
    check("DROPS injection vectors (LD_PRELOAD, IFS, BASH_ENV, PYTHONPATH)",
          not any(k in e for k in ("LD_PRELOAD", "IFS", "BASH_ENV", "PYTHONPATH")))
    check("DROPS unknown vars (FOO) — default-deny, not block-list", "FOO" not in e)
    print()

    print("⟨P, F, δ⟩ minimum-delta pairs\n")
    pairs = [
        ("a var survives iff it is on the allow-list (default-deny)",
         "a variable's membership in the allow-list",
         "PATH (listed) → kept", "PATH" in e,
         "LD_PRELOAD (unlisted) → dropped", "LD_PRELOAD" not in e),
        ("paperkit's own knobs pass; the shell's injection vectors do not",
         "the variable's name (PAPERKIT_CHECK_MB vs BASH_ENV)",
         "PAPERKIT_CHECK_MB → kept", "PAPERKIT_CHECK_MB" in e,
         "BASH_ENV → dropped", "BASH_ENV" not in e),
        ("a PATH entry survives iff it is absolute (Τ·path)",
         "the entry's absoluteness (/usr/bin vs .)",
         "/usr/bin (absolute) → kept", "/usr/bin" in e["PATH"].split(os.pathsep),
         ". (relative, = the gated cwd) → dropped", "." not in e["PATH"].split(os.pathsep)),
    ]
    for name, axis, p_lbl, p_ok, f_lbl, f_ok in pairs:
        ok = p_ok and f_ok
        fails.append(name) if not ok else None
        print(f"  {'ok ' if ok else 'XX '}{name}")
        print(f"      P (pass side): {p_lbl}")
        print(f"      F (flag side): {f_lbl}")
        print(f"      δ (min delta): {axis}\n")

    if fails:
        print(f"BOUNDARIES: FAIL ({len(fails)} drifted)")
        return 1
    bad = len([b for b in ran if not b])
    if bad:
        print(f"BOUNDARIES: FAIL ({bad} of {len(ran)} behaviors drifted)")
        return 1
    print(f"BOUNDARIES: PASS ({len(ran)} behaviors, 3 deltas)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
