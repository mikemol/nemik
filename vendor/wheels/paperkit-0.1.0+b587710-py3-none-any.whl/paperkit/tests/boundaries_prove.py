#!/usr/bin/env python3
"""Ζ·prove·degrade — the prove face's boundary: a certificate is NEVER emitted unmeasured.

A concept witness's --prove face emits ⟨verdict, sensitivity fingerprint⟩.  The degraded arm
of that measurement is the dangerous one: an unreachable/broken engine that still produced a
record would emit `sens: []` — an ABSENT measurement wearing the exact shape of an
INSENSITIVE one (the twice-bitten silent-degradation class, on the one path the grid canary
does not cover).  The contract pinned here, adopted from the downstream consumer's
certificate() (their fingerprint-null-plus-why discipline — the audit's reverse finding):

  P — the same entry point runs green against the REAL engine (the sound path exists);
  F — with the engine UNREACHABLE, --prove exits nonzero and emits NO record at all:
      a fingerprint of [] is only ever a MEASURED result;
  δ — one environment variable (PAPERKIT_ENGINE), presence → absence.

    python3 paperkit/tests/boundaries_prove.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
# ⚑ Ζ·lib·land — the concept library lives INSIDE the package now, so this is ROOT/paperkit/library
# and not ROOT/library.  A SECOND hardcoded copy of a path resolver.py already owns: the engine's
# `_LIBRARY` was fixed when a consumer's gate went UNRESOLVABLE on the composed old path, and this
# copy stayed wrong because nothing connects them — the same set held in two places, which is why
# a guard that carries its own copy of what it guards certifies a tautology until the copy drifts.
LIB = ROOT / "paperkit" / "library"


def main() -> int:
    # Ζ·suite·count — the recorder is SHARED, so the summary has an owner.  This suite's local
    # `check` appended to `fails` alone: it recorded what BROKE and never what RAN, so its
    # summary line had no accumulator to derive from and printed a literal ("1 sound arm, 2
    # degraded-arm refusals") that no arm could move.  `Suite` counts the arms it is given.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from _boundary import Suite
    s = Suite("PROVE", "Ζ·prove·degrade — a certificate is never emitted unmeasured")
    check = s.check

    # P — the sound path: the same entry point, real engine, cheap verdict mode (the prove
    # mode's full def-sweep is gated separately as the library's __dcalc in //:hook — not
    # re-swept here; one oracle, two gates would drift).
    p = subprocess.run([sys.executable, str(LIB / "concepts.py"), "claim-is-record"],
                       cwd=LIB, capture_output=True, text=True)
    check("P: the entry point runs a concept green against the REAL engine", p.returncode == 0)

    # F — the degraded arm: an engine that is not there.  The prove face must fail LOUD with
    # NO record — never a certificate whose empty fingerprint reads as "nothing flips it".
    with tempfile.TemporaryDirectory() as d:
        env = {**os.environ, "PAPERKIT_ENGINE": d}
        f = subprocess.run([sys.executable, str(LIB / "concepts.py"), "adequacy-pitch", "--prove"],
                           cwd=LIB, capture_output=True, text=True, env=env)
    check("F: with the engine unreachable, --prove exits NONZERO", f.returncode != 0)
    emitted_record = False
    for line in f.stdout.splitlines():
        try:
            emitted_record |= isinstance(json.loads(line), dict)
        except ValueError:
            pass
    check("F: ...and emits NO record (an absent measurement cannot masquerade as an insensitive one)",
          not emitted_record and '"fingerprint"' not in f.stdout)

    s.delta("a certificate is emitted only when the engine was REACHABLE to measure",
            p.returncode == 0, not emitted_record,
            p="real engine:   concepts.py <key> → exit 0",
            f="engine absent: concepts.py <key> --prove → nonzero, zero records emitted",
            d="one env var — PAPERKIT_ENGINE, present → an empty dir")
    return s.finish()


if __name__ == "__main__":
    raise SystemExit(main())
