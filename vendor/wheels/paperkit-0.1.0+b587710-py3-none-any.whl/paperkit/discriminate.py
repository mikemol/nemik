#!/usr/bin/env python3
"""paperkit discriminate (Δ) — grade each warrant's check by whether it can FAIL.

A check earns a claim only to the extent it is sensitive to the world: a check
that passes no matter what the project says verifies nothing.  The gate enforces
that every sentence NAMES a passing check; Δ asks the next question — could that
check ever have failed?  It grades every warrant's `check` on a computable
discrimination ladder, and for runnable (cmd/custom) checks it empirically
discovers the check's SENSITIVITY SET — the input files whose corruption flips
the check red — by single-file mutation in a throwaway sandbox.

Grades (this is also the `strength` field that Γ — graded thresholds — will read):

  vacuous     PROVABLY cannot fail: a file: check whose target is a required
              project input or engine source, so its existence is presupposed by
              the build itself.  Tests presence of something that must be there
              anyway — 0 bits about the claim.
  existence   file: of a CONTINGENT artifact (a build output, a figure) — its
              absence is a real failure, so it discriminates "the artifact was
              produced", but nothing about the artifact's content.
  behavioral  PROVEN falsifiable: some single-file mutation flips this cmd/custom
              check red.  It runs, and it can go red — the sensitivity set names
              exactly which inputs it actually tests.
  indeterminate  a cmd/custom check that no generic mutation could flip.  Either
              genuinely vacuous OR a NEGATIVE-ASSERTION check (one that passes
              precisely when the system correctly rejects bad input, e.g. a
              drift-rejection test — garbage input keeps the rejection true).
              Δ refuses to guess: falsifiability is not demonstrated.  Closing
              this needs a targeted counter-fixture (a Π task), not a verdict.

Δ does NOT judge whether a behavioral check's sensitivity set actually concerns
the CLAIM's content — a check sensitive to the right files for the wrong claim is
the launder case, left to Λ.  Δ reports the set; Λ judges relevance.

Binding dilution: a check shared by N cited claims supplies one verdict for N
sentences — reported as `shared_with`, the per-claim signal being the per-check
signal split N ways.

    paperkit-discriminate [DIR]                  report (exit 0)
    paperkit-discriminate --min-strength L [DIR] gate: exit 1 if any considered
                                                 warrant grades below L
                                                 (L = existence | behavioral)
    paperkit-discriminate --all [DIR]            grade every checked warrant, not
                                                 just those cited in the prose
    paperkit-discriminate --json [DIR]           machine output (feeds Γ / Π)
    paperkit-discriminate --state F --budget S [DIR]   resumable grading (pump-witness):
                                                 grade under an S-second budget, persist the
                                                 token to F, exit 2 if not done — re-run to
                                                 resume.  A slow grade resumes, never dies.

Exit codes are TYPED (a resume loop must tell "call me again" from "you asked wrong"):
  0  done            1  an adequacy floor (--min-strength/--corroboration) was not met
  2  INCOMPLETE, resume — the pump-witness spent its budget; re-run to continue
  3  REFUSE          — a caller bug the engine will not answer (unknown --only key, or a
                       resumption token written against a different stale set).  Distinct
                       from 2 so a resume loop aborts on a bug instead of spinning on it.
    paperkit-discriminate --no-cache [DIR]       ignore the content-addressed cache

Grades are memoized PER CHECK (Δ·footprint-cache): each check's grade is keyed on the
content of the files it actually READS (Φ·footprint) plus a global engine epoch, so a
commit re-grades only the checks whose footprint the diff touched — not the whole
project.  (.delta-cache.json, git-ignored.  content_key below is the coarse soundness
basis the per-check key refines: a grade is a pure function of project+engine content.)

DIR defaults to the current directory and must contain paper.toml.
"""
from __future__ import annotations

import json
import sys
import tomllib
from pathlib import Path

# Ζ·pkg·shape — the engine's own directory, FIRST on sys.path, and it must stay a per-module
# line rather than moving to paperkit/__init__.py: a package __init__ runs only when the
# package is IMPORTED, and these modules are also loaded as siblings by a caller that has
# already put its own directory ahead of ours.  render/checks/ ships its OWN bib.py, so a
# witness inserting that directory shadows the engine's parser and `from bib import
# dep_order` resolves to the wrong module.  MEASURED: removing these six lines reddened
# seven talk claims with "cannot import name 'dep_order' from bib (render/checks/bib.py)".
# The insert is a PRIORITY CLAIM, not a reachability fix — __init__.py handles reachability.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bib
import driver as D
import gate as G

# The MODULE bindings whose Ω·config Params join the composed registry below (grader/layout/
# resolver edges already in the cone; project is a NEW direct edge, DEPS-legal delta→project,
# closure-neutral — it was already transitively staged via gate).
import grader
import layout
import project
import resolver

# This file is the Δ CLI + report.  The grade CACHE, project TOPOLOGY, and the GRADER (the
# mutation sweep + the grade ladder) are their own modules now; imported under the names the
# CLI uses, and re-exported so discriminate.content_key / .grade_check callers keep working.
from cache import content_key
from cache import engine_hash as _engine_hash
from cache import footprint_hash as _footprint_hash
from cache import load as _load_cache
from cache import save as _save_cache
from grade import (
    CORRO_C,
    ORDER,
    RANK_C,
    STRENGTH,
    clamp,
    mark_content_sensitive,
)
from grader import (
    UNREACHABLE,          # Ζ·broken·offaxis — the tristate sentinel, carried onto the calc record
    GradeWitness,
    _grade_parallel,
    _sandbox_root,
    grade_check,
    mutate_one,
    presupposed_inputs,
    sensitivity,
)

import config

# Ζ·ladder·sentinel (exit alphabet) — main()'s returns are TYPED so a caller can tell "call me
# again" from "you asked wrong".  0 done · 1 an adequacy FLOOR was not met · 2 INCOMPLETE, resume
# (the pump-witness spent its budget — re-run to continue) · _REFUSE a caller BUG the engine will
# not answer (a key that names no check, or a resumption token written against a different set).
# Refuse used to share code 2 with resume, so a naive `until discriminate; do :; done` loop spun
# forever on a typo'd key (a downstream consumer measured 29 iterations in 15s before killing it).
# The distinct code lets the loop ABORT on a bug instead of retrying it; "not measured" is not a
# measurement, and "you asked wrong" is not "ask again".
_REFUSE = 3

# Ω·config — the knobs this module RESOLVES, declared here (place-by-ownership; the kernel
# hosts the mechanism only).
MIN_STRENGTH = config.Param("min-strength", "PAPERKIT_MIN_STRENGTH", config="min_strength",
                            help="Δ adequacy floor on the FALSIFIABILITY axis")
MIN_CORRO = config.Param("min-corroboration", "PAPERKIT_MIN_CORROBORATION", config="min_corroboration",
                         help="Δ floor on the orthogonal CORROBORATION axis")
RESOLUTION = config.Param("resolution", "PAPERKIT_RESOLUTION", config="resolution", default="file",
                          choices=("file", "def"), help="Δ mutation surface: file (project only) or def (+ engine)")
STATE = config.Param("state", "PAPERKIT_STATE",
                     help="resumable grading: the resumption-token file (persisted between calls)")
BUDGET = config.Param("budget", "PAPERKIT_BUDGET",
                      help="seconds per Δ invocation (<=0 = run to completion; unset = batch grade)")
ALL = config.Param("all", "PAPERKIT_ALL", flag=True,
                   help="Δ grades every checked warrant, not only cited ones")
FOOTPRINT = config.Param("footprint", "PAPERKIT_FOOTPRINT", flag=True,
                         help="print each check's READ footprint and exit")
NO_CACHE = config.Param("no-cache", "PAPERKIT_NO_CACHE", flag=True,
                        help="ignore the Δ footprint-cache (re-grade every check)")
MUTANT = config.Param("mutant", "PAPERKIT_MUTANT",
                      help="Ζ·mutant: with --only, probe ONE def-site (path or path::qualname) — mutate it, report whether it flips the check, exit (the sweep's atom, for a pk_mutant action)")
# The Δ CLI's composed registry: exactly the Params its import cone hosts — its own 9 plus
# every host below it in the DEPS lattice (bnd-config asserts this completeness — a
# cone-resolved Param missing here would be a silently ignored flag).
REGISTRY = [MIN_STRENGTH, MIN_CORRO, RESOLUTION, STATE, BUDGET, ALL, FOOTPRINT, NO_CACHE, MUTANT,
            grader.DELTA_REPEAT, grader.DELTA_PULSE, layout.ROOT, resolver.PATH, resolver.ENGINE_PATH,
            G.SAFE, G.WITHOUT_K, G.JOBS, G.JSON, G.ONLY, G.INVARIANTS,
            project.TARGET, project.GENRE, project.GAMMA, project.OBSERVE, project.CHECK]


def _fine(rec: dict) -> list:
    """Δ·grain — the sensitivity set to key on, or [] when there is none to trust.  Only a
    BEHAVIORAL grade has a measured surface: an indeterminate one was flipped by nothing, so it
    has no definitions to key on and must keep the whole-file key.
    """
    return list(rec.get("tests") or []) if rec.get("grade") == "behavioral" else []


def main(argv: list) -> int:
    config.apply_args(argv, REGISTRY)   # Ω·config: capture args process-locally (arg overrides env)
    pos = config.positionals(argv, REGISTRY)
    project_dir = Path(pos[0]).resolve() if pos else Path.cwd()
    sandbox_root = _sandbox_root(project_dir)   # resolve+validate the sandbox root up front (home-guard) — clean exit before any sweep
    cfg = bib.load_config(project_dir)
    raw = tomllib.loads((project_dir / "paper.toml").read_text())
    pol, custom = raw.get("paper", {}), raw.get("checks", {})   # project policy + custom check types
    presupposed = presupposed_inputs(project_dir, cfg)

    # every knob resolved through the ONE pipeline (env [post-arg] > paper.toml [paper] > default),
    # validated against its choices inside resolve() — except the two FLOORS, validated here.
    min_strength = config.resolve(MIN_STRENGTH, pol)
    min_corro = config.resolve(MIN_CORRO, pol)
    # Ζ·ladder — the valid FLOORS are the ladder's, so both sets are DERIVED from grade.py at
    # its ONE consumer (this module already imports the ladder; config carrying choices= would
    # re-import grade into the kernel and put the ladder in every module's cone —
    # Μ·kernel·shrink·grade-edge).  Listing them would let the knob and the ladder disagree —
    # a floor the ladder cannot rank.
    if min_strength is not None and min_strength not in ORDER:
        raise SystemExit(f"paperkit: --min-strength must be one of {sorted(ORDER)} (got {min_strength!r})")
    if min_corro is not None and min_corro not in CORRO_C:
        raise SystemExit(f"paperkit: --min-corroboration must be one of {sorted(CORRO_C)} (got {min_corro!r})")
    resolution = config.resolve(RESOLUTION, pol)
    state_file = config.resolve(STATE)
    budget_raw = config.resolve(BUDGET)     # None = batch grade; a value = resumable under a budget
    budget = float(budget_raw) if budget_raw else 0.0
    consider_all = config.resolve(ALL)
    as_json = config.resolve(G.JSON)

    F = {}
    for b in cfg["bibs"]:
        F.update(bib.parse(b, cfg["consumer_fields"]))

    out = cfg["out"]
    cited = G.cited_keys(out.read_text()) if out.exists() else set()
    if config.resolve(project.TARGET, pol) == "plain":
        # plain surfaces no citation marker, but the projection weaves every section-tagged claim — so each
        # is placed-in-prose and must be graded (identical scope to the footnote target, which marked all).
        cited |= {k for k, f in F.items() if f.get("section")}
    # GROUNDING closure — grade every claim the considered set RESTS ON, transitively: a cited
    # claim's grounding premises are load-bearing whether or not a citation marker for them
    # survives in the rendered prose (the gate's rests_closure twin — same scope, same edges).
    cited |= bib.rests_closure(cited & set(F), F)[0]

    only = config.resolve(G.ONLY)
    if only:
        # Ζ·nest — grade ONE claim (the per-claim grade ORACLE), emitting its raw grade as JSON.
        # Bazel nests one of these per claim and aggregates them (pk_adequacy), so the whole-project
        # SWEEP is the build graph — not the loop below, which stays for direct/on-demand use.
        f = F.get(only)
        if not f or not f.get("check"):
            # Ζ·ladder·sentinel — "there is no such claim" is NOT A GRADE.  The ladder totally orders
            # MEASUREMENTS; an absent claim was never measured, so placing it on the ladder is a
            # category error — and the rung it borrowed, `broken`, MEANS "does not pass in a pristine
            # sandbox", i.e. the repo is red.  Two states collapsed to one alarming word, and because
            # `grade.below("behavioral")` includes `broken`, a mistyped key silently FAILED adequacy
            # while this path exited 0.  Absence gets its own denotation (an `error` record) and its
            # own loud exit: a key that names nothing is a caller bug, not a measurement.
            # (Reported by a downstream consumer, who lost a debugging cycle reading it as "repo red".)
            print(json.dumps({"claim": only,
                              "error": "no-check" if f else "no-such-claim"}), file=sys.stderr)
            return _REFUSE                     # a key naming nothing is a caller bug, NOT a resume
        chk = f["check"]
        mutant = config.resolve(MUTANT)
        if mutant:
            # Ζ·mutant — the SINGLE-SITE probe lifted for Bazel: mutate exactly one def-site and
            # report whether it flips the check.  A pk_mutant action runs this per (claim, site);
            # pk_sens aggregates the {flipped} records into the `sens` fingerprint the in-process
            # sweep used to compute alone.  No sweep here — one mutation, hermetic.
            print(json.dumps({"claim": only, "site": mutant,
                              "flipped": mutate_one(project_dir, chk, custom, mutant)}))
            return 0
        res = _grade_parallel(project_dir, [chk], custom, presupposed, resolution)
        rec = res[chk]
        if "--calc" in argv:
            # Ζ·calc — emit the CALCULATION (the measurement), separate from the grade INTERPRETATION:
            # the baseline verdict + the sensitivity fingerprint that a reading (grade/emergence/...)
            # consumes.  The expensive sweep runs ONCE here; readings over this record are free.
            # Μ·sweep·atom — carry the orthogonal decision-coverage axis (if grade_check measured any
            # reached-but-unasserted decision) onto the __dcalc record, so the grade/cohere reading and
            # the compliance disclosure see it without re-sweeping.  Absent ⇒ no such decision (common).
            calc = {"claim": only, "baseline": rec.get("baseline", rec["grade"] != "broken"),
                    "sens": rec.get("tests", [])}
            # ⚡ Ζ·calc·why·carry — CARRY THE CHECK'S OWN ACCOUNT ONTO THE CALC RECORD.
            # grader.py sets rec["check_said"] on a failing baseline (Ζ·calc·why) and this dict
            # dropped it, so the record every consumer reads said `{"baseline": false, "sens": []}`
            # — one bit — for a check that had explained itself in five arms.  MEASURED on
            # arch-roster-wired: green on the host, red in the cell, and two successive diagnoses
            # built on that one bit were both wrong.  Absent when the baseline passed or the check
            # said nothing, so every existing record stays byte-identical — the same non-breaking
            # widening `why` took in the verdict record.
            if rec.get("check_said"):
                calc["check_said"] = rec["check_said"]
            # ⚑ Ζ·broken·offaxis — CARRY THE TRISTATE ACROSS THE SERIALIZATION BOUNDARY.
            #
            # `baseline` above is the RAW measured verdict, and UNREACHABLE (grader._Unreachable) is
            # an `int` subclass returning 0 — falsy, so every `if not baseline` still holds, and
            # distinguishable IN PROCESS.  json.dumps writes it as `0`, BYTE-IDENTICAL to a refuted
            # `False`, and tools/read_grade.py cannot pass `reachable=` because the record no longer
            # says which one it was.  So every calc-derived grade record reported
            # `baseline: "refuted"` with "repo is not green" — including for a check that merely
            # could not RUN.  That is the exact false statement grade.py:86-92 records as MEASURED
            # TWICE on 2026-08-26, reappearing at the one boundary the Bazel pipeline runs through.
            #
            # The sentinel cannot survive JSON, so the AXIS is carried beside the value, on the
            # `decisions_unasserted` model directly below: an orthogonal key, present only when it
            # applies, that NAMES THE GAP and never moves the rung (BASELINE_C's own discipline —
            # "unreachable is not worse than refuted, it is a different kind of statement").
            # Absent ⇒ reachable, so every existing record and reader is unaffected.
            if rec.get("baseline") is UNREACHABLE:
                calc["reachable"] = False
            if rec.get("decisions_unasserted"):
                calc["decisions_unasserted"] = rec["decisions_unasserted"]
            print(json.dumps(calc))
        else:
            print(json.dumps({"claim": only, "grade": rec["grade"]}))   # the grade INTERPRETATION
        return 0

    # which warrants to grade
    keys = [k for k, f in F.items() if f.get("check")
            and (consider_all or k in cited)]

    # share counts: how many CONSIDERED warrants lean on each distinct check
    share: dict[str, list] = {}
    for k in keys:
        share.setdefault(F[k]["check"], []).append(k)

    if config.resolve(FOOTPRINT):
        # Φ·footprint: each considered check's READ footprint (the project files it opens),
        # the SOUND per-check key a footprint cache invalidates on — a diff touching none of
        # a check's footprint cannot change its verdict.  Reads ⊇ Δ's sensitivity `tests`.
        print(json.dumps({c: G.footprint(c, project_dir, custom) for c in sorted(share)}, indent=2))
        return 0

    # Δ·footprint-cache: a Δ grade is a pure function of its inputs, so cache it PER CHECK,
    # keyed on the content of the files it actually READS (Φ·footprint) plus the engine
    # EPOCH (_engine_hash).  A commit then re-grades only the checks whose footprint the diff
    # touched — where the old whole-project content_key cache invalidated EVERY check on any
    # edit.  Reuse a check while its footprint files (and the engine) are unchanged.
    no_cache = config.resolve(NO_CACHE)
    engine = _engine_hash()
    cached = {} if no_cache else _load_cache(project_dir)
    # A grade is a function of the check's inputs AND the sandbox UNIVERSE it reran in: a root
    # change (declared or re-inferred) changes what the pristine copy contains, which can flip a
    # baseline without touching any footprint file — so the root is part of the cache validity,
    # exactly like `resolution`.
    valid = (cached.get("engine") == engine and cached.get("resolution") == resolution
             and cached.get("root") == str(sandbox_root))
    entries = cached.get("checks", {}) if valid else {}

    reuse, stale = {}, []
    for c in share:
        e = entries.get(c)
        if e and _footprint_hash(project_dir, e["footprint"], _fine(e.get("grade", {}))) == e["fp"]:
            reuse[c] = e
        else:
            stale.append(c)

    # Δ·bank·cohere — a resumption token indexes into THIS `stale` list (the witness pumps a
    # cursor over it), so a token is only meaningful against the set it was written against.
    # Banking makes the cache move DURING a sweep, so the two interact, and the interaction has
    # two very different cases that must not be conflated:
    #
    #   the EXPECTED shrink   banking removed exactly the checks this token already graded.  The
    #                         cursor counted them; the new stale set no longer contains them.
    #                         Resuming at that cursor would SKIP that many un-graded checks.  The
    #                         grades are safe in the cache, so the repair is to reset the cursor
    #                         to 0 and sweep what remains — no measurement is lost or repeated.
    #
    #   a genuine DIVERGENCE  the set changed some other way (an edit, a changed root, a
    #                         different project).  A cursor into it names different claims, and
    #                         no reset can make the old token mean anything.  Ν·loud: refuse.
    #
    # Telling them apart is what the sidecar is for: it records the stale set the token was
    # written against, so the shrink can be checked for being a SUBSET (banking) rather than
    # merely different (divergence).  Before banking, the cache never moved mid-sweep and this
    # whole interaction was unreachable.
    if state_file is not None and stale:
        sidecar = Path(str(state_file) + ".stale")
        prior = (sidecar.read_text().splitlines()
                 if Path(state_file).exists() and sidecar.exists() else None)
        if prior is not None and prior != stale:
            if set(stale) <= set(prior):
                # the expected shrink — banked grades left the stale set.  Drop the token: its
                # cursor counts a longer list, and every grade it stood for is already cached.
                Path(state_file).unlink(missing_ok=True)
                print(f"paperkit-discriminate: {len(prior) - len(stale)} banked grade(s) left the "
                      f"stale set; resumption token reset (the grades are durable in the cache, "
                      f"so nothing is re-measured)", file=sys.stderr)
            else:
                print(f"Ν·loud: {state_file} was written against a stale set this run does not "
                      f"extend ({len(prior)} check(s) then, {len(stale)} now, "
                      f"{len(set(stale) - set(prior))} of them unseen) — an edit, a changed root "
                      f"or a different project.  Its cursor no longer names the same claims.  "
                      f"Delete it and re-run.", file=sys.stderr)
                return _REFUSE                 # a token naming a different set is a bug, NOT a resume
        try:
            sidecar.write_text("\n".join(stale))
        except OSError:
            pass                              # a read-only state dir is not a grading failure

    fresh, fresh_grader = {}, None
    if stale and state_file is None and budget_raw is None:
        # Batch grade — the default.  Test the RAW value (budget_raw): an absent --budget
        # coerces to 0.0 ("run to done"), so `budget is None` would never hold and would
        # leave this path dead (the Σ·flat·gate guard-fix).  Only the STALE checks are swept.
        fresh_grader = "_grade_parallel"
        fresh = _grade_parallel(project_dir, stale, custom, presupposed, resolution)
    elif stale:
        # Resumable path: grade the stale checks as a pump-witness under an optional budget
        # (--state/--budget make a long grade resume across short calls — pump-ask liveness).
        witness = GradeWitness(project_dir, stale, custom, presupposed, resolution)
        meaning, steps, done = D.drive(witness, state_path=state_file, budget=budget)
        if not done:
            # Δ·bank — BANK the increment's completed grades into the cache before returning.
            # The resumption token already makes the next call CONTINUE; without this the graded
            # records reach only the state file, which nothing but the driver reads — so a
            # partial grade was invisible to every cache consumer (coherence --from-cache, a
            # later sweep's `reuse` set) until a run happened to finish.  A grade is durable the
            # moment it is measured, not the moment the sweep ends: bank it here on exactly the
            # terms the completion path uses below, so N bounded increments and one long run
            # leave the SAME cache.  Entries not yet graded are simply absent (a partial cache is
            # a partial reading, never a wrong one); an untraceable footprint stays uncacheable.
            if not no_cache:
                banked = dict(reuse)
                for c, rec in meaning["graded"].items():
                    fp = rec.get("_footprint", [])
                    if fp is None:
                        continue                  # Φ·degrade — uncacheable, as below
                    banked[c] = {"grade": {k: v for k, v in rec.items() if k != "_footprint"},
                                 "footprint": fp,
                                 "fp": _footprint_hash(project_dir, fp, _fine(rec))}
                _save_cache(project_dir, {"engine": engine, "resolution": resolution,
                                          "root": str(sandbox_root), "checks": banked})
            print(f"paperkit-discriminate: graded {meaning['progress']} in {steps} increment(s) — "
                  f"not done; state persisted to {state_file} ({len(meaning['graded'])} grade(s) "
                  f"banked to the cache), re-run to resume", file=sys.stderr)
            return 2
        fresh = meaning["graded"]
        fresh_grader = "GradeWitness"

    # assemble grades + a PER-CHECK grader, and refresh the cache entry of each graded check
    # with its fresh footprint (Σ·flat·witness: a reused grade reports grader "cache").
    graded, grader_of, new_entries = {}, {}, dict(reuse)
    for c, e in reuse.items():
        graded[c], grader_of[c] = e["grade"], "cache"
    for c in stale:
        fp = fresh[c].pop("_footprint", [])   # computed once during grading (scoping + cache); strip from the record
        graded[c], grader_of[c] = fresh[c], fresh_grader
        if fp is None:
            continue                          # Φ·degrade: untraceable footprint — UNCACHEABLE (re-grade
            # every run).  Storing it under [] would over-reuse a grade whose inputs we never saw.
        new_entries[c] = {"grade": fresh[c], "footprint": fp,
                          "fp": _footprint_hash(project_dir, fp, _fine(fresh[c]))}

    if not no_cache:
        _save_cache(project_dir, {"engine": engine, "resolution": resolution,
                                  "root": str(sandbox_root), "checks": new_entries})

    if stale:
        print(f"paperkit-discriminate: graded by {fresh_grader} "
              f"({len(stale)} graded, {len(reuse)} reused from footprint cache)", file=sys.stderr)
    else:
        print(f"paperkit-discriminate: all {len(reuse)} grade(s) reused from footprint cache", file=sys.stderr)
    records = []
    for k in keys:
        chk = F[k]["check"]
        g = dict(graded[chk])
        g.update(key=k, check=chk, cited=k in cited, section=F[k].get("section"),
                 shared_with=[o for o in share[chk] if o != k])
        g["from"] = F[k].get("from", [])
        g["rests-on"] = F[k].get("rests-on", [])     # grounding edges (for clamping)
        g["grader"] = grader_of[chk]
        records.append(g)

    # content inputs = the files a check must touch to discriminate the paper's CONTENT (not
    # merely its config/engine).  The INTERPRETATION lives in grade (Μ·grade — calc vs interp):
    # mark content-sensitivity, then clamp the effective grade by entailment over rests-on.
    content = {p.name for p in cfg["bibs"]} | {cfg["rubric"].name, cfg["out"].name}
    mark_content_sensitive(records, content)
    # Ζ·rests·unresolved — hand clamp the bib's key set so a `rests-on` target that was
    # never graded reads as a TRUNCATION rather than as an edge imposing no constraint.
    clamp(records, keys=set(F))

    if as_json:
        print(json.dumps(records, indent=2))
    else:
        report(records, share, graded, len(cited), len(keys), consider_all)

    rc = 0
    if min_strength is not None:
        floor = ORDER[min_strength]
        weak = [r for r in records if STRENGTH.get(r["grade"], 0) < floor]
        if weak:
            print(f"\npaperkit-discriminate: {len(weak)} warrant(s) below "
                  f"strength '{min_strength}':", file=sys.stderr)
            for r in weak:
                print(f"  [@{r['key']}] {r['grade']} — {r['check']}", file=sys.stderr)
            rc = 1
        else:
            print(f"\npaperkit-discriminate: all {len(records)} warrant(s) "
                  f"meet strength '{min_strength}'")
    if min_corro is not None:
        floor = CORRO_C[min_corro]
        weak = [r for r in records if CORRO_C.get(r.get("corroboration", "single"), 0) < floor]
        if weak:
            print(f"\npaperkit-discriminate: {len(weak)} warrant(s) below "
                  f"corroboration '{min_corro}':", file=sys.stderr)
            for r in weak:
                print(f"  [@{r['key']}] {r.get('corroboration', 'single')} — {r['check']}", file=sys.stderr)
            rc = 1
        else:
            print(f"\npaperkit-discriminate: all {len(records)} warrant(s) "
                  f"meet corroboration '{min_corro}'")
    return rc


def report(records, share, graded, n_cited, n_checked, consider_all):
    scope = "all checked" if consider_all else f"of {n_cited} cited"
    print(f"paperkit-discriminate (Δ): {n_checked} {scope} warrant(s) carry a "
          f"check, {len(share)} distinct check(s)\n")
    # Ζ·ladder — the ladder's own total order (grade.RANK_C), not a second copy of it.
    order = RANK_C
    for r in sorted(records, key=lambda r: (order.get(r["grade"], 9), r["key"])):
        share_n = len(r["shared_with"]) + 1
        dil = f"  (shared by {share_n} claims)" if share_n > 1 else ""
        crash = (r["grade"] == "behavioral" and not r.get("content_sensitive"))
        tag = "  ⚠ config/crash-sensitive only" if crash else ""
        # Ζ·surface·kind — a grade is only as complete as the surface it was measured over.  Say so
        # NEXT TO the grade, because the number of inputs the sweep could not touch is exactly what
        # a reader would otherwise assume was zero.  Orthogonal to the rung, like crash-sensitivity.
        un = r.get("unmeasured") or []
        tag += f"  ⚠ {len(un)} unmeasured input(s): {', '.join(un[:3])}" if un else ""
        # Ζ·corro·honest — report ANY multi-producer corroboration, not only the top rung.
        # This printed nothing unless the value was `independent`, so widening the axis
        # would have made every record silent — the value most worth showing is the one
        # that says the producers were never checked for shared ground.
        corro = (f"  + {r['corroboration']} ({r.get('producers','?')} producers)"
                 if r.get("corroboration", "single") != "single" else "")
        print(f"  {r['grade']:13} [@{r['key']}]{dil}{tag}{corro}")
        print(f"  {'':13} check: {r['check']}")
        if r["tests"]:
            shown = ", ".join(r["tests"][:6]) + ("…" if len(r["tests"]) > 6 else "")
            print(f"  {'':13} sensitive to: {shown}")
        why = r["why"]
        if crash:
            why += " — but touches no content input (warrants/rubric/prose); flips only by crashing on malformed config"
        print(f"  {'':13} {why}\n")
    counts: dict[str, int] = {}
    for r in records:
        counts[r["grade"]] = counts.get(r["grade"], 0) + 1
    summary = ", ".join(f"{n} {g}" for g, n in sorted(counts.items()))
    print(f"  summary (self-grade): {summary}")
    eff_counts: dict[str, int] = {}
    for r in records:
        eff_counts[r.get("effective_grade", r["grade"])] = \
            eff_counts.get(r.get("effective_grade", r["grade"]), 0) + 1
    print(f"  summary (effective):  {', '.join(f'{n} {g}' for g, n in sorted(eff_counts.items()))}")
    clamped = [r for r in records if r.get("clamp", 0) > 0]
    vac = counts.get("vacuous", 0)
    if vac:
        print(f"  ⚠ {vac} cited claim(s) rest on a check that PROVABLY cannot fail.")
    if clamped:
        print(f"  ⚠ {len(clamped)} cited claim(s) are CLAMPED below their self grade by "
              f"weaker premises (effective < self).")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
