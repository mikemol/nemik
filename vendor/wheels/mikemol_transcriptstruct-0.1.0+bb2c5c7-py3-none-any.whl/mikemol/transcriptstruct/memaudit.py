# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Mike Mol
"""Audit a memory directory against its project's transcripts, read-only (W1545, W1541).

⚑ THE OPERATOR ASKED FOR THIS VERBATIM (2026-10-18, after el-openglo swarmed on a stale note): the
memory files are audited against the same "verify against the transcript, find the operator
ruling" principles as a card. For each note this prints one row per finding and writes nothing:
a GRANT row for each line that grants a permission or lifts a rule (priority review), a
WARRANTED or UNWARRANTED row for each claimed operator quote (WARRANTED names the record), and
up to `SHOWN` POSSIBLY-SUPERSEDED rows naming the newest later utterances on the note's subject,
and an UNINDEXED row for a note no line of `MEMORY.md` points at.

⚑ THE TRANSCRIPTS ARE THE MEMORY DIRECTORY'S PARENT (`~/.claude/projects/<project>/memory`), the
top-level `*.jsonl` only: a subagent's transcript is not the operator's. Each session reviews its
own directory and corrects or deletes; nothing here edits a note.
CONSUMED BY: the `--audit-memory` mode of `mikemol-transcriptstruct`.
"""

import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import cast

from mikemol.transcriptstruct import memclaims, memfind, memgrants
from mikemol.transcriptstruct.memfind import Utterance
from mikemol.transcriptstruct.query import grep_prose
from mikemol.transcriptstruct.records import read_path

SHOWN = 3
GRANT = "GRANT"
SUPERSEDED = "POSSIBLY-SUPERSEDED"
LINKED_NEWER = "LINKED-NEWER"
LINK_OVERLAP = 2
ELSEWHERE = "ELSEWHERE"
UNINDEXED = "UNINDEXED"
DANGLING = "DANGLING"
_UNFOUND = frozenset({memfind.UNWARRANTED, memfind.RELAYED})
INDEX = "MEMORY.md"
_INDEXED = re.compile(r"\]\(([^)\s]+\.md)\)")
_DATE = re.compile(r"\b20[0-9]{2}-[0-9]{2}-[0-9]{2}\b")
_SUBJECT = re.compile(r"^(?:name|description):")
_LINK = re.compile(r"\[\[([^\]\n]+)\]\]")
_MODIFIED = re.compile(r"^[ \t]*modified:[ \t]*(\S+)", re.MULTILINE)
_DETAIL = 100
_END_OF_DAY = "T99"


@dataclass(frozen=True)
class Row:
    """One finding about one line of one note."""

    note: str
    line: int
    status: str
    detail: str
    claim: str = ""

    def text(self) -> str:
        """Spell the finding as one line.

        Returns:
            `<note>:<line>  <STATUS>  <detail>`.

        """
        return f"{self.note}:{self.line}  {self.status}  {self.detail}"


def utterances_of(project: Path) -> list[Utterance]:
    """Collect what the operator said in a project's top-level transcripts.

    Returns:
        every human utterance, file by file in name order.

    """
    found: list[Utterance] = []
    for path in sorted(project.glob("*.jsonl")):
        result = grep_prose(read_path(path), ".", speakers={"human"})
        found.extend(Utterance(str(path), h.line, h.uuid, h.at, h.text) for h in result.hits)
    return found


def indexed(index: str) -> dict[str, int]:
    """Read which note files the index points at, and the first line that does.

    Returns:
        each `(file.md)` link target of the index, mapped to its first line number.

    """
    found: dict[str, int] = {}
    for number, raw in enumerate(index.splitlines(), start=1):
        for target in cast("list[str]", _INDEXED.findall(raw)):
            found.setdefault(target, number)
    return found


Stamp = tuple[str, int]
"""A note's `modified:` stamp ("" when it has none) and its file's modification time in ns."""


def _newer(mine: Stamp, other: Stamp) -> bool:
    # By the notes' own `modified:` stamps when both carry one, else by file modification time.
    if mine[0] and other[0]:
        return mine[0] > other[0]
    return mine[1] > other[1]


def _supersedes(
    name: str, grants: list[str], notes: dict[str, str], stamps: dict[str, Stamp]
) -> str | None:
    # The first indexed GRANT note this one is newer than and shares `LINK_OVERLAP` terms with.
    subject = _subject(notes[name])
    for other in grants:
        shared = len(subject & _subject(notes[other]))
        if _newer(stamps[name], stamps[other]) and shared >= LINK_OVERLAP:
            return other
    return None


def rank_unindexed(
    rows: list[Row], notes: dict[str, str], stamps: dict[str, Stamp], pointed: dict[str, int]
) -> list[Row]:
    """Put first the UNINDEXED notes that may supersede an indexed grant.

    ⚑ THIS IS EXACTLY THE SWARM SHAPE (github-8f, 2026-10-18, W1570, from el-openglo's W686): the
    stale grant was indexed and loaded, the ruling that withdrew it was a newer note on the same
    subject that no index line named. So an UNINDEXED note that is newer than an indexed note with
    a GRANT row, and shares `LINK_OVERLAP` of its key terms, is moved ahead of every other row and
    its detail names that grant note.

    Returns:
        the rows, those unindexed notes first (in their original order), then the rest unchanged.

    """
    grants = sorted({r.note for r in rows if r.status == GRANT and r.note in pointed})
    first: list[Row] = []
    rest: list[Row] = []
    for row in rows:
        other = _supersedes(row.note, grants, notes, stamps) if row.status == UNINDEXED else None
        if other is None:
            rest.append(row)
        else:
            detail = f"{row.detail}; newer than {other} (GRANT) on the same subject: may supersede"
            first.append(Row(row.note, row.line, UNINDEXED, detail))
    return [*first, *rest]


def _subject(text: str) -> frozenset[str]:
    """Take the key terms of a note's name and description lines.

    Returns:
        the terms, empty when the note has neither line.

    """
    lines = [raw for raw in text.splitlines() if _SUBJECT.match(raw)]
    return memfind.terms(" ".join(lines))


def _latest(texts: list[str]) -> str:
    """Find the newest date a note's claims mention, as a cut-off past the end of that day.

    Returns:
        `<date>T99` for the newest date, or "" when no claim carries one.

    """
    dates: list[str] = []
    for text in texts:
        dates.extend(cast("list[str]", _DATE.findall(text)))
    return f"{max(dates)}{_END_OF_DAY}" if dates else ""


def _modified(text: str) -> str:
    """Read a note's `modified:` stamp.

    Returns:
        the stamp, or "" when the note has none.

    """
    found = _MODIFIED.search(text)
    return found.group(1) if found is not None else ""


def linked_newer(name: str, text: str, notes: dict[str, str]) -> list[Row]:
    """Report the notes this one links to that are newer and share its subject.

    ⚑ A LINK IS THE AUTHOR'S OWN CLAIM OF RELATEDNESS (github-8f, 2026-10-18, W1550): when a note
    it points at was modified after it and shares `LINK_OVERLAP` of its key terms, that newer note
    may contradict it, a stronger signal than term overlap with an utterance. It cannot tell
    contradiction from agreement, so the row names the pair for a reviewer.

    Returns:
        one `LINKED-NEWER` row per such link, in link-name order.

    """
    mine = _modified(text)
    subject = _subject(text)
    rows: list[Row] = []
    for link in sorted(set(cast("list[str]", _LINK.findall(text)))):
        other = notes.get(f"{link}.md")
        if other is None or _modified(other) <= mine:
            continue
        if len(subject & _subject(other)) >= LINK_OVERLAP:
            rows.append(Row(name, 0, LINKED_NEWER, f"{link}.md modified {_modified(other)}"))
    return rows


def audit_note(name: str, text: str, utterances: list[Utterance]) -> list[Row]:
    """Audit one note.

    Returns:
        its GRANT rows, then a row per claim, then the newest later utterances on its subject.

    """
    rows = [Row(name, g.line, GRANT, ",".join(g.words)) for g in memgrants.grants(text)]
    claims = memclaims.claims(text)
    for found in (memfind.warrant_for(c, utterances) for c in claims):
        record = found.record
        where = found.claim.text[:_DETAIL]
        if record is not None:
            where = f"{record.path}:{record.line} uuid={record.uuid}"
            where += " (approximate)" if found.approximate else ""
        unfound = found.claim.text if found.status in _UNFOUND else ""
        rows.append(Row(name, found.claim.line, found.status, where, unfound))
    since = _latest([c.text for c in claims])
    if since:
        later = memfind.superseded_by(_subject(text), since, utterances)
        rows.extend(
            Row(name, 0, SUPERSEDED, f"{u.at} {u.path}:{u.line} uuid={u.uuid}: {u.text[:_DETAIL]}")
            for u in later[:SHOWN]
        )
    return rows


def elsewhere(rows: list[Row], projects: Iterable[Path]) -> list[Row]:
    """Look each unfound quote up in other projects' transcripts, and say where it was found.

    ⚑ A RULING IS OFTEN GIVEN IN ANOTHER SESSION (github-8f, 2026-10-18, W1552): luthen's or
    cassian's transcripts hold words a note in this project's memory quotes, so a quote this
    project's transcripts do not carry is not yet unwarranted. Each project is read only while an
    unfound quote remains, and a quote found becomes `ELSEWHERE <path>:<line> uuid=<uuid>`.

    Returns:
        the rows, with each quote found in another project's transcripts re-stated as ELSEWHERE.

    """
    out = list(rows)
    pending = [i for i, row in enumerate(out) if row.claim]
    for project in projects:
        if not pending:
            break
        utterances = utterances_of(project)
        for i in list(pending):
            row = out[i]
            found = memfind.warrant_for(memclaims.Claim(row.line, "quote", row.claim), utterances)
            if found.record is not None:
                record = found.record
                where = f"{record.path}:{record.line} uuid={record.uuid}"
                out[i] = Row(row.note, row.line, ELSEWHERE, where)
                pending.remove(i)
    return out


def _siblings(memory: Path) -> list[Path]:
    """Name the other projects beside this memory directory's project.

    Returns:
        their directories in name order; empty when the projects directory cannot be listed.

    """
    try:
        beside = sorted(memory.parent.parent.iterdir())
    except OSError:
        return []
    return [p for p in beside if p.is_dir() and p != memory.parent]


def audit(memory: Path) -> list[Row]:
    """Audit every note of a memory directory against its project's transcripts.

    ⚑ A NOTE NO INDEX LINE POINTS AT NEVER LOADS (github-8f, 2026-10-18, W1568, from el-openglo's
    W686): the superseding no-swarm ruling sat in a file with no `MEMORY.md` line, so only the stale
    grant was ever read. Every such note gets an UNINDEXED row, and a directory with no index at
    all has every note unindexed. The converse is a DANGLING row (W1569) on the index itself, for a
    line whose file the directory does not hold: a rule the author thinks is loaded, and is not.

    Returns:
        the findings, note by note in name order; `MEMORY.md` is the index and is skipped.

    """
    utterances = utterances_of(memory.parent)
    paths = sorted(memory.glob("*.md"))
    notes = {p.name: p.read_text(encoding="utf-8") for p in paths}
    stamps = {p.name: (_modified(notes[p.name]), p.stat().st_mtime_ns) for p in paths}
    pointed = indexed(notes.get(INDEX, ""))
    rows: list[Row] = []
    for name, text in notes.items():
        if name != INDEX:
            rows.extend(audit_note(name, text, utterances))
            rows.extend(linked_newer(name, text, notes))
            if name not in pointed:
                rows.append(Row(name, 0, UNINDEXED, f"no line of {INDEX} points at it"))
    rows.extend(
        Row(INDEX, line, DANGLING, f"{target} is not in the directory")
        for target, line in pointed.items()
        if target not in notes
    )
    return elsewhere(rank_unindexed(rows, notes, stamps, pointed), _siblings(memory))
